# Beluga: One IoT container engine based on Moby

## Main Links

- [Overview](#introduction)
- [Features](#features)
- [Different with Moby and Docker CE](#Different with Moby and Docker CE)
- [Licensing](#Licensing)

## Overview

Beluga is a container engine for IoT and compatible with Docker containers. Based on Moby Project. IoT device have less resource than cloud and PC environment, smaller memory and storage space, lower performance CPU and loss network. Beluga has small footprint, lower memory usage and more faster run on low performance embedded CPU. It is for IoT device and promote container technology in IoT.  

## Features

- __Small footprint__
	- 4x smaller than Docker CE, 2x smaller than the docker 1.13 the latest Moby release. Put all Moby components into one source tree.
- __Multi-arch support__
	- Available for a wide variety of chipset architectures. 
- __Low memory usage__
	- Reduce binary footprint and package all binaries into one shared library bianry. Optimize go package's memory usage.
- __run_more_faster__
	- Remove reexec mechanism and remove components and initialization is not needed for IoT environment.

## Different with Moby and Docker CE

Remove some Docker features that we saw as most needed in cloud deployments and therefore not warranting inclusion in a lightweight IoT-focused container engine. 

- Docker Swarm
- Cloud logging drivers
- Plugin support
- Overlay networking driver
- Docker build and commit command
- Notary support
- unused FS drivers except overlayfs and vfs driver
- discovery backends consul, zookeeper and etcd

## Licensing

Beluga is licensed under the Apache License, Version 2.0. 
