package main

import (
	"fmt"
	"github.com/containerd/containerd/cmd/containerd-shim"
	"os"
	filepath "path/filepath"
)

func main() {
	switch filepath.Base(os.Args[0]) {
	case "docker-containerd-shim":
		containerd_shim.Main()
	default:
		fmt.Println("Not support command\n")
	}
}
