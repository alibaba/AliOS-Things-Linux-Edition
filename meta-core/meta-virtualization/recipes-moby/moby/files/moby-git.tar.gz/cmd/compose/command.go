package compose

import (
	"golang.org/x/net/context"

	"github.com/docker/libcompose/cli/app"
	"github.com/docker/libcompose/cli/command"
	"github.com/docker/libcompose/docker"
	"github.com/docker/libcompose/docker/ctx"
	"github.com/docker/libcompose/project"
	"github.com/docker/libcompose/project/options"
	"github.com/urfave/cli"
)

type ProjectFactory struct {
}

func (p *ProjectFactory) Create(c *cli.Context) (project.APIProject, error) {

	context := &ctx.Context{
		Context: project.Context{
			ProjectName: "pouch-compose",
		},
	}

	command.Populate(&context.Context, c)

	pr, err := docker.NewProject(context, nil)

	if err != nil {
		return nil, err
	}

	if err = pr.Parse(); err != nil {
		return nil, err
	}

	return pr, err
}

func StartCommand(factory app.ProjectFactory) cli.Command {
	return cli.Command{
		Name:   "start",
		Usage:  "Start services",
		Action: app.WithProject(factory, app.ProjectStart),
	}
}

func UpCommand(factory app.ProjectFactory) cli.Command {
	return cli.Command{
		Name:   "up",
		Usage:  "Bring all services up",
		Action: app.WithProject(factory, ProjectUp),
	}
}

func PullCommand(factory app.ProjectFactory) cli.Command {
	return cli.Command{
		Name:   "pull",
		Usage:  "Pulls images for services",
		Action: app.WithProject(factory, app.ProjectPull),
	}
}

func CreateCommand(factory app.ProjectFactory) cli.Command {
	return cli.Command{
		Name:   "create",
		Usage:  "Create all services but do not start",
		Action: app.WithProject(factory, app.ProjectCreate),
	}
}

func ProjectUp(p project.APIProject, c *cli.Context) error {
	if err := p.Up(context.Background(), options.Up{}, c.Args()...); err != nil {
		return err
	}

	return nil
}
