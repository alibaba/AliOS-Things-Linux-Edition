package compose

import (
	"os"

	"github.com/docker/libcompose/cli/command"
	"github.com/sirupsen/logrus"
	"github.com/urfave/cli"
)

func beforeApp(c *cli.Context) error {
	if c.GlobalBool("verbose") {
		logrus.SetLevel(logrus.DebugLevel)

	}
	return nil
}

func Main() {
	factory := &ProjectFactory{}

	app := cli.NewApp()
	app.Name = "pouch-compose"
	app.Usage = "Compose tool for pouch"
	app.Version = "v1.0.0"
	app.Author = "alibaba-inc"
	app.Email = "yangjie.yangjiewan@alibaba-inc.com"
	app.Before = beforeApp
	app.Flags = append(command.CommonFlags())

	app.Commands = []cli.Command{
		UpCommand(factory),
		StartCommand(factory),
		CreateCommand(factory),
		command.LogsCommand(factory),
		command.RestartCommand(factory),
		command.StopCommand(factory),
		command.ScaleCommand(factory),
		command.RmCommand(factory),
		PullCommand(factory),
	}

	if err := app.Run(os.Args); err != nil {
		logrus.Fatal(err)
	}

}
