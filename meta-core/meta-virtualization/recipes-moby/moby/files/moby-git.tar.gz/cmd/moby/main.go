package main

import (
	"fmt"
	"github.com/docker/docker/cmd/compose"
	"github.com/docker/docker/cmd/dockerd"
	"github.com/docker/docker/pkg/reexec"
	"github.com/docker/libnetwork/cmd/proxy"
	"os"
	filepath "path/filepath"
)

func main() {
	if reexec.Init() {
		return
	}

	switch filepath.Base(os.Args[0]) {
	case "dockerd":
		dockerd.Main()
	case "docker-compose":
		compose.Main()
	case "docker-proxy":
		proxy.Main()
	default:
		fmt.Println("Not support command\n")
	}
}
