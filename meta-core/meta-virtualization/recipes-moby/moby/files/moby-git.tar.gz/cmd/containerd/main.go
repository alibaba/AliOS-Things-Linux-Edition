package main

import (
	"fmt"
	"github.com/containerd/containerd/cmd/containerd"
	"github.com/containerd/containerd/cmd/ctr"
	"os"
	filepath "path/filepath"
)

func main() {
	switch filepath.Base(os.Args[0]) {
	case "docker-containerd":
		containerd.Main()
	case "docker-containerd-ctr":
		containerd_ctr.Main()
	default:
		fmt.Println("Not support command\n")
	}
}
