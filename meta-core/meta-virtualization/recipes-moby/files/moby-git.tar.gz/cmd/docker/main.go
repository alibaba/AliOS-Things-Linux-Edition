package main

import (
	"fmt"
	"github.com/docker/cli/cmd/docker"
	"os"
	filepath "path/filepath"
)

func main() {

	switch filepath.Base(os.Args[0]) {
	case "docker":
		docker.Main()
	default:
		fmt.Println("Not support command\n")
	}
}
