package main

import (
	"fmt"
	"github.com/opencontainers/runc"
	"os"
	filepath "path/filepath"
)

func main() {

	switch filepath.Base(os.Args[0]) {
	//case "docker":
	//	docker.Main()
	//case "dockerd":
	//	dockerd.Main()
	//case "docker-containerd":
	//	containerd.Main()
	//case "docker-containerd-shim":
	//	containerd_shim.Main()
	//case "docker-containerd-ctr":
	//	containerd_ctr.Main()
	case "docker-runc":
		runc.Main()
	//case "docker-proxy":
	//    proxy.Main()
	//case "docker-compose":
	//	compose.Main()
	default:
		fmt.Println("Not support command\n")
	}
}
