/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

#include "../adu.h"

mb_status_t rtu_assemble(mb_handler_t *handler);
mb_status_t rtu_disassemble(mb_handler_t *handler);

