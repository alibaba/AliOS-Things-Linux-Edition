/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

#ifndef _MB_CRC_H
#define _MB_CRC_H

uint16_t mb_crc16(uint8_t *frame, uint16_t frame_len);

#endif
