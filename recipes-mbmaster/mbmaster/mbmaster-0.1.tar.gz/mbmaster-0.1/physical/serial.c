/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */
#include <mbmaster_api.h>
#include "serial.h"
#include <sys/select.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>

static struct termios old_tio;

mb_status_t mb_serial_init(mb_handler_t * handler, uint8_t port, uint32_t baud_rate, uint8_t data_width, mb_parity_t parity)
{
    char        device_name[16];
    mb_status_t status = MB_SUCCESS;
	 
	int         serial_fd = -1;

    struct termios  new_tio;
    speed_t         speed_set;

    snprintf( device_name, 16, "/dev/ttyAMA%d", port );

    if((serial_fd = open( device_name, O_RDWR | O_NOCTTY ) ) < 0) {
        mb_log( MB_LOG_ERROR, "Can't open serial port %s: %s\n", device_name,
                    strerror( errno ) );
    } else if(tcgetattr( serial_fd, &old_tio ) != 0)
    {
        mb_log( MB_LOG_ERROR, "Can't get settings from port %s: %s\n", device_name,
                    strerror( errno ) );
    } else {
        bzero( &new_tio, sizeof( struct termios ) );

        new_tio.c_iflag |= IGNBRK | INPCK;
        new_tio.c_cflag |= CREAD | CLOCAL;
        switch ( parity )
        {
            case MB_PAR_NONE:
                break;
            case MB_PAR_EVEN:
                new_tio.c_cflag |= PARENB;
                break;
            case MB_PAR_ODD:
                new_tio.c_cflag |= PARENB | PARODD;
                break;
            default:
                status = MB_SERIAL_INIT_FAILED;
        }
        switch (data_width) {
            case 8:
                new_tio.c_cflag |= CS8;
                break;
            case 7:
                new_tio.c_cflag |= CS7;
                break;
            default:
                status = MB_SERIAL_INIT_FAILED;
        }
		
        switch (baud_rate) {
            case 9600:
                speed_set = B9600;
                break;
            case 19200:
                speed_set = B19200;
                break;
            case 38400:
                speed_set = B38400;
                break;
            case 57600:
                speed_set = B57600;
                break;
            case 115200:
                speed_set = B115200;
                break;
            default:
                status = MB_SERIAL_INIT_FAILED;
        }
        if(status == MB_SUCCESS) {
            if (cfsetispeed( &new_tio, speed_set ) != 0) {
                mb_log( MB_LOG_ERROR, "Can't set baud rate %ld for port %s: %s\n",
                            baud_rate, strerror( errno ) );
            } else if (cfsetospeed( &new_tio, speed_set ) != 0) {
                mb_log( MB_LOG_ERROR, "Can't set baud rate %ld for port %s: %s\n",
                            baud_rate, device_name, strerror( errno ));
            } else if (tcsetattr( serial_fd, TCSANOW, &new_tio ) != 0) {
                mb_log(MB_LOG_ERROR, "Can't set settings for port %s: %s\n",
                       device_name, strerror( errno ) );
            }
        }
    }
	
    handler->private = serial_fd;
    return status;
}

mb_status_t mb_serial_finalize(mb_handler_t * handler)
{
    mb_status_t   status = MB_SUCCESS;

	int serial_fd = (int)handler->private;
    if( serial_fd != -1 )
    {
        ( void )tcsetattr( serial_fd, TCSANOW, &old_tio );
        ( void )close( serial_fd );
        serial_fd = -1;
    }
    return status;
}

mb_status_t mb_serial_frame_send(mb_handler_t * handler)
{
    int     serial_fd = (int)handler->private;
	
	uint32_t   res;
    uint32_t   left = ( size_t ) handler->mb_frame_length;
    uint32_t   done = 0;

    while (left > 0) {
        if ((res = write( serial_fd, handler->mb_frame_buff + done, left)) == -1 ) {
            if( errno != EINTR ) {
                break;
            }
            continue;
        }
        done += res;
        left -= res;
    }
    return left == 0 ? MB_SUCCESS : MB_FRAME_SEND_ERR;
}

mb_status_t mb_serial_frame_recv(mb_handler_t * handler)
{
    int serial_fd = (int)handler->private;
	
	mb_status_t     status = MB_SUCCESS;
    uint32_t        res;
    fd_set          rfds;
    struct timeval  tv;

    tv.tv_sec = 0;
    tv.tv_usec = handler->respond_timeout * 1000;
    FD_ZERO(&rfds);
    FD_SET(serial_fd, &rfds);

    do {
        if(select( serial_fd + 1, &rfds, NULL, NULL, &tv) == -1 ) {
            if(errno != EINTR) {
                status = MB_SLAVE_NO_RESPOND;
            }
        } else if (FD_ISSET( serial_fd, &rfds )) {
            if ((res = read( serial_fd, handler->mb_frame_buff, ADU_BUF_MAX_LENGTH ) ) == -1) {
                status = MB_SLAVE_NO_RESPOND;
            } else {
                handler->mb_frame_length = ( uint16_t ) res;
                break;
            }
        } else {
            handler->mb_frame_length = 0;
            break;
        }
    } while( status == MB_SUCCESS );

    return status;
}
