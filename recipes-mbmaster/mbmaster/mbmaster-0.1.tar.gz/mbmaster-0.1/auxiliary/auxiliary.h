/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

/* forward declaration */
typedef enum mb_status mb_status_t;
typedef struct mb_handler mb_handler_t;

typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;

typedef enum
{
    MB_LOG_ERROR = 0,
    MB_LOG_DEBUG = 1
} mb_log_level_t;

#define MB_CRITICAL_ALLOC()
#define MB_CRITICAL_ENTER() pthread_mutex_lock(&mutex_critical_lock) 
#define MB_CRITICAL_EXIT()  pthread_mutex_unlock(&mutex_critical_lock) 

#define MB_MUTEX_T             pthread_mutex_t
#define MB_MUTEX_CREATE(mutex) mb_mutex_create(mutex)
#define MB_MUTEX_LOCK(mutex)   mb_mutex_lock(mutex)
#define MB_MUTEX_UNLOCK(mutex) mb_mutex_unlock(mutex)
#define MB_MUTEX_DEL(mutex)    mb_mutex_del(mutex)

#ifndef htobe
#define htobe(X) (((X >> 8) & 0x00ff) | ((X<<8) & 0xff00))
#endif

void     mb_log( mb_log_level_t log_level, const char* fmt_str, ... );
uint8_t* status_to_string(mb_status_t status);

mb_handler_t* mb_alloc_handler();
void mb_free_handler(mb_handler_t* handler);

mb_status_t mb_mutex_create(MB_MUTEX_T *mutex);
mb_status_t mb_mutex_lock(MB_MUTEX_T *mutex);
mb_status_t mb_mutex_unlock(MB_MUTEX_T *mutex);
mb_status_t mb_mutex_del(MB_MUTEX_T *mutex);
