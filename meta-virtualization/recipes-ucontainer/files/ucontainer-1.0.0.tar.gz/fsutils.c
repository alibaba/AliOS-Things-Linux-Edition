/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <mntent.h>
#include <utime.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "uC.h"
#include "fsutils.h"

int dir_Create(char * path, long mode)
{
	mode_t cur_mask;
	mode_t org_mask;
	char *s;
	char c;
	int retval;
	struct stat st;

	if (LONE_CHAR(path, '/'))
		return 0;
	if (path[0] == '.') {
		if (path[1] == '\0')
			return 0;
	}

	org_mask = cur_mask = (mode_t)-1L;
	s = path;
	while (1) {
		c = '\0';

		while (*s) {
			if (*s == '/') {
				do {
				    ++s;
				} while (*s == '/');
				c = *s;
				*s = '\0';
				break;
			}
			++s;
		}

        if (c != '\0') {
		    if (cur_mask == (mode_t)-1L) {
		    	mode_t new_mask;
	    		org_mask = umask(0);
		    	cur_mask = 0;
	    		new_mask = (org_mask & ~(mode_t)0300);

	    		if (new_mask != cur_mask) {
		    		cur_mask = new_mask;
		    		umask(new_mask);
		    	}
	    	} else {
			    if (org_mask != cur_mask) {
		    		cur_mask = org_mask;
		    		umask(org_mask);
			    }
		    }
        }

		if (mkdir(path, mode) < 0) {
			if ((errno != EEXIST && errno != EISDIR)
			     || ((stat(path, &st) < 0) || !S_ISDIR(st.st_mode))) {
                 break;
		    }

			if (!c) {
			    retval = 0;
			    goto ret;
			}
		}
		*s = c;
	}

	retval = -1;

 ret:
	if (org_mask != cur_mask)
		umask(org_mask);
	return retval;
}

int file_Copy (const char * src, const char * dest)
{
    struct stat src_stat;

    int result = stat(src, &src_stat);

    if (result != 0){
        return UC_NOT_FOUND;
    }

    if (!S_ISREG(src_stat.st_mode)){
    	return UC_FAULT;
    }

    int readFd;
    int writeFd;

    readFd = open(src, O_RDONLY);

    if (readFd < 0){
        return UC_FAULT;
    }

    writeFd = creat(dest, src_stat.st_mode);

    if (writeFd < 0)
    {
        close(readFd);
        return UC_FAULT;
    }

    ssize_t written = 0;
    off_t offset = 0;
    result = UC_OK;

    while (written < src_stat.st_size)
    {
        ssize_t written_size = sendfile(writeFd, readFd,
        		                        &offset,
                                        src_stat.st_size - written);

        if (written_size == -1)
        {
            UC_FAULT("Error when copying file '%s' to '%s'", src, dest);
            result = UC_FAULT;
            break;
        }

        written += written_size;
    }

    close(readFd);
    close(writeFd);

    return result;
}

static char* malloc_readlink(const char *path) {
    char *buf = NULL;
    int bufsize = 0, readsize = 0;

    do {
    	bufsize += 96;
    	buf = realloc(buf, bufsize);
        readsize = readlink(path, buf, bufsize);
    	if (readsize == -1) {
    		free(buf);
    		return NULL;
    	}
    } while (bufsize < readsize + 1);

    buf[readsize] = '\0';

    return buf;
}

int file_Rescopy(const char * source, const char * dest)
    {
    	/* This is a recursive function, try to minimize stack usage */
    	struct stat source_stat;
    	struct stat dest_stat;
    	int retval = 0;
    	int dest_exists = 0;

    	if (lstat(source, &source_stat) < 0) {
    		return -1;
    	}

    	if (lstat(dest, &dest_stat) < 0) {
    		if (errno != ENOENT) {
    			return -1;
    		}
    	} else {
    		if (source_stat.st_dev == dest_stat.st_dev
    		    && source_stat.st_ino == dest_stat.st_ino
    		) {
    			return -1;
    		}
    		dest_exists = 1;
    	}

    	if (S_ISDIR(source_stat.st_mode)) {
    		mode_t saved_umask = 0;

    		if (dest_exists) {
    			if (!S_ISDIR(dest_stat.st_mode)) {
    				return -1;
    			}
    		} else {
    			mode_t mode;
    			saved_umask = umask(0);
				mode = source_stat.st_mode & ~saved_umask;
    			mode |= S_IRWXU;
    			if (mkdir(dest, mode) < 0) {
    				umask(saved_umask);
    				return -1;
    			}
    			umask(saved_umask);

    			if (lstat(dest, &dest_stat) < 0) {
    				return -1;
    			}
    		}

    		DIR *dp;
    		struct dirent *d;

    		dp = opendir(source);
    		if (dp == NULL) {
    			retval = -1;
    			goto exit;
    		}

    		while ((d = readdir(dp)) != NULL) {
    			char *new_source, *new_dest;

    			if (DOT_OR_DOTDOT(d->d_name) ||
					asprintf(&new_source, "%s/%s", source, d->d_name) < 0)
    				continue;
    			if (asprintf(&new_dest, "%s/%s", dest, d->d_name) < 0)
    				continue;
    			if (file_Rescopy (new_source, new_dest) < 0)
    				retval = -1;
    			free(new_source);
    			free(new_dest);
    		}
    		closedir(dp);

    		goto exit;
    	}

    	if (S_ISREG(source_stat.st_mode)) {
    		if (S_ISLNK(source_stat.st_mode)) {
    			goto dont_copy;
    		}

            retval = file_Copy(source, dest);

    		if (!S_ISREG(source_stat.st_mode))
    			return retval;
    	}
     dont_copy:

    	if (dest_exists) {
    		errno = EEXIST;
    		if (unlink(dest) <= 0)
    			return -1;
    	}
    	if (S_ISLNK(source_stat.st_mode)) {
    		char *link_path = malloc_readlink(source);
    		if (link_path) {
    			int r = symlink(link_path, dest);
    			if (r < 0) {
    				free(link_path);
    				return -1;
    			}
    			free(link_path);
    		}

    		goto exit;
    	}
    	if (S_ISBLK(source_stat.st_mode) || S_ISCHR(source_stat.st_mode)
    	 || S_ISSOCK(source_stat.st_mode) || S_ISFIFO(source_stat.st_mode)
    	) {
    		if (mknod(dest, source_stat.st_mode, source_stat.st_rdev) < 0) {
    			return -1;
    		}
    	} else {
    		return -1;
    	}

exit:
	 {
		struct timeval times[2];

		times[1].tv_sec = times[0].tv_sec = source_stat.st_mtime;
		times[1].tv_usec = times[0].tv_usec = 0;

		utimes(dest, times);
		chmod(dest, source_stat.st_mode);
		if (chown(dest, source_stat.st_uid, source_stat.st_gid) < 0) {
			source_stat.st_mode &= ~(S_ISUID | S_ISGID);
		}
	 }

    	return retval;
    }

int file_Remove(const char *path)
{
	struct stat path_stat;

	if (lstat(path, &path_stat) < 0) {
        return -1;
	}

	if (S_ISDIR(path_stat.st_mode)) {
		DIR *dp;
		struct dirent *d;
		int status = 0;

		dp = opendir(path);
		if (dp == NULL) {
			return -1;
		}

		while ((d = readdir(dp)) != NULL) {
			char *new_path;

			if (DOT_OR_DOTDOT(d->d_name) ||
                asprintf(&new_path, "%s/%s", path, d->d_name) < 0)
				continue;
			if (file_Remove (new_path) < 0)
				status = -1;
			free(new_path);
		}

		if (closedir(dp) < 0) {
			return -1;
		}

		if (rmdir(path) < 0) {
			return -1;
		}
		return status;
	}

	if (unlink(path) < 0) {
		return -1;
	}

	return 0;
}

off_t get_file_size(int fd) {
    struct stat st;

    if (fstat(fd, &st) == 0) {
    	return st.st_size;
    } else {
    	return 0;
    }
}

int fs_is_mounted (const char * name, const char * path)
{
    /* Open /proc/mounts file to check where all the mounts are */
	int retval = 0;
    FILE * mount_file = setmntent("/proc/mounts", "r");
    if (mount_file == NULL) {
    	retval = -1;
    	goto err;
    }

    char buf[PATH_MAX * 2];
    struct mntent mnt_entry;

    while (getmntent_r(mount_file, &mnt_entry, buf, PATH_MAX * 2) != NULL)
    {
        if ( (strcmp(name, mnt_entry.mnt_fsname) == 0) &&
             (strcmp(path, mnt_entry.mnt_dir) == 0) )
        {
        	retval = 1;
            break;
        }
    }

err:
    endmntent(mount_file);

    return retval;
}

