/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

#ifndef CGROUP__H
#define CGROUP__H

#ifdef __cplusplus
extern "C"
{
#endif

#include "uC.h"

typedef enum
{
    CGRP_SUBSYS_CPU = 0,
    CGRP_SUBSYS_MEM,
    CGRP_NUM_SUBSYSTEMS
}cgrp_SubSys_t;

/*
 * Initializes cgroups for the system.
 */
//--------------------------------------------------------------------------------------------------
void cgrp_Init
(
    void
);

/*
 * Creates a cgroup with the specified name in the specified sub-system.  If the cgroup already
 * exists this function has no effect.
 *
 * @param[in] subsystem  Sub-system the cgroup belongs to
 * @param[in] cgroup_name_ptr  Name of the cgroup to create
 *
 * @return OK if successful.FAULT if there was some other error
 */

uc_err_t cgrp_Create
(
    cgrp_SubSys_t subsystem,
    const char* cgroup_name_ptr
);

/*
 * Adds a process to a cgroup.
 *
 * @param[in] subsystem  Sub-system of the cgroup
 * @param[in] cgroup_name_ptr  Name of the cgroup to add the process to
 * @param[in] pid  PID of the process to add
 *
 * @return OK if successful. OUT_OF_RANGE if the process doesn't exist.
 *         LE_FAULT if there was some other error.
 */

uc_err_t cgrp_AddProc
(
    cgrp_SubSys_t subsystem,
    const char* cgroup_name_ptr,
    pid_t pid
);

/*
 * Gets a list of threads that are in a cgroup.
 *
 * @param[in] subsystem  Sub-system of the cgroup
 * @param[in] cgroup_name_ptr  Name of the cgroup
 * @param[out] tid_list_ptr  Buffer that will contain the list of TIDs
 * @param[in] max_tids  The maximum number of tids can hold
 *
 * @return
 *      The number of threads that are in the cgroup if successful.
 *      LE_FAULT if there was some other error.
 */

ssize_t cgrp_GetThreadList
(
    cgrp_SubSys_t subsystem,
    const char* cgroup_name_ptr,
    pid_t* tid_list_ptr,
    size_t max_tids
);

/*
 * Gets a list of threads that are in a cgroup.
 *
 * @param[in] subsystem  Sub-system of the cgroup
 * @param[in] cgroup_name_ptr  Name of the cgroup
 * @param[out] id_list_ptr  Buffer that will contain the list of TIDs
 * @param[in] max_tids  The maximum number of tids can hold
 *
 * @return
 *      The number of threads that are in the cgroup if successful.
 *      FAULT if there was some other error.
 */
//--------------------------------------------------------------------------------------------------
ssize_t cgrp_GetProcessesList
(
    cgrp_SubSys_t subsystem,
    const char* cgroup_name_ptr,
    pid_t* id_list_ptr,
    size_t max_ids
);

/*
 * Sends the specified signal to all the processes in the specified cgroup.
 *
 * @param[in] subsystem  Sub-system of the cgroup
 * @param[in] cgroup_name_ptr  Name of the cgroup
 * @param[in] sig  The signal to send
 *
 * @return The number of PIDs that are in the cgroup. FAULT if there an error.
 */

ssize_t cgrp_SendSig
(
    cgrp_SubSys_t subsystem,
    const char* cgroup_name_ptr,
    int sig
);

/*
 * Checks if the specified cgroup is empty of all processes.
 *
 * @param[in] subsystem  Sub-system of the cgroup
 * @param[in] cgroup_name_ptr  Name of the cgroup
 *
 * @return
 *      true if the specified cgroup has no processes in it.
 *      false if there are processes in the specified cgroup.
 */

int cgrp_IsEmpty
(
    cgrp_SubSys_t subsystem,
    const char* cgroup_name_ptr
);

/*
 * Deletes a cgroup.
 *
 * @param[in] subsystem  Sub-system of the cgroup
 * @param[in] cgroup_name_ptr  Name of the cgroup to delete
 *
 * @return OK if the cgroup was successfully deleted. BUSY if the cgroup could
 *         not be deleted because there are still processes in the cgroup.
 *         FAULT if there was some other error.
 */

uc_err_t cgrp_Delete
(
    cgrp_SubSys_t subsystem,
    const char* cgroup_name_ptr
);

/*
 * Gets the name of sub-system.
 *
 * @param[in] subsystem  Sub-system tag
 *
 * @return The name of the sub-system.
 */

const char* cgrp_SubSysName
(
    cgrp_SubSys_t subsystem
);

/*
 * Sets the cpu share of a cgroup.
 *
 * Cpu share is used to calculate the cpu percentage for a process relative to all other processes
 * in the system. Refer Linux kernel doc Documentation/cgroups/cpu.txt
 *
 * @param[in] cgroup_name_ptr  Name of the cgroup to set the share for
 * @param[in] share  Share value to set
 *
 *
 * @return OK if successful. FAULT if there was an error.
 */

uc_err_t cgrp_cpu_SetShare
(
    const char* cgroup_name_ptr,
    size_t share
);

/*
 * Sets the memory limit for a cgroup.
 *
 * @param[in] cgroup_name_ptr  Name of the cgroup to set the limit for
 * @param[in] limit  Memory limit in kilobytes
 *
 * @return OK if successful. FAULT if there was an error.
 */

uc_err_t cgrp_mem_SetLimit
(
    const char* cgroup_name_ptr,
    size_t limit
);

/*
 * Gets the amount of memory used in bytes by a cgroup
 *
 * @param[in] cgroup_name_ptr  Name of the cgroup
 *
 * @return Number of bytes in use by the cgroup. FAULT if there was an error.
 */

ssize_t cgrp_GetMemUsed
(
    const char* cgroup_name_ptr
);

/*
 * Gets the imum amount of memory used in bytes by a cgroup.
 *
 * @param[in] cgroup_name_ptr Name of the cgroup
 *
 * @return Maximum number of bytes used at any time up to now by this cgroup.
 *         FAULT if there was an error.
 */

ssize_t cgrp_GetMaxMemUsed
(
    const char* cgroup_name_ptr
);

#ifdef __cplusplus
}
#endif

#endif
