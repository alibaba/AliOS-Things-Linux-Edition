/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sched.h>
#include <sys/mount.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>

#include <net/if_arp.h>
#include <net/if.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/if_link.h>
#include <linux/if_addr.h>
#include <linux/veth.h>
#include <sys/socket.h>

#include "uC.h"
#include "libnetwork.h"

#define NLMSG_TAIL(nmsg) \
	((struct rtattr *)(((void *) (nmsg)) + NLMSG_ALIGN((nmsg)->nlmsg_len)))

struct link_req_if {
	struct nlmsghdr n;
	struct ifinfomsg i;
	char   buf[1024];
};

struct link_req_addr {
	struct nlmsghdr n;
	struct ifaddrmsg a;
	char   buf[1024];
};

struct link_req_rt {
	struct nlmsghdr n;
	struct rtmsg r;
	char   buf[1024];
};

static int addattr_l(struct nlmsghdr *n, int maxlen, int type, const void *data,
	      	  	  	 int alen) {
	int len = RTA_LENGTH(alen);
	struct rtattr * rta;

	if (NLMSG_ALIGN(n->nlmsg_len) + RTA_ALIGN(len) > maxlen) {
		UC_FAULT("addattr_l ERROR: message exceeded bound of %d",maxlen);
		return UC_FAULT;
	}
	rta = NLMSG_TAIL(n);
	rta->rta_type = type;
	rta->rta_len = len;
	memcpy(RTA_DATA(rta), data, alen);
	n->nlmsg_len = NLMSG_ALIGN(n->nlmsg_len) + RTA_ALIGN(len);
	return UC_OK;
}

static int netlink_Open() {
	socklen_t addr_len;
	struct sockaddr_nl nl_addr;
	int    fd;

	fd = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
	if (fd < 0) {
		UC_FAULT("Cannot open netlink socket");
		return UC_FAULT;
	}

	memset(&nl_addr, 0, sizeof(nl_addr));
	nl_addr.nl_family = AF_NETLINK;
	nl_addr.nl_groups = 0;

	if (bind(fd, (struct sockaddr *)&nl_addr, sizeof(nl_addr)) < 0) {
		UC_FAULT("Cannot bind netlink socket");
		close(fd);
		return UC_FAULT;
	}
	addr_len = sizeof(nl_addr);
	if (getsockname(fd, (struct sockaddr *)&nl_addr, &addr_len) < 0) {
		UC_FAULT("Cannot getsockname");
		close(fd);
		return UC_FAULT;
	}
	if (addr_len != sizeof(nl_addr)) {
		UC_FAULT("Wrong address length %d", addr_len);
		close(fd);
		return UC_FAULT;
	}
	if (nl_addr.nl_family != AF_NETLINK) {
		UC_FAULT("Wrong address family %d", nl_addr.nl_family);
		close(fd);
		return UC_FAULT;
	}

	return fd;
}

static int netlink_Send(int fd, void * req, size_t len) {
	struct iovec iov = {
		.iov_base = (void*) req,
		.iov_len = len
	};

	struct sockaddr_nl nladdr;

	memset(&nladdr, 0, sizeof(nladdr));
	nladdr.nl_family = AF_NETLINK;
	nladdr.nl_pid = 0;
	nladdr.nl_groups = 0;

	struct msghdr msg = {
		.msg_name = &nladdr,
		.msg_namelen = sizeof(nladdr),
		.msg_iov = &iov,
		.msg_iovlen = 1,
	};

	int status = sendmsg(fd, &msg, 0);

	if (status < 0) {
		UC_FAULT("Cannot talk to rtnetlink");
		return UC_FAULT;
	}

	return UC_OK;
}

int bridge_Add(char * bridge_name){
	struct link_req_if req;

	if (bridge_name == NULL){
		return UC_FAULT;
	}

	int fd = netlink_Open();

	if (fd < 0) {
		return UC_FAULT;
	}

	memset(&req, 0, sizeof(req));
	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.n.nlmsg_flags = NLM_F_REQUEST|NLM_F_CREATE|NLM_F_EXCL;
	req.n.nlmsg_type = RTM_NEWLINK;
	req.i.ifi_family = AF_UNSPEC;

	addattr_l(&req.n, sizeof(req), IFLA_IFNAME, bridge_name, strlen(bridge_name));
	struct rtattr *linkinfo = NLMSG_TAIL(&req.n);
	addattr_l(&req.n, sizeof(req), IFLA_LINKINFO, NULL, 0);
	addattr_l(&req.n, sizeof(req), IFLA_INFO_KIND, "bridge", strlen("bridge"));
	linkinfo->rta_len = (void *)NLMSG_TAIL(&req.n) - (void *)linkinfo;

	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	} else {
	    close(fd);
	    return UC_OK;
	}
}

int veth_Add(char * veth_name1, char * veth_name2) {
	struct link_req_if req;

	if (veth_name1 == NULL || veth_name2 == NULL)
		return UC_FAULT;

	int fd = netlink_Open();

	if (fd < 0) {
		return UC_FAULT;
	}

	memset(&req, 0, sizeof(req));

	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.n.nlmsg_flags = NLM_F_REQUEST|NLM_F_CREATE|NLM_F_EXCL;
	req.n.nlmsg_type = RTM_NEWLINK;
	req.i.ifi_family = AF_UNSPEC;

	addattr_l(&req.n, sizeof(req), IFLA_IFNAME, veth_name1, strlen(veth_name1));
	struct rtattr *linkinfo = NLMSG_TAIL(&req.n);
	addattr_l(&req.n, sizeof(req), IFLA_LINKINFO, NULL, 0);
	addattr_l(&req.n, sizeof(req), IFLA_INFO_KIND, "veth", strlen("veth"));

	struct rtattr * data = NLMSG_TAIL(&req.n);
	addattr_l(&req.n, sizeof(req), IFLA_INFO_DATA, NULL, 0);

	struct rtattr * linkpeer = NLMSG_TAIL(&req.n);
	addattr_l(&req.n, sizeof(req), VETH_INFO_PEER, NULL, 0);
	req.n.nlmsg_len += sizeof(struct ifinfomsg);

	struct ifinfomsg * ifm = RTA_DATA(linkpeer);
	ifm->ifi_family = AF_UNSPEC;

	addattr_l(&req.n, sizeof(req), IFLA_IFNAME, veth_name2, strlen(veth_name2));
	linkpeer->rta_len = (void *)NLMSG_TAIL(&req.n) - (void *)linkpeer;

	data->rta_len = (void *)NLMSG_TAIL(&req.n) - (void *)data;
	linkinfo->rta_len = (void *)NLMSG_TAIL(&req.n) - (void *)linkinfo;

	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	} else {
	    close(fd);
	    return UC_OK;
	}
}

int netns_Add (char * netns_name) {
	char path[128];

	if (mkdir("/run/netns", S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH) < 0)
		return UC_FAULT;

	int pid = syscall(__NR_clone, CLONE_NEWNET | SIGCHLD, NULL);

	if (pid == 0){
		snprintf(path, sizeof(path), "/run/netns/%s", netns_name);
		int fd = creat(path, S_IRUSR | S_IRGRP | S_IROTH);
		if (fd < 0) {
			UC_FAULT("create netns file failed");
			exit(UC_FAULT);
		}

		close(fd);

		if (mount("/proc/self/ns/net", path, "none", MS_BIND, NULL) != 0) {
		  UC_FAULT("bind netns file failed");
		  exit(UC_FAULT);
		}
		exit(1);
	}

	waitpid(pid, NULL, 0);

	return UC_OK;
}

int netns_Remove (char * netns_name) {
	char path[PATH_MAX];

	snprintf(path, sizeof(path), "/run/netns/%s", netns_name);
	if (umount2(path, MNT_DETACH) < 0) {
		UC_FAULT("remove netns failed");
		return UC_FAULT;
	}

	return UC_OK;
}

int link_Setup (char * link_name, char * link_ops) {
	struct link_req_if req;

	if (link_name == NULL)
		return UC_FAULT;

	int fd = netlink_Open();

	if (fd < 0) {
		return UC_FAULT;
	}

	memset(&req, 0, sizeof(req));

	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.n.nlmsg_flags = NLM_F_REQUEST;
	req.n.nlmsg_type = RTM_SETLINK;
	req.i.ifi_family = AF_UNSPEC;

	addattr_l(&req.n, sizeof(req), IFLA_IFNAME, link_name, strlen(link_name));

	/* link up */
	if (strncmp(link_ops, "up", strlen("up")) == 0) {
		req.i.ifi_change |= IFF_UP;
		req.i.ifi_flags |= IFF_UP;
	} else if (strncmp(link_ops, "up", strlen("up")) == 0) {
		req.i.ifi_change |= IFF_UP;
		req.i.ifi_flags &= ~IFF_UP;
	} else {
		close(fd);
		return UC_FAULT;
	}


	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	} else {
	    close(fd);
	    return UC_OK;
	}
}

int link_Remove(char * link_name){
	struct link_req_if req;

	if (link_name == NULL)
		return UC_FAULT;

	int fd = netlink_Open();

	if (fd < 0) {
		return UC_FAULT;
	}

	memset(&req, 0, sizeof(req));

	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.n.nlmsg_flags = NLM_F_REQUEST;
	req.n.nlmsg_type = RTM_DELLINK;
	req.i.ifi_family = AF_UNSPEC;

	addattr_l(&req.n, sizeof(req), IFLA_IFNAME, link_name, strlen(link_name));

	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	} else {
	    close(fd);
	    return UC_OK;
	}
}

int netns_Join(char * link_name, int netns_fd) {
	struct link_req_if req;

	if (link_name == NULL)
		return UC_FAULT;

	int fd = netlink_Open();

	if (fd < 0){
		return UC_FAULT;
	}

	memset(&req, 0, sizeof(req));

	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.n.nlmsg_flags = NLM_F_REQUEST;
	req.n.nlmsg_type = RTM_SETLINK;
	req.i.ifi_family = AF_UNSPEC;
	req.i.ifi_index = if_nametoindex(link_name);
	req.i.ifi_change |= IFF_UP;
	req.i.ifi_flags |= IFF_UP;

	addattr_l(&req.n, sizeof(req), IFLA_NET_NS_FD, &netns_fd, 4);

	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	} else {
	    close(fd);
	    return UC_OK;
	}
}

int bridge_Connect(char * bridge_name, char * link_name){
	struct link_req_if req;

	if (bridge_name == NULL || link_name == NULL)
		return UC_FAULT;

	int fd = netlink_Open();

	if (fd < 0) {
		return UC_FAULT;
	}

	memset(&req, 0, sizeof(req));

	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
	req.n.nlmsg_flags = NLM_F_REQUEST;
	req.n.nlmsg_type = RTM_SETLINK;
	req.i.ifi_family = AF_UNSPEC;

	/* link up */
	req.i.ifi_change |= IFF_UP;
	req.i.ifi_flags |= IFF_UP;

	unsigned int if_index = if_nametoindex(bridge_name);

	addattr_l(&req.n, sizeof(req), IFLA_IFNAME, link_name, strlen(link_name));
	addattr_l(&req.n, sizeof(req), IFLA_MASTER, (void *)&if_index, sizeof(unsigned int));

	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	} else {
	    close(fd);
	    return UC_OK;
	}
}

int route_Add(void * dest, void * gateway, int netmask, char * link_name)
{
	struct link_req_rt req;
	in_addr_t          dst, gw;

    int fd = netlink_Open();

    memset(&req, 0, sizeof(req));
    req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct rtmsg));
    req.n.nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL;
    req.n.nlmsg_type = RTM_NEWROUTE;

    req.r.rtm_family = AF_INET;
    req.r.rtm_table = RT_TABLE_MAIN;
    req.r.rtm_protocol = RTPROT_BOOT;
    req.r.rtm_scope = RT_SCOPE_UNIVERSE;
    req.r.rtm_type = RTN_UNICAST;
    req.r.rtm_dst_len = netmask;
    //req.r.rtm_flags = RT_TABLE_MAIN;

    int index = if_nametoindex(link_name);
    dst = inet_addr(dest);
    addattr_l(&req.n, sizeof(req), RTA_DST, &dst, sizeof(dst));
    gw = inet_addr(gateway);
    addattr_l(&req.n, sizeof(req), RTA_GATEWAY, &gw, sizeof(gw));
    addattr_l(&req.n, sizeof(req), RTA_OIF, &index, sizeof(index));

	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	} else {
	    close(fd);
	    return UC_OK;
	}
}

int set_link_ipv4_addr(char * link_name, void * ip, int mask_len) {
	struct link_req_addr req;
	in_addr_t addr, bcast;

	if (link_name == NULL || ip == NULL || mask_len > 32)
		return UC_FAULT;

	int fd = netlink_Open();

	if (fd < 0) {
		return UC_FAULT;
	}

	memset(&req, 0, sizeof(req));
	/* delete address */
	req.n.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifaddrmsg));
	req.n.nlmsg_type = RTM_DELADDR;
	req.n.nlmsg_flags = NLM_F_REQUEST;
	req.a.ifa_family = AF_INET;
	req.a.ifa_index = if_nametoindex(link_name);

	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	}

	/* add new address */
	req.n.nlmsg_type = RTM_NEWADDR;
	req.n.nlmsg_flags = NLM_F_CREATE | NLM_F_EXCL | NLM_F_REQUEST;
	req.a.ifa_prefixlen = mask_len;

	addr = inet_addr(ip);
	addattr_l(&req.n, sizeof(req), IFA_LOCAL, &addr, sizeof(addr));

	bcast = addr | htonl((1 << (32 - mask_len)) - 1);
	addattr_l(&req.n, sizeof(req), IFA_BROADCAST, &bcast, sizeof(bcast));

	if (netlink_Send(fd, &req, req.n.nlmsg_len) < 0){
	    close(fd);
	    return UC_FAULT;
	} else {
	    close(fd);
	    return UC_OK;
	}
}
