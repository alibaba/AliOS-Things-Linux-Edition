/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <limits.h>
#include <sys/mount.h>

#include "fsutils.h"
#include "cgroup.h"


static const char* SubSysName[CGRP_NUM_SUBSYSTEMS] = {"cpu,cpuacct", "memory"};

#define ROOT_PATH                   "/sys/fs/cgroup"
#define ROOT_NAME                   "cgroups_root"

static int SubSys_is_Mounted (void)
{
    cgrp_SubSys_t subSys = 0;

    for (; subSys < CGRP_NUM_SUBSYSTEMS; subSys++)
    {
        char dir[PATH_MAX];
        snprintf(dir, sizeof(dir),ROOT_PATH"/%s", SubSysName[subSys]);

        if (!fs_is_mounted(SubSysName[subSys], dir)){
            return UC_FAULT;
        }
    }

    return UC_OK;
}

static void SubSys_Mount (void)
{
    cgrp_SubSys_t subSys = 0;
    for (; subSys < CGRP_NUM_SUBSYSTEMS; subSys++)
    {
        char dir[PATH_MAX];
        snprintf(dir, sizeof(dir),ROOT_PATH"/%s/", SubSysName[subSys]);

        dir_Create(dir, S_IRWXU);

        if (mount(SubSysName[subSys], dir, "cgroup", 0, SubSysName[subSys]) != 0)
              UC_INFO("Can not mount cgroup subsystem '%s'", SubSysName[subSys]);

        UC_INFO("Mounted cgroup hierarchy for subsystem '%s'", SubSysName[subSys]);
    }
}

void cgrp_Init (void)
{
    if (fs_is_mounted(ROOT_NAME, ROOT_PATH) == 0) {
        if (mount(ROOT_NAME, ROOT_PATH, "tmpfs", 0, NULL) !=0) {
        	UC_FAULT("Could not mount cgroup root file system");
            return;
        }

        SubSys_Mount();
    } else {
        if (!SubSys_is_Mounted()){
            SubSys_Mount();
        }
    }
}

static int open_cgrp_file (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr, const char* fileNamePtr, int accessMode)
{
    // Create the path to the cgroup file.
    char path[PATH_MAX];
    snprintf(path, sizeof(path),ROOT_PATH"/%s/%s/%s", SubSysName[subsystem], cgroup_name_ptr, fileNamePtr);

    // Open the cgroup file.
    int fd;

    do{
        fd = open(path, accessMode);
    } while ((fd < 0) && (errno == EINTR));

    if (fd < 0){
        UC_FAULT("Could not open file '%s'.", path);
    }

    return fd;
}

static uc_err_t cgrp_file_Write (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr, const char* fileNamePtr, const char* string)
{
    // Get the length of the string.
    size_t len = strlen(string);

    // Open the file.
    int fd = open_cgrp_file(subsystem, cgroup_name_ptr, fileNamePtr, O_WRONLY);

    if (fd < 0){
        return UC_FAULT;
    }

    // Write the string to the file.
    uc_err_t retval = 0;
    ssize_t numBytesWritten = UC_OK;

    do{
        numBytesWritten = write(fd, string, len);
    }
    while ((numBytesWritten == -1) && (errno == EINTR));

    if (numBytesWritten != len){
        if (errno == ESRCH){
        	retval = UC_NOT_FOUND;
        }
        else{
        	retval = UC_FAULT;
        }
    }

    close(fd);

    return retval;
}

static uc_err_t GetValue (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr, const char* file_name_ptr, char* bufPtr, size_t bufSize)
{
    // Open the file.
    int fd = open_cgrp_file(subsystem, cgroup_name_ptr, file_name_ptr, O_RDONLY);

    if (fd < 0) {
        return UC_FAULT;
    }

    // Read the value from the file.
    ssize_t numBytesRead;

    do {
        numBytesRead = read(fd, bufPtr, bufSize);
    }
    while ( (numBytesRead == -1) && (errno == EINTR) );

    uc_err_t retval = UC_FAULT;

    // Check if the read value is valid.
    if (numBytesRead == UC_FAULT) {
    	UC_FAULT("Could not read file '%s' in cgroup '%s'.", file_name_ptr, cgroup_name_ptr);
        retval = UC_FAULT;
    } else if (numBytesRead == bufSize) {
        // The value in the file is larger than the provided buffer.  Truncate the buffer.
        bufPtr[bufSize-1] = '\0';
        retval = UC_FAULT;
    } else if ((numBytesRead >= 0) && (numBytesRead < bufSize)) {
        // Null-terminate the string.
        bufPtr[numBytesRead] = '\0';

        // Remove trailing newline characters.
        while ((numBytesRead > 0) && (bufPtr[numBytesRead - 1] == '\n')) {
            numBytesRead--;
            bufPtr[numBytesRead] = '\0';
        }

        retval = UC_OK;
    }

    close(fd);

    return retval;
}

static pid_t GetTasksId (int fd)
{
    // Read a pid from the file.
    pid_t pid;
    char pidStr[100];
    int retval = read(fd, pidStr, sizeof(pidStr));

    if (retval > 0) {
        pid = atoi(pidStr);

        return pid;
    }

    return UC_FAULT;
}

uc_err_t cgrp_Create (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr)
{
    char dir[PATH_MAX];
    snprintf(dir, sizeof(dir),ROOT_PATH"/%s/%s", SubSysName[subsystem], cgroup_name_ptr);

    // Create the cgroup.
    uc_err_t result = dir_Create (dir, S_IRWXU);

    if (result == -3) {
    	UC_FAULT("cgroup %s already exists", dir);
        return -3;
    } else if (result == UC_FAULT) {
    	UC_FAULT("could not create cgroup %s", dir);
        return UC_FAULT;
    }

    return UC_OK;
}

uc_err_t cgrp_AddProc (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr, pid_t pid)
{
    // Convert the pid to a string.
    char pidStr[16];

    if (snprintf(pidStr, sizeof(pidStr), "%d", pid) < 0){
    	return UC_FAULT;
    };

    // Write the pid to the file.
    return cgrp_file_Write(subsystem, cgroup_name_ptr, "cgroup.procs", pidStr);
}

static ssize_t BuildTidList (int fd, pid_t* id_list_ptr, size_t max_ids)
{
    // Read the pids from the file.
    size_t numTids = 0;

    while (1) {
        pid_t tid = GetTasksId(fd);

        if (tid >= 0) {
            numTids++;

            if (numTids <= max_ids) {
            	id_list_ptr[numTids-1] = tid;
            }
        } else if (tid == UC_NOT_FOUND) {
            break;
        } else {
            return UC_FAULT;
        }
    }
    return numTids;
}

ssize_t cgrp_GetThreadList (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr, pid_t* tid_list_ptr, size_t max_tids)
{
    // Open the cgroup's tasks file for reading.
    int fd = open_cgrp_file(subsystem, cgroup_name_ptr, "tasks", O_RDONLY);

    if (fd < 0) {
        return UC_FAULT;
    }

    size_t numTids = BuildTidList(fd, tid_list_ptr, max_tids);

    close(fd);

    if (numTids == UC_FAULT) {
    	UC_FAULT("Error reading the '%s' cgroup's tasks.", cgroup_name_ptr);
    }

    return numTids;
}

ssize_t cgrp_GetProcessesList (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr, pid_t* pid_list_ptr, size_t max_pids)
{
    int fd = open_cgrp_file(subsystem, cgroup_name_ptr, "cgroup.procs", O_RDONLY);

    if (fd < 0) {
        return UC_FAULT;
    }

    size_t numPids = BuildTidList(fd, pid_list_ptr, max_pids);

    if (numPids == UC_FAULT) {
    	UC_FAULT("Error reading the '%s' cgroup's tasks.", cgroup_name_ptr);
    }

    close(fd);

    return numPids;
}

uc_err_t GetProcessState (pid_t pid, char* pStatePtr)
{
    char procFile[PATH_MAX];
    if (snprintf(procFile, sizeof(procFile), "/proc/%d/status", pid) >= sizeof(procFile)) {
    	UC_FAULT("File name '%s...' size is too long.", procFile);
        return UC_FAULT;
    }

    int fd;

    do{
        fd = open(procFile, O_RDONLY);
    } while ( (fd == -1) && (errno == EINTR));

    if ( (fd == -1) && (errno == ENOENT)) {
        return UC_FAULT;
    }

    if(fd == -1) {
    	UC_FAULT("Could not read file %s.", procFile);
    	return UC_FAULT;
    }

    while (1) {
        char str[200] = {0};
        int retval = read(fd, str, sizeof(str));

        if (retval > 0) {
            if (strstr(str, "State:") == str)
            {
                char* procStateStrPtr = &(str[sizeof("State:")-1]);
                pStatePtr[0] = procStateStrPtr[1];
                pStatePtr[1] = '\0';
                close(fd);
                return UC_OK;
            }
        }
    }

    close(fd);
    return UC_FAULT;
}

ssize_t cgrp_SendSig (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr, int sig)
{
    // Open the cgroup's procs file for reading.
    int fd = open_cgrp_file(subsystem, cgroup_name_ptr, "cgroup.procs", O_RDONLY);

    if (fd < 0) {
        return UC_FAULT;
    }

    // Iterate over the pids in the procs file.
    size_t numPids = 0;
    pid_t prevPid = -1;

    while (1) {
        pid_t pid = GetTasksId(fd);

        if (pid >= 0) {
            char pState[2];
            if (GetProcessState(pid, pState) != 0) {
            	UC_INFO("Unable to get proc %d state", pid);
            }

            if (pid == prevPid) {
                if (strcmp(pState, "D") == 0) {
                    UC_INFO("Process %d is in '%s' state (uninterruptible sleep). Restarting device.",
                             pid, pState);
                }
            }

            numPids++;
            kill(pid, sig);
            prevPid = pid;
        } else if (pid == UC_NOT_FOUND){
            break;
        } else {
        	UC_FAULT("Error reading the '%s' cgroup's tasks.", cgroup_name_ptr);
            close(fd);
            return UC_FAULT;
        }
    }

    close(fd);
    return numPids;
}

int cgrp_IsEmpty (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr)
{
    // Open the cgroup's tasks file for reading.
    int fd = open_cgrp_file(subsystem, cgroup_name_ptr, "tasks", O_RDONLY);

    if (fd < 0) {
        return 1;
    }

    pid_t tid = GetTasksId(fd);
    close(fd);

    if (tid >= 0) {
        return 0;
    } else if (tid == -3) {
        return 1;
    } else {
    	UC_INFO("Error reading the '%s' cgroup's tasks.", cgroup_name_ptr);
        return 1;
    }
}

uc_err_t cgrp_Delete (cgrp_SubSys_t subsystem, const char* cgroup_name_ptr)
{
    // Create the path to the cgroup.
    char path[PATH_MAX];
    snprintf(path, sizeof(path),ROOT_PATH"/%s/%s", SubSysName[subsystem], cgroup_name_ptr);

    // Attempt to remove the cgroup directory.
    if (rmdir(path) != 0) {
        if (errno == EBUSY){
        	UC_INFO("Could not remove cgroup '%s'. Tasks (process) list may not be empty."
        			"After clean try again",
                     path);

        	if (cgrp_file_Write(subsystem, cgroup_name_ptr, "cgroup.procs", "") == UC_OK)
        		goto exit;

            return UC_FAULT;
        } else {
        	UC_FAULT("Could not remove cgroup '%s'.", path);
            return UC_FAULT;
        }
    }
exit:
    UC_INFO("Deleted cgroup %s.", path);

    return UC_OK;
}

const char* cgrp_SubSysName (cgrp_SubSys_t subsystem)
{
    return SubSysName[subsystem];
}

uc_err_t cgrp_cpu_SetShare (const char* cgroup_name_ptr, size_t share)
{
    // Convert the value to a string.
    char shareStr[96];
    snprintf(shareStr, sizeof(shareStr), "%zd", share);

    // Write the share value to the file.
    if (cgrp_file_Write(CGRP_SUBSYS_CPU, cgroup_name_ptr, "cpu.shares", shareStr) != UC_OK) {
        return UC_FAULT;
    }

    return UC_OK;
}

uc_err_t cgrp_mem_SetLimit (const char* cgroup_name_ptr, size_t limit)
{
    // Convert the limit to a string.
    char limitStr[96];

    if (snprintf(limitStr, sizeof(limitStr), "%zd", limit * 1024) > sizeof(limitStr)) {
    	UC_FAULT("limit string is too long..");
    	return UC_FAULT;
    }

    // Write the limit to the file.
    if (cgrp_file_Write(CGRP_SUBSYS_MEM, cgroup_name_ptr, "memory.limit_in_bytes", limitStr) != 0) {
        return UC_FAULT;
    }

    // Read the limit to see if it was set properly.
    char readLimitStr[96] = {0};

    if (GetValue(CGRP_SUBSYS_MEM,
                 cgroup_name_ptr,
                 "memory.limit_in_bytes",
                 readLimitStr,
                 sizeof(readLimitStr)) != 0)
    {
        return UC_FAULT;
    }

    if (strcmp(limitStr, readLimitStr) != 0){
        UC_INFO("The memory limit for %s was actually set to %s instead of %s", cgroup_name_ptr, readLimitStr, limitStr);
    }

    return UC_OK;
}

ssize_t cgrp_GetMemUsed (const char* cgroup_name_ptr)
{
    char buffer[32] = {0};
    ssize_t retval;

    if (GetValue(CGRP_SUBSYS_MEM,
                 cgroup_name_ptr,
                 "memory.memsw.usage_in_bytes",
                 buffer,
                 sizeof(buffer)) == 0)
    {
    	retval = strtol(buffer, NULL, 10);
        if ((errno == ERANGE) || (errno == EINVAL)) {
        	retval = UC_FAULT;
        }
    } else {
    	retval = UC_FAULT;
    }
    return retval;
}

ssize_t cgrp_GetMaxMemUsed (const char* cgroup_name_ptr)
{
    char buffer[32] = {0};
    ssize_t retval;

    if (GetValue(CGRP_SUBSYS_MEM,
                 cgroup_name_ptr,
                 "memory.memsw.max_usage_in_bytes",
                 buffer,
                 sizeof(buffer)) == 0)
    {
    	retval = strtol(buffer, NULL, 10);
        if ((errno == ERANGE) || (errno == EINVAL)) {
            retval = UC_FAULT;
        }
    } else {
    	retval = UC_FAULT;
    }
    return retval;
}

