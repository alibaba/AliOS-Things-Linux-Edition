/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

#ifndef UC__h
#define UC__h

#include <linux/types.h>
#include <unistd.h>
#include <uuid/uuid.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define UC_COMMAND  (1)
#define UC_ARGS		(1)
#define UC_PARAM(n) argv[n+1]

typedef enum{
	NET_NONE = 0,
	NET_HOST,
	NET_NAT
}net_setting_t;

#define UC_MESSAGE(type, fmt, ...) \
	do {						   \
		fprintf(stderr, "["#type"]"#fmt"\n", ##__VA_ARGS__); \
	}while(0)

#define UC_MSG
#ifdef UC_MSG
#define UC_FAULT(fmt, ...) \
	UC_MESSAGE(FAULT, fmt, ##__VA_ARGS__)

#define UC_WARN(fmt, ...) \
	UC_MESSAGE(WARN, fmt, ##__VA_ARGS__)

#define UC_INFO(fmt, ...) \
	UC_MESSAGE(INFO, fmt, ##__VA_ARGS__)
#else
#define UC_FAULT(fmt, ...)
#define UC_WARN(fmt, ...)
#define UC_INFO(fmt, ...)
#endif

typedef enum {
 UC_OK		= 0,
 UC_FAULT	= -1,
 UC_BUSY    = -2,
 UC_NOT_FOUND = -3,
 UC_IO_ERR  = -4
}uc_err_t;

typedef enum {
    oPull,
    oInit,
    oRun,
    oImages,
    oPs,
    oRm,
    oExec,
	oStop,
	oStart,
	oInvalid
} opcodes;

typedef enum {
    CG_VALUE_STRING = 1,
	CG_VALUE_INT64,
	CG_VALUE_UINT64,
	CG_VALUE_BOOL
} cg_value_type;

struct command{
    const char * name;
    opcodes opcode;
};

struct cg_setting {
	char * 		name;
	char * 		controller;
	char * 		attribute;
	int			value_type;
	char * 		value_string;
	int64_t		value_int64;
	u_int64_t	value_uint64;
	int   		value_bool;
	struct cg_setting * cg_next;
};

typedef struct {
	char * 		name;
	uuid_t 		uuid;
	char * 		hostname;
	int 		flags;
	int         gid;
	int         uid;
	pid_t       pid;
	char * 		rootfs_path;
	char *      mount_point;
	char ** 	command;
	char *      envp[24];
	char *      cwd;
	net_setting_t 		network_setting;
	struct cg_setting * cg_config;
	char *      image_name;
	char *		container_image;
	char * 		reserve[8];
}container;

#ifdef __cplusplus
}
#endif

#endif
