/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <curl/curl.h>

#include "uC.h"
#include "cJSON.h"

struct MemoryStruct {
  char *memory;
  size_t size;
};

static long long recv_count = 0;

void mfree(void * p) {
	void * t = (void *)(*(long *)p);
	free(t);
}

static size_t recv_file(void *ptr, size_t size, size_t nmemb, void * stream) {

	size_t written = fwrite(ptr, size, nmemb, (FILE *)stream);
	recv_count += written;
	printf("\033[1K\rReceived %12lld Bytes", recv_count);
	return written;
}

static size_t recv_data(void *contents, size_t size, size_t nmemb, void *userp)
{
	size_t realsize = size * nmemb;
	struct MemoryStruct *mem = (struct MemoryStruct *)userp;

	mem->memory = realloc(mem->memory, mem->size + realsize + 1);
	if(mem->memory == NULL) {
		/* out of memory! */
		UC_FAULT("not enough memory (realloc returned NULL)\n");
		return 0;
	}

	memcpy(&(mem->memory[mem->size]), contents, realsize);
	mem->size += realsize;
	mem->memory[mem->size] = 0;

	return realsize;
}

static int get_token(void * json_ptr, void * data) {
	cJSON * root = cJSON_Parse(json_ptr);

	if(root == NULL) return UC_FAULT;

	cJSON * item = cJSON_GetObjectItem(root,"token");

	strncpy((char *)data, item->valuestring, strlen(item->valuestring));

	cJSON_Delete(root);

	return UC_OK;
}

static int curl_http_download(char * url, struct curl_slist * header_list, void * data, void * func) {
  	CURL *   curl;
  	CURLcode res = CURLE_OK;

  	curl_global_init(CURL_GLOBAL_DEFAULT);

  	curl = curl_easy_init();
  	if (curl) {
  	  curl_easy_setopt(curl, CURLOPT_URL, url);
	  if (func != NULL)
   	  	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, func);
    	  curl_easy_setopt(curl, CURLOPT_WRITEDATA, data);
   	  if (header_list != NULL)
   		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, header_list);
	  curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);

   	  /* Perform the request, res will get the return code */
  	  res = curl_easy_perform(curl);
  	  /* Check for errors */
    	  if (res != CURLE_OK)
    	     UC_FAULT("curl_easy_perform() failed: %s\n",
            	     curl_easy_strerror(res));

    	  /* always cleanup */
    	  curl_easy_cleanup(curl);
  	}

  	curl_global_cleanup();

  	return res;
}

static int parse_manifest_and_download(char * json_string, char * image_name, char * token, char * target_path) {
	char * cmd;
	char * path;
	char * url;
   	char * header;
    struct curl_slist * header_list = NULL;
    int    ret = 0;
	cJSON *array_item, *blob_sum;

	cJSON * manifest = cJSON_Parse(json_string);

	if (manifest == NULL) {
		return UC_FAULT;
	}

	cJSON * item = cJSON_GetObjectItem(manifest, "fsLayers");

	if (item == NULL) {
		cJSON_Delete(manifest);
		return -1;
	}

    int array_size = cJSON_GetArraySize(item);

	for (int i = array_size - 1;i >= 0;i--) {
		array_item = cJSON_GetArrayItem(item, i);
		blob_sum = cJSON_GetObjectItem(array_item, "BlobSum");
		printf("\nLayer: %s\n", blob_sum->valuestring);

		if (asprintf(&header, "Authorization: Bearer %s", token) != -1) {
			header_list = NULL;
    		header_list = curl_slist_append(header_list, header);
    	}


		FILE * fp = NULL;
		if (asprintf(&path, "/tmp/%s", blob_sum->valuestring) != -1){
		unlink(path);
		fp = fopen(path, "wb+");
		if (fp == NULL)perror("open failed");
		}

		recv_count = 0;
		if (asprintf(&url, "https://registry-1.docker.io/v2/%s/blobs/%s", image_name, blob_sum->valuestring) != -1) {
			if (curl_http_download(url, header_list, fp, &recv_file) != CURLE_OK)
				ret = UC_FAULT;
			free(url);
		}
		if (fp != NULL)
		    fclose(fp);

		if (asprintf(&cmd,"tar -C %s -xf %s", target_path, path) != -1) {
			ret = system(cmd);
		}
		unlink(path);

		free(path);
		free(header);
		curl_slist_free_all(header_list);
	}

	cJSON_Delete(manifest);

	return ret;
}

int pull_image (char * image_name, char * target_dir) {
	char * token __attribute__((cleanup(mfree))) = (char *)malloc(8192);
	char * url = NULL;
	char * header = NULL;
	struct curl_slist * header_list = NULL;
	struct MemoryStruct chunk = {0};
    int    ret = 0;

    /* get token */
    if (asprintf(&url, "https://auth.docker.io/token?service=registry.docker.io&scope=repository:%s:pull", \
    		     image_name) != -1) {
    	curl_http_download(url, NULL, (void *)&chunk, &recv_data);
    	free(url);
    }

    get_token(chunk.memory, token);

    free(chunk.memory);
    memset(&chunk, 0, sizeof(struct MemoryStruct));

    if (asprintf(&header, "Authorization: Bearer %s", token) != -1){
    	header_list = curl_slist_append(header_list, header);

    	/* get manifest version 2 */
    	//header_list = curl_slist_append(header_list,
    	//		                        "Accept: application/vnd.docker.distribution.manifest.v2+json");
    }

    /* download fsLayer */
    if (asprintf(&url, "https://registry-1.docker.io/v2/%s/manifests/latest", image_name) != -1) {
    	curl_http_download(url, header_list, (void *)&chunk, &recv_data);
    	free(url);
    }

    curl_slist_free_all(header_list);

    ret = parse_manifest_and_download(chunk.memory, image_name, token, target_dir);

	if (ret >= 0) {
		printf("\nDownload complete\n");
	} else {
		printf("\nDownload failed\n");
	}

    free(chunk.memory);

    return ret;
}
