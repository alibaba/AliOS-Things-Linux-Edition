/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

#ifndef LIBNETWORK__H
#define LIBNETWORK__H

#ifdef __cplusplus
extern "C"
{
#endif

#include "uC.h"

int bridge_Add(char * bridge_name);
int veth_Add(char * veth_name1, char * veth_name2);
int netns_Add(char * netns_name);
int netns_Remove(char * netns_name);
int link_Setup(char * link_name, char * link_ops);
int link_Remove(char * link_name);
int netns_Join(char * link_name, int netns_fd);
int bridge_Connect(char * bridge_name, char * link_name);
int set_link_ipv4_addr(char * link_name, void * ip, int mask_len);
int route_Add(void * dest, void * gateway, int netmask, char * link_name);

#ifdef __cplusplus
}
#endif

#endif
