/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

#ifndef FSUTILS__H
#define FSUTILS__H

#ifdef __cplusplus
extern "C"
{
#endif

#include "uC.h"

#define LONE_DASH(s)     ((s)[0] == '-' && !(s)[1])
#define NOT_LONE_DASH(s) ((s)[0] != '-' || (s)[1])
#define LONE_CHAR(s,c)     ((s)[0] == (c) && !(s)[1])
#define NOT_LONE_CHAR(s,c) ((s)[0] != (c) || (s)[1])
#define DOT_OR_DOTDOT(s) ((s)[0] == '.' && (!(s)[1] || ((s)[1] == '.' && !(s)[2])))

off_t get_file_size(int fd);
int file_Remove(const char *path);
int dir_Create(char *path, long mode);
int file_Copy(const char * src, const char * dest);
int file_Rescopy(const char *source, const char *dest);
int fs_is_mounted (const char* Name, const char* path);

#ifdef __cplusplus
}
#endif

#endif
