/*
 * Copyright (C) 2017-2019 Alibaba Group Holding Limited
 */

/* include */
#define _GNU_SOURCE
#include <sched.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/mount.h>
#include <sys/syscall.h>

#include "cgroup.h"
#include "uC.h"
#include "cJSON.h"
#include "libnetwork.h"
#include "fsutils.h"

struct command command[] =
{
  {"pull",   oPull},
  {"init",   oInit},
  {"run",    oRun},
  {"images", oImages},
  {"ps",     oPs},
  {"rm",     oRm},
  {"exec",   oExec},
  {"stop",   oStop},
  {"start",  oStart}
};

/* defines */
#define UC_WORK_DIR  "/var/container"
#define OCI_VERSION  "1.0.0"

/* import */
extern int pull_image(char * image_name, char * target_dir);

void ptr_free(void * p) {
	free((void *)(*(unsigned long *)(p)));
}

void fd_close(void * fdp) {
	int fd = *(volatile int *)fdp;
	if (fd >= 0){
	    close(fd);
	}
}

static void usage() {
    printf("uContainer version 1.0.0\n\n"
           "Run a command in a light-weight container.\n\n"
     	   "usage: uContainer COMMAND\n\n"
           " create a container from an image:\n"
    	   " \tuContainer run -c <image> <command [argument...]>\n"
     	   " \tuContainer run --network <none | host | nat> - c <image> <command [argument...]>\n\n"
           " create an image from directory:\n"
    	   " \tuContainer init <directory>\n\n"
           " show exist container:\n"
    	   " \tuContainer ps\n\n"
           " download docker image\n"
    	   " \tuContainer pull <name>\n\n"
           " list exist images:\n"
    	   " \tuContainer images\n\n"
           " delete image or remove container\n"
    	   " \tuContainer rm <id>\n\n"
           " enter a container and run a command\n"
    	   " \tuContainer exec <id> <command [argument...]>\n\n"
           " start a stopped container\n"
    	   " \tuContainer start <id>\n\n");

    exit(UC_OK);
}

static void gen_uuid(uuid_t uuid, char * short_uuid) {
	uuid_t id;
	char uuidstr[64];

	uuid_generate_random(id);
	uuid_unparse(id, uuidstr);
	if (short_uuid != NULL)
		strncpy(short_uuid, strtok(uuidstr, "-"), 9);
	if (uuid != NULL)
		memcpy(uuid, id, 16);
}

static char * get_workdir()
{
	return UC_WORK_DIR;
}

static uc_err_t create_network(container * pContainer) {
	char * name1 __attribute__((cleanup(ptr_free)));
	char * name2 __attribute__((cleanup(ptr_free)));

	asprintf(&name1, "veth0_%s", pContainer->name);
    asprintf(&name2, "veth1_%s", pContainer->name);

	if (veth_Add(name1, name2) < 0) {
		return UC_FAULT;
	}

	if (bridge_Connect("bridge0", name1) < 0) {
		return UC_FAULT;
	}

	if (netns_Add(pContainer->name) < 0) {
		return UC_FAULT;
	}

	return UC_OK;
}

static uc_err_t setup_network(container * pContainer) {
	char buffer[16 + strlen(pContainer->name)];
	char ip[32];
	int  fd __attribute__((cleanup(fd_close)));

	snprintf(buffer, sizeof(buffer), "/run/netns/%s", pContainer->name);
	fd = open(buffer, O_RDONLY);
	if (fd == -1)
		UC_FAULT("open network namespace\n");

	snprintf(buffer, sizeof(buffer), "veth1_%s", pContainer->name);
	if (netns_Join(buffer, fd) < 0) {
		UC_FAULT("join netns failed");
		return UC_FAULT;
	}

	if (setns(fd, CLONE_NEWNET) < 0) {
		UC_FAULT("change network namespace failed\n");
		return UC_FAULT;
	}

	link_Setup("lo", "up");
	int a;
	snprintf(ip, sizeof(ip), "10.0.0.%d", (a = random()%256) > 1?a:3);
	set_link_ipv4_addr(buffer, ip, 24);
	route_Add("0.0.0.0", "10.0.0.1", 0, buffer);

	return UC_OK;
}

static uc_err_t delete_network(container * pContainer) {
	char buffer[strlen("veth0_") + strlen(pContainer->name) + 1];

	snprintf(buffer, sizeof(buffer), "veth0_%s", pContainer->name);
	link_Remove(buffer);
    netns_Remove(pContainer->name);

	return UC_OK;
}

static uc_err_t mount_rootfs(container * pContainer) {
	char * options __attribute__((cleanup(ptr_free)));
	char * dir_path __attribute__((cleanup(ptr_free)));

	// mount -t overlay overlay -olowerdir=/lower,upperdir=/upper, workdir=/work /merged
	asprintf(&options, "lowerdir=%s,upperdir=%s/upper,workdir=%s/work", \
					  pContainer->container_image, \
					  pContainer->rootfs_path, \
					  pContainer->rootfs_path, \
					  pContainer->rootfs_path);


	asprintf(&dir_path, "%s%s", pContainer->rootfs_path, pContainer->mount_point);

	umount2(dir_path, MNT_DETACH);
	if (mount("overlay", dir_path, "overlay", 0, options) != 0)
		UC_FAULT("mount image failed option %s\n", options);

	return UC_OK;
}

static uc_err_t umount_rootfs(container * pContainer) {
	char * path;

	if (asprintf(&path, "%s%s", pContainer->rootfs_path, pContainer->mount_point) != -1) {
		umount2(path, MNT_DETACH);
		free(path);
		return UC_OK;
	} else {
		return UC_FAULT;
	}
}

static uc_err_t change_rootfs(container * pContainer) {
	char * path __attribute__((cleanup(ptr_free)));

	asprintf(&path, "%s/%s", pContainer->rootfs_path, pContainer->mount_point);

	if (mount(NULL, "/", NULL, MS_SLAVE|MS_REC, NULL) != 0) {
		UC_FAULT("Failed to mount / as slave\n");
	    return UC_FAULT;
	}

	if (mount(path, path, "bind", MS_BIND|MS_REC, NULL) != 0) {
		UC_FAULT("Failed to bind mount rootfs %s", path);
	    return UC_FAULT;
	}

	if (mount(path, "/", NULL, MS_MOVE, NULL) != 0) {
	    UC_FAULT("Failed to move mount /\n");
	    return UC_FAULT;
	}

	if (chdir(path) != 0) {
		UC_FAULT("Failed to chdir to rootfs\n");
	    return UC_FAULT;
	}

	if (chroot(".") != 0) {
		UC_FAULT("chroot failed\n");
	    return UC_FAULT;
	}

	if (pContainer->cwd != NULL){
	    if (chdir(pContainer->cwd) != 0) {
	    	UC_FAULT("chroot failed\n");
	        return UC_FAULT;
	    }
	} else {
	    if (chdir("/") != 0) {
	    	UC_FAULT("chroot "/" failed\n");
	        return UC_FAULT;
	    }
	}

	return UC_OK;
}

static uc_err_t create_cgroup(container * pContainer) {
	cgrp_Init();

	cgrp_Create(CGRP_SUBSYS_CPU, pContainer->name);
	cgrp_Create(CGRP_SUBSYS_MEM, pContainer->name);

	cgrp_cpu_SetShare(pContainer->name, 1024);
	cgrp_mem_SetLimit(pContainer->name, 100000);

	cgrp_AddProc(CGRP_SUBSYS_CPU, pContainer->name, pContainer->pid);
	cgrp_AddProc(CGRP_SUBSYS_MEM, pContainer->name, pContainer->pid);

	return UC_OK;
}

static uc_err_t delete_cgroup(container * pContainer) {

	cgrp_Delete(CGRP_SUBSYS_CPU, pContainer->name);
	cgrp_Delete(CGRP_SUBSYS_MEM, pContainer->name);

	return UC_OK;
}

static uc_err_t mount_filesystem(container * pContainer) {
	char * path __attribute__((cleanup(ptr_free)));
	uc_err_t retval = UC_OK;

	asprintf(&path, "%s/merge/proc", pContainer->rootfs_path);
	if (mkdir(path, 0755) < 0){
		return UC_FAULT;
	}

	if (mount("proc", path, "proc",  MS_NOSUID|MS_NOEXEC|MS_NODEV, NULL) < 0) {
	    UC_FAULT("Failed to mount /proc\n");
	    retval = UC_FAULT;
	}

	free(path);
	asprintf(&path, "%s/merge/dev/pts", pContainer->rootfs_path);
	mkdir(path, 0755);
	if (mount("devpts", path, "devpts", MS_NOSUID|MS_NOEXEC, NULL) < 0) {
		UC_FAULT("Failed to mount devpts /dev/pts\n");
		retval = UC_FAULT;
	}

	free(path);
	asprintf(&path, "%s/merge/sys", pContainer->rootfs_path);
	mkdir(path, 0755);
	if (mount("sysfs", path, "sysfs", MS_RDONLY|MS_NOSUID|MS_NOEXEC|MS_NODEV, NULL) < 0) {
		UC_FAULT("Failed to mount /sys\n");
		retval = UC_FAULT;
	}

	return retval;
}

static uc_err_t create_image_storage(char * image_name) {
	char * path __attribute__((cleanup(ptr_free)));
	uc_err_t retval = UC_OK;

	if (asprintf(&path, "%s/%s/rootfs", get_workdir(), image_name) != -1) {
		if (dir_Create(path, S_IRWXU | S_IRWXG | S_IRWXO) < 0){
		  retval = UC_FAULT;
		}
    }

	free(path);
	if (asprintf(&path, "%s/%s/image.json", get_workdir(), image_name) !=-1) {
		int fd = creat(path, S_IRWXU | S_IRWXG | S_IRWXO);
		if (fd < 0){
			retval = UC_FAULT;
		}
		close(fd);
	}

	return retval;
}

static uc_err_t remove_image_storage(char * image_name) {
	char * path __attribute__((cleanup(ptr_free)));

	if (asprintf(&path, "%s/%s", get_workdir(), image_name) != -1) {
		file_Remove (path);
	}

	return UC_OK;
}

static uc_err_t create_container_directory(container * pContainer) {
	char * path __attribute__((cleanup(ptr_free)));

	dir_Create(pContainer->rootfs_path, S_IRWXU | S_IRWXG | S_IRWXO);

	if (asprintf(&path, "%s/upper", pContainer->rootfs_path) != -1){
		dir_Create(path, S_IRWXU | S_IRWXG | S_IRWXO);
	}

	free(path);
	if (asprintf(&path, "%s/work", pContainer->rootfs_path) != -1){
		dir_Create(path, S_IRWXU | S_IRWXG | S_IRWXO);
	}

	free(path);
	if (asprintf(&path,"%s/%s", pContainer->rootfs_path, pContainer->mount_point) != -1) {
		dir_Create(path, S_IRWXU | S_IRWXG | S_IRWXO);
	}

	free(path);
	if (asprintf(&path, "%s/runtime.json", pContainer->rootfs_path) != -1) {
		int fd = creat(path, S_IRWXU | S_IRWXG | S_IRWXO);
		if (fd >= 0){
		    close(fd);
		}
	}

	return UC_OK;
}

static uc_err_t create_container_config (container * pContainer) {
	char  * path;
	cJSON * array;
	cJSON * array_item;
	int     fd __attribute__((cleanup(fd_close)));

	cJSON * config = cJSON_CreateObject();
	cJSON_AddStringToObject(config,"name",pContainer->name);
	cJSON_AddStringToObject(config,"image",pContainer->image_name);
	cJSON_AddStringToObject(config,"status", "created");
	cJSON_AddNumberToObject(config,"network", pContainer->network_setting);
	cJSON_AddItemToObject(config,"cmdline", array = cJSON_CreateArray());
	int i = 0;
	while (pContainer->command[i] != NULL) {
		array_item = cJSON_CreateString(pContainer->command[i]);
		cJSON_AddItemToArray(array, array_item);
		i++;
	}
	char * json_string = cJSON_Print(config);

	(void) asprintf(&path, "%s/ps_%s/runtime.json", get_workdir(), pContainer->name);
	fd = open(path, O_CREAT | O_RDWR, 0755);
	free(path);
	if (fd > 0) {
		if (write(fd, json_string, strlen(json_string)) < 0) {
			UC_FAULT("create container configuration failed");
			return UC_FAULT;
		}
	}
	cJSON_Delete(config);

	return UC_OK;
}

static uc_err_t container_config_add(container * pContainer, int type,
								char * name, void * value) {
	cJSON * config;
	char  * json_string;
	char  * path __attribute__((cleanup(ptr_free)));
	int     fd __attribute__((cleanup(fd_close)));

	(void) asprintf(&path, "%s/ps_%s/runtime.json", get_workdir(), pContainer->name);
	fd = open(path, O_RDWR);
	if (fd < 0) {
		UC_FAULT("can not open configuration file");
	} else {
		char buffer[get_file_size(fd) + 1];
		if (read(fd, buffer, get_file_size(fd)) > 0) {
			config = cJSON_Parse(buffer);
			if (config == NULL) {
				return UC_FAULT;
			}

			cJSON_DeleteItemFromObject(config, name);

			switch(type) {
			case cJSON_Number:
				cJSON_AddNumberToObject(config, name, *((double *)value));
				break;
			case cJSON_String:
				cJSON_AddStringToObject(config, name, (char *)value);
				break;
			case cJSON_True:
				cJSON_AddBoolToObject(config, name, 1);
				break;
			case cJSON_False:
				cJSON_AddBoolToObject(config, name, 0);
				break;
			default:
				UC_FAULT("Not support type %d\n", type);
			}

		json_string = cJSON_Print(config);
		lseek(fd, 0, SEEK_SET);
		if (write(fd, json_string, strlen(json_string)) < 0)
			UC_FAULT("write JSON configure failed\n");
		cJSON_Delete(config);
		}
	}

	return UC_FAULT;
}

static container * container_init(char * image_name, char ** command) {
	static container ucon;

	ucon.name = (char *)malloc(64);
	gen_uuid(ucon.uuid, ucon.name);
	ucon.command = command;

	asprintf(&ucon.image_name, "%s", image_name);

	asprintf(&ucon.container_image, "%s/%s/rootfs", get_workdir(), image_name);

	ucon.hostname = ucon.name;

	asprintf(&ucon.rootfs_path, "%s/ps_%s", get_workdir(), ucon.name);

	ucon.mount_point = "/merge";

	char path[PATH_MAX];
	snprintf(path, sizeof(path), "%s/%s/image.json", get_workdir(), image_name);
	int fd = open(path, O_RDONLY);
	if (fd < 0){
		UC_FAULT("can not open image config");
		return &ucon;
	}

	char buffer[get_file_size(fd) + 1];
	if (read(fd, buffer, get_file_size(fd)) < 0) {
		UC_FAULT("read JSON failed");
		close(fd);
		return &ucon;
	}
	close(fd);

    /* get env from image config */
	cJSON * root = cJSON_Parse(buffer);
	cJSON *	item = cJSON_GetObjectItem(root ,"process");
	cJSON * item2;
	cJSON * array = cJSON_GetObjectItem(item ,"env");

	for(int i = 0; array != NULL && i < cJSON_GetArraySize(array); i++){
        cJSON * env = cJSON_GetArrayItem(array, i);
	    int len = strlen(env->valuestring);
		ucon.envp[i] = malloc((len>1024) ? 1024 : len + 1);
		if (ucon.envp[i] == NULL)
			continue;
		strncpy(ucon.envp[i], env->valuestring, len);
	}

	/* get CWD form image config */
	item = cJSON_GetObjectItem(root , "process");
	item2 = cJSON_GetObjectItem(item , "cwd");

	if (item2 != NULL){
		int len = strlen(item2->valuestring);
		ucon.cwd = malloc(len + 1);
		if (ucon.cwd != NULL)
			strcpy(ucon.cwd, item2->valuestring);
	}
	else {
        ucon.cwd = NULL;
	}

	/* get uid/gid form image config */
	item = cJSON_GetObjectItem(root , "process");
	item2 = cJSON_GetObjectItem(item , "user");
	item = cJSON_GetObjectItem(item2 , "uid");
	if (item != NULL){
        ucon.uid = item->valueint;
	}

	item = cJSON_GetObjectItem(item2 , "gid");
	if (item != NULL){
		ucon.gid = item->valueint;
	}

	/* get command form image config */
	if (ucon.command[0] == NULL){
	    item = cJSON_GetObjectItem(root ,"process");
	    array = cJSON_GetObjectItem(item ,"args");

	    if (array != NULL) {
		    int i, len;
	        cJSON * cmd;

		    for(i = 0; i < cJSON_GetArraySize(array); i++){
		    	cmd = cJSON_GetArrayItem(array, i);
		        len = strlen(cmd->valuestring);
			    ucon.command[i] = malloc((len>256) ? 256 : len + 1);
			    if (ucon.command[i] == NULL)
				    continue;
			    strncpy(ucon.command[i], cmd->valuestring, len);
		    }

		    ucon.command[i] = NULL;
	    }
	}

	cJSON_Delete(root);

	return &ucon;
}

static uc_err_t setup_dev_node(container * pContainer) {
	char * devnode[] = {"/dev/urandom",
						"/dev/random",
						"/dev/zero",
						"/dev/full",
						"/dev/tty",
						"/dev/null",
						"/dev/console", NULL};
	char * path;
	struct stat st;

	for (int i = 0; devnode[i] != NULL; i++) {
        if (stat(devnode[i], &st) < 0) {
            UC_FAULT("failed to stat %s", devnode[i]);
            continue;
         } else if (!S_ISCHR(st.st_mode) && !S_ISBLK(st.st_mode)) {
            UC_FAULT("%s is not a char or block device", devnode[i]);
            continue;
         } else {
        	 if (asprintf(&path, "%s/merge%s", pContainer->rootfs_path, devnode[i]) != -1) {
        		 if (access(path, 0) < 0) {
        			 if (mknod(path, st.st_mode, st.st_rdev) < 0) {
        				 UC_FAULT("can not create device node %s", devnode[i]);
        			 }
        		 }
            	 free(path);
        	 }
         }
	}

	asprintf(&path, "%s/merge/dev/ptmx", pContainer->rootfs_path);
	symlink("/dev/pts/ptmx", path);

	return UC_OK;
}

static uc_err_t setup_resolv_conf(container * pContainer) {
	char  * path __attribute__((cleanup(ptr_free)));

	asprintf(&path, "%s/merge/etc/resolv.conf", pContainer->rootfs_path);
	int fd = open(path, O_TRUNC|O_CREAT, 0755);
	if (fd < 0){
		UC_FAULT("can not create resolv.conf\n");
		return UC_FAULT;
	} else {
		close(fd);
	}

	mkdir(path, 0755);
	if (mount("/etc/resolv.conf", path, NULL, MS_BIND, NULL) >= 0) {
		if (mount(NULL, path, NULL, MS_BIND|MS_REMOUNT|MS_RDONLY|MS_NOSUID|MS_NODEV, NULL) <0) {
			UC_FAULT("create resolv.conf failed\n");
			return UC_FAULT;
		}
	} else {
		UC_FAULT("create resolv.conf failed\n");
		return UC_FAULT;
	}

	return UC_OK;
}

uc_err_t uC_pull(int argc, char * argv[]) {
	char   short_uuid[10] = {0};
	char * image_name __attribute__((cleanup(ptr_free)));
	char * path __attribute__((cleanup(ptr_free)));
	int    fd __attribute__((cleanup(fd_close)));

	gen_uuid(NULL, short_uuid);

	asprintf(&image_name, "img_%s", short_uuid);

	if (create_image_storage(image_name) != UC_OK){
		UC_FAULT("can not create image");
		return UC_FAULT;
	}

	/* init configuration JSON */
	cJSON *item, *item2;
	cJSON *array;
    cJSON *config = cJSON_CreateObject();
    cJSON_AddStringToObject(config, "oci_Version", OCI_VERSION);

    item = cJSON_AddObjectToObject(config, "process");
    cJSON_AddFalseToObject(item,"terminal");
    item2 = cJSON_AddObjectToObject(item, "user");
    cJSON_AddNumberToObject(item2, "uid", 10);
    cJSON_AddNumberToObject(item2, "gid", 10);

    array = cJSON_AddArrayToObject(item,"args");
    cJSON_AddItemToArray(array, cJSON_CreateString("/bin/sh"));
    cJSON_AddStringToObject(item,"cwd","/");
    array = cJSON_AddArrayToObject(item,"env");
    cJSON_AddItemToArray(array, cJSON_CreateString("PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"));
    cJSON_AddItemToArray(array, cJSON_CreateString("TERM=xterm"));

    item = cJSON_AddObjectToObject(config, "annotations");
    cJSON_AddStringToObject(item,"source", UC_PARAM(0));
    char * json_string = cJSON_Print(config);

	(void) asprintf(&path, "%s/%s/image.json", get_workdir(), image_name);
	fd = open(path, O_CREAT | O_RDWR, 0755);
	if (fd > 0) {
		if (write(fd, json_string, strlen(json_string)) < 0) {
			UC_FAULT("create image failed\n");
			return UC_FAULT;
		}
	}
    cJSON_Delete(config);

    free(path);
	(void) asprintf(&path, "%s/%s/rootfs", get_workdir(), image_name);
	if (UC_PARAM(0) != NULL) {
		printf("pull %s\n", UC_PARAM(0));
		if (pull_image(UC_PARAM(0), path) < 0) {
			remove_image_storage(image_name);
		}
	} else {
		file_Remove (path);
		return UC_FAULT;
	}

	return UC_OK;
}

static struct option run_options[] =
  {
    /* These options set a flag. */
    {"network", required_argument, NULL, 'n'},
	{"cmd", no_argument, NULL, 'c'},
    {0, 0, 0, 0}
  };

static uc_err_t uC_run(int argc, char * argv[]) {
	int			   c=0, f=0;
	container *    uC_container;
	net_setting_t  nsset = NET_NAT;

	while (f != 1 && (c = getopt_long(argc, argv, "n:c", run_options, NULL)) >= 0) {
	    switch (c) {
	    case 'n':
	    	 if (strncmp(optarg, "none", sizeof("none")) == 0){
	    	   nsset = NET_NONE;
	    	 } else if (strncmp(optarg, "host", sizeof("host")) == 0){
	    	   nsset = NET_HOST;
	    	 } else {
	    	   nsset = NET_NAT;
	    	 }
			 break;
	    case 'c':
	    	 f = 1;
	    	 break;
	    default:
	    	 return UC_FAULT;
	    }
	}

	uC_container = container_init(UC_PARAM(optind - 1), &UC_PARAM(optind));
	uC_container->network_setting = nsset;

	if (access(uC_container->container_image, 0) == -1){
		UC_FAULT("Image %s is not exists", uC_container->container_image);
		return UC_FAULT;
    }

	create_container_directory(uC_container);

	create_container_config(uC_container);

	mount_rootfs(uC_container);

	setup_dev_node(uC_container);

	if (uC_container->network_setting == NET_NAT){
	    create_network(uC_container);
	}

	setup_resolv_conf(uC_container);

//setup seccomp
//setup_user(uC_container);
//drop capabilities

	//ioctl(0, TIOCNOTTY , 0);

	int pipefd[2];

	if (pipe(pipefd) < 0)
		goto exit;

	container_config_add(uC_container, cJSON_String, "status", "running");

	int clone_flags = SIGCHLD      |
				  	  CLONE_NEWIPC |
					  CLONE_NEWNS  |
					  CLONE_NEWPID |
					  CLONE_NEWUTS;

	if (uC_container->network_setting == NET_NONE){
		clone_flags |= CLONE_NEWNET;
	}

	int clone_pid = syscall(__NR_clone, clone_flags, NULL);
	if (clone_pid == -1) {
		UC_FAULT("Failed to clone\n");
		return UC_FAULT;
	}

	/* record child pid */
	if (clone_pid > 0) {
		char signal;
		double d = (double)clone_pid;

		uC_container->pid = clone_pid;
		container_config_add(uC_container, cJSON_Number, "pid", &d);
		create_cgroup(uC_container);

		close(pipefd[0]);
        write(pipefd[1], &signal, 1);
	}

	if (clone_pid == 0) {
		char signal;

		close(pipefd[1]);
		read(pipefd[0], &signal, 1);

		//setsid();
		//ioctl(0, TIOCSCTTY, 1);

		// Set up hostname
		if (sethostname(uC_container->hostname, strlen(uC_container->hostname)) != 0) {
			UC_FAULT("Could not set hostname");
			return UC_FAULT;
		}

		if (uC_container->network_setting == NET_NAT){
		    setup_network(uC_container);
		}

		mount_filesystem(uC_container);

		change_rootfs(uC_container);

		if (uC_container->command[0] != NULL){
			if (execvpe(uC_container->command[0],
						uC_container->command, uC_container->envp) == -1) {
				UC_FAULT("execvp failed");
				exit(UC_FAULT);
			}
		}
		exit(UC_OK);
	}

	int status;
	for (;;) {
		int ret = waitpid(clone_pid, &status, WUNTRACED);
		if ((ret == clone_pid) && (WIFSTOPPED(status))) {
			kill(getpid(), SIGSTOP);
			kill(clone_pid, SIGCONT);
		} else {
			break;
		}
	}

	delete_cgroup(uC_container);

exit:
	umount_rootfs(uC_container);

	if (uC_container->network_setting == NET_NAT){
	    delete_network(uC_container);
	}

	container_config_add(uC_container, cJSON_String, "status", "stopped");

	return UC_OK;
}

static uc_err_t uC_init(int argc, char * argv[]) {
	char   short_uuid[10] = {0};
	char * image_name;
	char * path __attribute__((cleanup(ptr_free)));
	int    fd __attribute__((cleanup(fd_close)));

	gen_uuid(NULL, short_uuid);
	asprintf(&image_name, "img_%s", short_uuid);
	create_image_storage(image_name);

	/* init configuration JSON */
	cJSON * item;
	cJSON * array;
    cJSON * config = cJSON_CreateObject();
    cJSON_AddStringToObject(config, "oci_Version", OCI_VERSION);

    item = cJSON_AddObjectToObject(config, "process");
    cJSON_AddFalseToObject(item,"terminal");
    array = cJSON_AddArrayToObject(item,"args");
    cJSON_AddItemToArray(array, cJSON_CreateString("/bin/sh"));
    cJSON_AddStringToObject(item,"cwd","/");
    array = cJSON_AddArrayToObject(item,"env");
    cJSON_AddItemToArray(array, cJSON_CreateString("PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"));
    cJSON_AddItemToArray(array, cJSON_CreateString("TERM=xterm"));

    item = cJSON_AddObjectToObject(config, "annotations");
    cJSON_AddStringToObject(item,"source", UC_PARAM(0));
    char * json_string = cJSON_Print(config);

	asprintf(&path, "%s/%s/image.json", get_workdir(), image_name);
	fd = open(path, O_CREAT | O_RDWR, 0755);
	if (fd > 0) {
		if (write(fd, json_string, strlen(json_string)) < 0) {
			UC_FAULT("store command failed\n");
		}
	}
    cJSON_Delete(config);

	/* copy all file into image */

	if (UC_PARAM(0) != NULL){
		free(path);
		if (asprintf(&path, "%s/%s/rootfs", get_workdir(), image_name) != -1) {
			if (file_Rescopy(UC_PARAM(0), path) < 0){
				return UC_FAULT;
			}
		}
    }

	return UC_OK;
}

static uc_err_t uC_ps(int argc, char * argv[]) {
	DIR *           dirptr;
	struct dirent * entry;
	char * 			path;
	cJSON *         array_item;

	printf("CONTAINER_ID\t\tCOMAMND\n");

	if ((dirptr = opendir(get_workdir())) == NULL){
		UC_FAULT("can't open dir\n");
		return UC_FAULT;
    }

	while((entry = readdir(dirptr)) != NULL){
		if (strstr(entry->d_name, "ps_") != NULL && entry->d_type == DT_DIR) {
			int fd __attribute__((cleanup(fd_close)));
			(void) asprintf(&path, "%s/%s/runtime.json", get_workdir(), entry->d_name);
			fd = open(path, O_RDONLY);
			free(path);
			if (fd < 0) {
				UC_FAULT("can not open configuration file\n");
				continue;
			}

			char buffer[get_file_size(fd) + 1];
			if (read(fd, buffer, get_file_size(fd)) < 0) {
				continue;
			}
			cJSON * config = cJSON_Parse(buffer);
			cJSON * item = cJSON_GetObjectItem(config , "cmdline");
			int array_size = cJSON_GetArraySize(item);

			printf("%s\t\t",  entry->d_name);
			for(int i=0;i<array_size;i++) {
				array_item = cJSON_GetArrayItem(item, i);
				if (array_item != NULL)
					printf("%s ", array_item->valuestring);
			}
			printf("\n");

			cJSON_Delete(config);
		}
	}

	closedir(dirptr);
	return UC_OK;
}

static uc_err_t uC_images(int argc, char * argv[]) {
	char *        	path;
	DIR *           dirptr;
	struct dirent * entry;
	int fd __attribute__((cleanup(fd_close)));

	if ((dirptr = opendir(get_workdir())) == NULL){
		UC_FAULT("can't open work dir\n");
		return UC_FAULT;
    }

	printf("IMAGE_ID\t\tSOURCE\n");

	while((entry = readdir(dirptr)) != NULL){
		if (strstr(entry->d_name, "img_") != NULL && entry->d_type == DT_DIR) {
			(void) asprintf(&path, "%s/%s/image.json", get_workdir(), entry->d_name);
			fd = open(path, O_RDONLY);
			free(path);
			if (fd < 0) {
				continue;
			}

			char buffer[get_file_size(fd) + 1];
			if (read(fd, buffer, get_file_size(fd)) < 0) {
				UC_FAULT("read JSON failed\n");
				continue;
			}

			cJSON *	root = cJSON_Parse(buffer);
			cJSON *	item = cJSON_GetObjectItem(root , "annotations");
			item = cJSON_GetObjectItem(item ,"source");

			if (item != NULL){
			    printf("%s\t\t%s\n", entry->d_name, item->valuestring?item->valuestring:"oci bundle");
			} else {
				printf("%s\t\toci bundle\n", entry->d_name);
			}
			cJSON_Delete(root);
        }
   	}

	closedir(dirptr);
	return UC_OK;
}

static uc_err_t uC_rm(int argc, char * argv[]) {
	char * path;

	if (UC_PARAM(0) == NULL)
		return UC_FAULT;

	if (asprintf(&path, "%s/%s", get_workdir(), UC_PARAM(0)) != -1) {
		file_Remove (path);
		free(path);
	}

	cgrp_Delete(CGRP_SUBSYS_CPU, &UC_PARAM(0)[3]);
	cgrp_Delete(CGRP_SUBSYS_MEM, &UC_PARAM(0)[3]);

	return UC_OK;
}

static uc_err_t uC_exec(int argc, char * argv[]) {
	char * path __attribute__((cleanup(ptr_free)));
	int    fd __attribute__((cleanup(fd_close)));
	char * nstype[] = {"ipc", "pid", "net", "uts", "mnt", NULL};

	(void) asprintf(&path, "%s/%s/runtime.json", get_workdir(), UC_PARAM(0));
	fd = open(path, O_RDONLY);
	if (fd < 0) {
		UC_FAULT("can not open configuration file");
		return UC_FAULT;
	}

	int size = get_file_size(fd);
	char * buffer = malloc(size + 1);
	if (buffer == NULL){
		return UC_FAULT;
	}

	if (read(fd, buffer, size) <= 0) {
		UC_FAULT("error read configuration file\n");
		free(buffer);
		return UC_FAULT;
	}

	cJSON * config = cJSON_Parse(buffer);
	cJSON * item = cJSON_GetObjectItem(config , "pid");

	char * nsfile;
	for (int i = 0; nstype[i] != NULL; i++) {
		asprintf(&nsfile, "/proc/%d/ns/%s", item->valueint, &nstype[i][0]);
		int nsfd = open(nsfile, O_RDONLY);
		if (nsfd < 0){
			UC_INFO("can not open namespace %s", nsfile);
			free(nsfile);
			continue;
		}
		if (setns(nsfd, 0) == -1)
			UC_INFO("setns failed %s", nsfile);
		close(nsfd);
		free(nsfile);
	}
	cJSON_Delete(config);
	free(buffer);

	int pid = fork();

	if (pid > 0){
		int status;
		for (;;) {
			int ret = waitpid(pid, &status, WUNTRACED);
			if ((ret == pid) && (WIFSTOPPED(status))) {
				kill(getpid(), SIGSTOP);
				kill(pid, SIGCONT);
			} else {
				break;
			}
		}

		if (WIFEXITED(status)) {
			exit(WEXITSTATUS(status));
		} else if (WIFSIGNALED(status)) {
			kill(getpid(), WTERMSIG(status));
		}

		exit(UC_FAULT);
	}

	int arg_index = 2;

    if (argv[arg_index] != NULL && argv[arg_index] != NULL){
	    if (execvp(argv[arg_index], &argv[arg_index]) == -1){
		    UC_FAULT("exec failed");
	    }
    }

	return UC_OK;
}

static uc_err_t uC_stop(int argc, char * argv[]) {
	char * path __attribute__((cleanup(ptr_free)));
	int    fd __attribute__((cleanup(fd_close)));

	(void) asprintf(&path, "%s/%s/runtime.json", get_workdir(), UC_PARAM(0));
	fd = open(path, O_RDWR);
	if (fd < 0) {
		UC_FAULT("can not open configuration file");
		return UC_FAULT;
	}

	char buffer[get_file_size(fd) + 1];
	if (read(fd, buffer, get_file_size(fd)) <= 0) {
		UC_FAULT("error read configuration file");
		return UC_FAULT;
	}
	cJSON * config = cJSON_Parse(buffer);
	cJSON * item = cJSON_GetObjectItem(config , "pid");

	kill(item->valueint,SIGTERM);
	kill(item->valueint,SIGKILL);

	cJSON_DeleteItemFromObject(config, "status");
	cJSON_AddStringToObject(config, "status", "stopped");

	char * json_string = cJSON_Print(config);
	lseek(fd, 0, SEEK_SET);
	if (write(fd, json_string, strlen(json_string)) < 0)
		UC_FAULT("write JSON configure failed\n");

	cJSON_Delete(config);

	return UC_OK;
}

static uc_err_t uC_start(int argc, char * argv[]) {
	container * uC_container;
	char * path __attribute__((cleanup(ptr_free)));

	(void) asprintf(&path, "%s/%s/runtime.json", get_workdir(), UC_PARAM(0));
	int fd = open(path, O_RDONLY);
	if (fd < 0) {
		UC_FAULT("can not open configuration file");
		return UC_FAULT;
	}

	char buffer[get_file_size(fd) + 1];
	if (read(fd, buffer, get_file_size(fd)) <= 0) {
		UC_FAULT("error read configuration file");
		close(fd);
		return UC_FAULT;
	}
	close(fd);

	cJSON * config = cJSON_Parse(buffer);
	cJSON * item = cJSON_GetObjectItem(config , "image");
	cJSON * array = cJSON_GetObjectItem(config , "cmdline");
	char *  cmd[16];
	int     i;

	for(i = 0; array != NULL && i < cJSON_GetArraySize(array); i++){
        cJSON * arg = cJSON_GetArrayItem(array, i);
	    int len = strlen(arg->valuestring);
		cmd[i] = malloc((len > 1024) ? 1024 : len + 1);
		if (cmd[i] == NULL)
			continue;
		strncpy(cmd[i], arg->valuestring, len);
	}
	cmd[i] = NULL;

	uC_container = container_init(item->valuestring, cmd);
	strncpy(uC_container->name, strchr(UC_PARAM(0),'_') + 1, 64);
	sprintf(uC_container->rootfs_path, "%s/%s", get_workdir(), UC_PARAM(0));

	/* update network setting */
	item = cJSON_GetObjectItem(config , "network");
	if (item != NULL){
	    uC_container->network_setting = item->valueint;
	}

	cJSON_Delete(config);

	mount_rootfs(uC_container);

	if (uC_container->network_setting == NET_NAT){
	    create_network(uC_container);
	}

	setup_resolv_conf(uC_container);

	int pipefd[2];
	if (pipe(pipefd) < 0)
		goto exit;

	container_config_add(uC_container, cJSON_String, "status", "running");
	//ioctl(0, TIOCNOTTY , 0);

	int clone_flags = SIGCHLD      |
				  	  CLONE_NEWIPC |
					  CLONE_NEWNS  |
					  CLONE_NEWPID |
					  CLONE_NEWUTS;

	if (uC_container->network_setting == NET_NONE){
		clone_flags |= CLONE_NEWNET;
	}

	int clone_pid = syscall(__NR_clone, clone_flags, NULL);
	if (clone_pid == -1) {
		UC_FAULT("Failed to clone\n");
		return UC_FAULT;
	}

	/* record child pid */
	if (clone_pid > 0) {
		char signal;
		double d = (double)clone_pid;

		uC_container->pid = clone_pid;
		container_config_add(uC_container, cJSON_Number, "pid", &d);

		create_cgroup(uC_container);

		close(pipefd[0]);
        write(pipefd[1], &signal, 1);
	}

	if (clone_pid == 0) {
		char signal;

		close(pipefd[1]);
		read(pipefd[0], &signal, 1);

		// Set up hostname
		if (sethostname(uC_container->hostname, strlen(uC_container->hostname)) != 0) {
			UC_FAULT("Could not set hostname\n");
			return UC_FAULT;
		}

		if (uC_container->network_setting == NET_NAT){
		    setup_network(uC_container);
		}

		mount_filesystem(uC_container);

		change_rootfs(uC_container);

		if (uC_container->command[0] != NULL){
			if (execvpe(uC_container->command[0],
						uC_container->command, uC_container->envp) == -1) {
				UC_FAULT("execvp failed");
				exit(UC_FAULT);
			}
		}
		exit(UC_OK);
	}

	int status;
	for (;;) {
		int ret = waitpid(clone_pid, &status, WUNTRACED);
		if ((ret == clone_pid) && (WIFSTOPPED(status))) {
			kill(getpid(), SIGSTOP);
			kill(clone_pid, SIGCONT);
		} else {
			break;
		}
	}

	delete_cgroup(uC_container);

exit:
	umount_rootfs(uC_container);

	if (uC_container->network_setting == NET_NAT){
	    delete_network(uC_container);
	}

	container_config_add(uC_container, cJSON_String, "status", "stopped");

	return UC_OK;
}

int main(const int argc, char * argv[]) {
  int opt = oInvalid;

  if (argc < 2)
	  usage(&argv[0]);

  for (int i = 0; command[i].name; i++) {
       if (strcasecmp(argv[1], command[i].name) == 0) {
           opt = command[i].opcode;
           break;
       }
  }

  /* create the work dir */
  if (access(get_workdir(), 0) < 0){
	  char * path;
	  asprintf(&path, "%s", get_workdir());
	  if (dir_Create (path, S_IRWXU | S_IRWXG | S_IRWXO) < 0) {
		  UC_FAULT("can not create work dir");
	  }
	  free(path);
  }

  int arg_num = argc - UC_ARGS;

  switch(opt){
       case oPull:
            uC_pull(arg_num, &argv[UC_ARGS]);
            break;
       case oRun:
            uC_run(arg_num, &argv[UC_ARGS]);
            break;
       case oInit:
            uC_init(arg_num, &argv[UC_ARGS]);
            break;
       case oPs:
            uC_ps(arg_num, &argv[UC_ARGS]);
            break;
       case oImages:
            uC_images(arg_num, &argv[UC_ARGS]);
            break;
       case oRm:
            uC_rm(arg_num, &argv[UC_ARGS]);
            break;
       case oExec:
            uC_exec(arg_num, &argv[UC_ARGS]);
            break;
       case oStop:
            uC_stop(arg_num, &argv[UC_ARGS]);
            break;
       case oStart:
            uC_start(arg_num, &argv[UC_ARGS]);
            break;
       default:
            usage();
  }

  return UC_OK;
}
