#ifndef _KM_TEST_MAC_H_
#define _KM_TEST_MAC_H_

uint32_t km_mac_test();
uint32_t km_mac_short_buffer_test();
uint32_t km_mac_whole_test();
uint32_t km_mac_perf_test(uint32_t test_count);

#endif /* _KM_TEST_MAC_H_ */
