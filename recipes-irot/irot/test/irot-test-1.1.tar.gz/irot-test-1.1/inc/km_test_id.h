#ifndef _KM_TEST_ID_H_
#define _KM_TEST_ID_H_

uint32_t test_get_id2();
uint32_t test_set_get_id2();
uint32_t km_get_attestation_test();

#endif /* _KM_TEST_ID_H_ */
