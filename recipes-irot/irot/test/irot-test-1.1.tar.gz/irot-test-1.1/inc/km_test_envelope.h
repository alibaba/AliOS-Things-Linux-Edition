#ifndef _KM_ENVELOPE_H_
#define _KM_ENVELOPE_H_

int km_envelope_whole_test();
int km_envelope_perf_test(uint32_t test_count);

#endif /* _KM_ENVELOPE_H_ */
