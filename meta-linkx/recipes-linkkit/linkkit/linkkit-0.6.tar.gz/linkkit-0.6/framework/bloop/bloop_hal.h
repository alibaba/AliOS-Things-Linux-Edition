#ifndef _BLOOP_HAL_H_
#define _BLOOP_HAL_H_

#include <stdint.h>

void * hal_malloc(uint32_t len);
void hal_free(void *ptr);
int hal_msleep(uint32_t ms);
int hal_thread_new(void * (*start_routine)(void *), void *arg, int stack_size);
int hal_mutex_lock(void *mutex);
int hal_mutex_unlock(void *mutex);
void * hal_mutex_create();
void hal_mutex_destroy(void *mutex);

#endif
