#include "bloop.h"
#include "bloop_hal.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <pthread.h>
#include <stdio.h>

void * hal_malloc(uint32_t len)
{
    return malloc((size_t)len);
}

void hal_free(void *ptr)
{
    free(ptr);
}

int hal_msleep(uint32_t ms)
{
    usleep(ms * 1000);
    return 0;
}

int hal_thread_new(void * (*start_routine)(void *), void *arg, int stack_size)
{
    pthread_t tid;
    return pthread_create(&tid, NULL, start_routine, arg);
}

int hal_mutex_lock(void *mutex)
{
    return pthread_mutex_lock((pthread_mutex_t *)mutex);
}

int hal_mutex_unlock(void *mutex)
{
    return pthread_mutex_unlock((pthread_mutex_t *)mutex);
}

void* hal_mutex_create()
{
    int ret;
    pthread_mutex_t *mutex;

    mutex = (pthread_mutex_t *)hal_malloc(sizeof(pthread_mutex_t));
    if (NULL == mutex) {
        return NULL;
    }

    if (0 != (ret = pthread_mutex_init(mutex, NULL))) {
        printf("Failed to create mutex.\r\n");
        hal_free(mutex);
        return NULL;
    }

    return mutex;
}

void hal_mutex_destroy(void *mutex)
{
    int ret;

    if (mutex == NULL) {
        printf("mutex want to destroy is NULL!\r\n");
        return;
    }

    if (0 != (ret = pthread_mutex_destroy((pthread_mutex_t *)mutex))) {
        printf("destroy mutex failed\r\n");
    }

    hal_free(mutex);
}
