#include "bloop.h"
#include "bloop_hal.h"
#include <stddef.h>
#include <stdio.h>
#include <stdbool.h>

typedef struct evt_cb_list_s {
    struct evt_cb_list_s *next;
    bloop_event_cb_t cb;
    void *priv;
} evt_cb_list_t;

typedef struct evt_posted_list_s {
    struct evt_posted_list_s *next;
    bloop_event_t evt;
} evt_posted_list_t;

typedef struct evt_list_s {
    struct evt_list_s *next;
    uint16_t type;
    evt_cb_list_t *cb_list;
    evt_posted_list_t *posted;
    void *post_mtx;
} evt_list_t;

evt_list_t *g_evt_list = NULL;
static bool m_event_loop_enabled = true;

/* Post event to the loop.
 * Do not call the callbacks directly in this function, instead call it
 * within the event main loop.
 */
int bloop_post_event(bloop_event_type_t type, bloop_event_code_t code,
                  unsigned long value)
{
    evt_list_t *evt_node;
    evt_cb_list_t *cb;
    evt_posted_list_t *evt_to_post;

    evt_to_post = (evt_posted_list_t *)hal_malloc(sizeof(evt_posted_list_t));
    if (!evt_to_post) {
        printf("Error: failed to post event (malloc failed).\r\n");
        return -1;
    }

    evt_to_post->evt.type = type;
    evt_to_post->evt.code = code;
    evt_to_post->evt.value = value;
    evt_to_post->next = NULL;

    evt_node = g_evt_list;
    while (evt_node) {
        /* We find it, add it to the posted event list. */
        if (evt_node->type == type) {
            if (hal_mutex_lock(evt_node->post_mtx) != 0){
                printf("!!!Error: %s failed to get lock for event "
                       "(type: %d)", __func__, type);
                hal_free(evt_to_post);
                return -1;
            }

            if (evt_node->posted == NULL) {
                evt_node->posted = evt_to_post;
            } else {
                evt_posted_list_t *tmp = evt_node->posted;
                while (tmp->next != NULL) tmp = tmp->next;
                tmp->next = evt_to_post;
            }

            hal_mutex_unlock(evt_node->post_mtx);

            printf("%s event posted: t-c-v: %d-%d-%d\r\n", __func__, type, code, (unsigned int)value);

            return 0;
        }

        evt_node = evt_node->next;
    }

    return -1;
}

int bloop_register_event_filter(bloop_event_type_t type, bloop_event_cb_t cb,
                             void *priv)
{
    int ret = 0;
    evt_list_t *p_evt = NULL, *p_evt_prev = NULL;
    evt_cb_list_t *p_cb = NULL, *p_cb_tmp = NULL;

    /* New cb_list node, fill the fields accordingly. */
    p_cb = (evt_cb_list_t *)hal_malloc(sizeof(evt_cb_list_t));
    if (!p_cb) {
        printf("Error: failed to register event filter (malloc fail)\n");
        ret = -1;
        goto fail;
    } else {
        p_cb->next = NULL;
        p_cb->cb = cb;
        p_cb->priv = priv;
        //p_cb->ready = false;
    }

    /* If no evt_list node yet, create a new one directory. */
    if (g_evt_list == NULL) {
        goto new_evt_list_node;
    }

    /* If the first node in evt_list hits the type, ... */
    if (g_evt_list->type == type) {
        p_cb_tmp = g_evt_list->cb_list;
        while (p_cb_tmp->next != NULL) p_cb_tmp = p_cb_tmp->next;
        p_cb_tmp->next = p_cb;
        return 0;
    }

    p_evt_prev = g_evt_list;
    p_evt = g_evt_list->next;
    while (p_evt) {
        /* This evt_list node matches the event type, add it to the list */
        if (p_evt->type == type) {
            p_cb_tmp = p_evt->cb_list;
            while (p_cb_tmp->next != NULL) p_cb_tmp = p_cb_tmp->next;
            p_cb_tmp->next = p_cb;
            return 0;
        }

        p_evt_prev = p_evt;
        p_evt = p_evt->next;
    }

new_evt_list_node:
    p_evt = (evt_list_t *)hal_malloc(sizeof(evt_list_t));
    if (!p_evt) {
        printf("Error: failed to register event filter (malloc fail)\r\n");
        goto fail;
    }
    p_evt->next = NULL;
    p_evt->type = type;
    p_evt->cb_list = p_cb;
    if (g_evt_list == NULL) {
        g_evt_list = p_evt;
    } else {
        p_evt_prev->next = p_evt;
    }
    p_evt->posted = NULL;
    p_evt->post_mtx = hal_mutex_create();
    if (p_evt->post_mtx == NULL) {
        printf("!!!Error: failed to create mutex for event (type: %d).\r\n", type);
        goto fail;
    }

    return 0;

fail:
    if (p_cb) hal_free(p_cb);
    if (p_evt) hal_free(p_evt);

    return -1;
}

#define EVENT_LOOP_INTERVAL 200 /* milli seconds */
static void* event_loop(void *arg)
{
    evt_list_t *evt;
    evt_cb_list_t *cb;
    evt_posted_list_t *evt_posted, *tmp;

    /* the major work is to iterate the event loop, 
     * and call callback if any event is ready.
     */
    while (1) {
        /* Add mutex lock for the ready flag. TODO */
        for (evt = g_evt_list; evt; evt = evt->next) {
            if (evt->posted == NULL) {
                continue;
            }

            /* We find a ready event, call its callback list. */
            evt_posted = evt->posted;
            while (evt_posted != NULL) {
                cb = evt->cb_list;
                while (cb) {
                    if (cb->cb) cb->cb(&(evt_posted->evt), cb->priv);
                    cb = cb->next;
                }

                /* OK, now we finish this event, let's clear the event state. */
                if (hal_mutex_lock(evt->post_mtx) != 0){
                    printf("!!!Error: failed to get lock for event (type: %d)", evt->type);
                    continue;
                }

                tmp = evt_posted;
                evt_posted = evt_posted->next;
                evt->posted = evt_posted;
                hal_free(tmp);

                hal_mutex_unlock(evt->post_mtx);
            }

            printf("%s event dispatched: type %d\r\n", __func__, evt->type);
        }
        /* Do not want to poll all the time.
         * This saves CPU, but will introduce delay to event response.
         * So balance it.
         */
        hal_msleep(EVENT_LOOP_INTERVAL);

        /* exit event loop if necessary */
        if (m_event_loop_enabled == false) break;
    };
    printf("bloop exit.\n");
}

void bloop_start_event_loop()
{
    int ret;

    ret = hal_thread_new(event_loop, NULL, 2048);
    if (ret != 0) {
        printf("!!!Warning: failed to create event loop thread.\r\n");
    }
}

void bloop_destroy_event_loop()
{
    m_event_loop_enabled = false;

    /* Destroy event loop resources here. TODO */
    return;
}

