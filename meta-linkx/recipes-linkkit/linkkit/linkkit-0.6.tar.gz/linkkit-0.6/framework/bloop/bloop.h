#ifndef _BLOOP_H_
#define _BLOOP_H_

#include <stdint.h>

typedef enum
{
    B_EV_BLE,
    B_EV_COMBO,
    /* Add more event type hereafter */
} bloop_event_type_t;

typedef enum
{
    /* BLE event code, reserved 0 to 0x000f */
    B_EV_CODE_BLE_TX_COMPLETED = 0,
    B_EV_CODE_BLE_TEST1,
    /* COMBO event code, reserved 0x0010 - 0x001f */
    B_EV_CODE_COMBO_AP_INFO_READY = 0x0010,
    B_EV_CODE_COMBO_TEST1,
    B_EV_CODE_COMBO_TEST2,
    B_EV_CODE_COMBO_TEST3,
    /* Add more event code hereafter */
    B_EV_CODE_MAX = 0xffff
} bloop_event_code_t;

typedef struct
{
    /* Event type, bloop_event_type_t */
    uint16_t type;
    /* Event code, bloop_event_code_t */
    uint16_t code;
    /* User data, defined according to type/code */
    unsigned long value;
} bloop_event_t;

/* Asynchronous event callback */
typedef void (*bloop_event_cb_t)(bloop_event_t *event, void *private_data);

int bloop_post_event(bloop_event_type_t type, bloop_event_code_t code,
                  unsigned long value);

int bloop_register_event_filter(bloop_event_type_t type, bloop_event_cb_t cb,
                             void *priv);

void bloop_start_event_loop();

void bloop_destroy_event_loop();

#endif
