#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bloop.h"
#include <pthread.h>
#include <unistd.h>

static void event_hanlder(bloop_event_t *event, void *priv)
{
    printf("Hello %s: type: %d, code: %d, value: %d, priv: %p\r\n", __func__,
           event->type, event->code, (int)event->value, priv);
}

static void* test_thread1(void *arg)
{
    int cnt = 0;
    printf("Hello %s entry\r\n", __func__);
    sleep(1);
    while (cnt < 5) {
        switch (cnt % 2) {
        case 0:
            bloop_post_event(B_EV_BLE, B_EV_CODE_BLE_TEST1, (unsigned long)__LINE__);
            break;
        case 1:
            bloop_post_event(B_EV_BLE, B_EV_CODE_BLE_TX_COMPLETED, (unsigned long)__LINE__);
            break;
        }
        sleep(1 << cnt++);
    }
    printf("Hello %s exit\r\n", __func__);
}

static void* test_thread2(void *arg)
{
    int cnt = 0;
    printf("Hello %s entry\r\n", __func__);
    sleep(2);
    while (cnt < 10) {
        switch (cnt % 3) {
        case 0:
            bloop_post_event(B_EV_COMBO, B_EV_CODE_COMBO_TEST1, (unsigned long)__LINE__);
            break;
        case 1:
            bloop_post_event(B_EV_COMBO, B_EV_CODE_COMBO_TEST2, (unsigned long)__LINE__);
            break;
        case 2:
            bloop_post_event(B_EV_COMBO, B_EV_CODE_COMBO_AP_INFO_READY, (unsigned long)__LINE__);
            break;
        }
        sleep(1 << cnt++);
    }
    printf("Hello %s exit\r\n", __func__);
}

static void* test_thread3(void *arg)
{
    int cnt = 0;
    printf("Hello %s entry\r\n", __func__);
    sleep(3);
    while (cnt < 10) {
        bloop_post_event(B_EV_COMBO, B_EV_CODE_COMBO_TEST3, (unsigned long)cnt);
        cnt++;
    }
    printf("Hello %s exit\r\n", __func__);
}

int main()
{
    void *test_priv = (void *)0x123;
    void *test_priv2 = (void *)0x456;
    pthread_t tid[3];

    bloop_register_event_filter(B_EV_COMBO, event_hanlder, test_priv);
    bloop_register_event_filter(B_EV_BLE, event_hanlder, test_priv2);
    bloop_start_event_loop();

    pthread_create(&tid[0], NULL, test_thread1, NULL);
    pthread_create(&tid[1], NULL, test_thread2, NULL);
    pthread_create(&tid[2], NULL, test_thread3, NULL);

    while (1);

    return 0;
}
