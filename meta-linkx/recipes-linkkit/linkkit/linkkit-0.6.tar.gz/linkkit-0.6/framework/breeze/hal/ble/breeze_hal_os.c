#include <breeze_hal_os.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/reboot.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <bloop.h>

int os_timer_new(os_timer_t *timer, os_timer_cb_t cb, void *arg, int ms)
{
    return 0;
}

int os_timer_start(os_timer_t *timer)
{
    return 0;
}

int os_timer_stop(os_timer_t *timer)
{
    return 0;
}

void os_timer_free(os_timer_t *timer)
{
    return;
}

long long os_now_ms(void)
{
    long long t = 0;
    struct timeval tv;

    if (gettimeofday(&tv, NULL) == 0) {
        t = (long long )tv.tv_sec * 1000 + (long long)tv.tv_usec;
    }

    return t;
}

void os_reboot()
{
    if (reboot(RB_AUTOBOOT) == -1) {
        printf("!!!Warning: failed to the reboot system.\r\n");
    }
}

void os_msleep(int ms)
{
    if (usleep((useconds_t)(ms * 1000)) != 0) {
        printf("!!!Warning: failed to sleep (%d ms)\r\n", ms);
    }
}

/* Post event to the loop.
 * Do not call the callbacks directly in this function, instead call it
 * within the event main loop.
 */
int os_post_event(os_event_type_t type, os_event_code_t code,
                  unsigned long value)
{
    return bloop_post_event((bloop_event_type_t)type, (bloop_event_code_t)code, value);
}

int os_register_event_filter(os_event_type_t type, os_event_cb_t cb,
                             void *priv)
{
    return bloop_register_event_filter((bloop_event_type_t)type, (bloop_event_cb_t)cb, priv);
}

static void os_destroy_event_loop()
{
    /* Destroy event loop resources here. TODO */
    return;
}

#ifdef CONFIG_AIS_STOTE_SEQ
void os_post_delayed_action(int ms, void (*action)(void *arg), void *arg)
{
    return;
}
#endif

void os_start_event_dispatcher()
{
    bloop_start_event_loop();
}

int os_kv_set(const char *key, const void *value, int len, int sync)
{
    return hal_kv_set(key, value, len, sync);
}

int os_kv_get(const char *key, void *buffer, int *buffer_len)
{
    return hal_kv_get(key, buffer, buffer_len);
}

int os_kv_del(const char *key)
{
    return hal_kv_del(key);
}
