/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 */

#include <breeze_hal_ble.h>

void ble_disconnect(uint8_t reason)
{
    return;
}

ais_err_t ble_stack_init(ais_bt_init_t *info)
{
    return AIS_ERR_SUCCESS;
}

ais_err_t ble_stack_deinit()
{
    return AIS_ERR_SUCCESS;
}

ais_err_t ble_send_notification(uint8_t *p_data, uint16_t length)
{
    return AIS_ERR_SUCCESS;
}

ais_err_t ble_send_indication(uint8_t *p_data, uint16_t length)
{
    return AIS_ERR_SUCCESS;
}

ais_err_t ble_advertising_start(ais_adv_init_t *adv)
{
    return AIS_ERR_SUCCESS;
}

ais_err_t ble_advertising_stop()
{
    return AIS_ERR_SUCCESS;
}

ais_err_t ble_get_mac(uint8_t *mac)
{
    return AIS_ERR_SUCCESS;
}
