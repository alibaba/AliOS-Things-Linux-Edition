#include <stdio.h>
#include "devinfo_reader.h"

int main()
{
    int ret = 0;
    devinfo_set5_t dinfo;
    char pk[16] = {0}, ps[20] = {0}, dn[32] = {0}, ds[32] = {0};

    dinfo.pk = pk;
    dinfo.ps = ps;
    dinfo.dn = dn;
    dinfo.ds = ds;

    if ((ret = get_devinfo_all5(&dinfo)) < 0) {
        printf("get_devinfo_all5 failed (%d).\r\n", ret);
        ret = -1;
    } else {
        printf("device info: \r\n");
        printf("pi: %d\r\n", dinfo.pi);
        printf("pk: %s\r\n", dinfo.pk);
        printf("ps: %s\r\n", dinfo.ps);
        printf("dn: %s\r\n", dinfo.dn);
        printf("ds: %s\r\n", dinfo.ds);
    }

    return ret;
}
