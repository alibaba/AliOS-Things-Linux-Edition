#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include "devinfo_reader.h"

#define DEVINFO_FILE "/data/.device_triple"
#define ENTER_CHAR '\n'

/*
product_key: a10uc3TeDWE
product_id: 457608
product_secret: 7xBeARyDHtknDNOk
device_name: dam04oxBIxG6YdhkWctG
device_secret: Mn4PibfuhjyiAA36huU7FEV2AoZcmClG
*/

/* Do not want to use getline() which is not in standard libc. */
static int read_line(int fd, char *line, unsigned int *len)
{
    int i = 0, ret;

    if (fd < 0 || !line || !len) return -1;

    while (i < *len) {
        ret = read(fd, &line[i], 1);
        if (-1 == ret) {
            printf("%s read error (%d)\r\n", __func__, errno);
            return -1;
        }

        /* hit end-of-file */
        if (ret == 0) {
            line[i] = '\0';
            *len = i;
            return 0;
        }

        /* hit line end */
        if (line[i] == ENTER_CHAR) {
            line[i] = '\0';
            *len = i;
            return 1;
        }

        i++;
    }

    /* erro, hit the max len which is unexpected. */
    return -1;
}

int get_devinfo_product_id(uint32_t pi)
{
    return 0;
}

int get_devinfo_product_key(char *pk)
{
    return 0;
}

int get_devinfo_product_secret(char *ps)
{
    return 0;
}

int get_devinfo_device_name(char *dn)
{
    return 0;
}

int get_devinfo_device_secret(char *ds)
{
    return 0;
}

#define LINE_STR_MAX_LEN 128
#define PRODUCT_ID_STR     "product_id: "
#define PRODUCT_KEY_STR    "product_key: "
#define PRODUCT_SECRET_STR "product_secret: "
#define DEVICE_NAME_STR    "device_name: "
#define DEVICE_SECRET_STR  "device_secret: "
#define PRODUCT_ID_MAX     6
#define PRODUCT_KEY_MAX    20
#define PRODUCT_SECRET_MAX 64
#define DEVICE_NAME_MAX    32
#define DEVICE_SECRET_MAX  64
int get_devinfo_all5(devinfo_set5_t *dinfo)
{
    int fd, flag = 0, len, ret;
    char line[LINE_STR_MAX_LEN], *match;

    if (!dinfo || !dinfo->pk || !dinfo->ps || !dinfo->dn || !dinfo->ds) {
        return -1;
    }

    fd = open(DEVINFO_FILE, O_RDONLY);
    if (fd == -1) {
        printf("Failed to open file (%s), errno: %d\r\n", DEVINFO_FILE, errno);
        return -1;
    }

    while (flag != 0x1f) {
        len = sizeof(line);
        memset(line, 0, len);
        if ((ret = read_line(fd, line, &len)) < 0) {
            printf("%s error when reading line.\r\n", __func__);
            return -1;
        }

        /* end of file */
        if (ret == 0) break;
        /* blank line */
        if (line[0] == '\0') continue;

        /* we get a line */
        if ((match = strstr(line, PRODUCT_ID_STR)) != NULL) {
            match += strlen(PRODUCT_ID_STR);
            if (strlen(match) > PRODUCT_ID_MAX) {
                printf("Invalid pi.\r\n");
            } else {
                dinfo->pi = (uint32_t)atoi(match);
                flag |= 0x01;
            }
        } else if ((match = strstr(line, PRODUCT_KEY_STR)) != NULL) {
            match += strlen(PRODUCT_KEY_STR);
            if (strlen(match) > PRODUCT_KEY_MAX) {
                printf("Invalid pk.\r\n");
            } else {
                strncpy(dinfo->pk, match, strlen(match) + 1);
                flag |= 0x02;
            }
        } else if ((match = strstr(line, PRODUCT_SECRET_STR)) != NULL) {
            match += strlen(PRODUCT_SECRET_STR);
            if (strlen(match) > PRODUCT_SECRET_MAX) {
                printf("Invalid ps.\r\n");
            } else {
                strncpy(dinfo->ps, match, strlen(match) + 1);
                flag |= 0x04;
            }
        } else if ((match = strstr(line, DEVICE_NAME_STR)) != NULL) {
            match += strlen(DEVICE_NAME_STR);
            if (strlen(match) > DEVICE_NAME_MAX) {
                printf("Invalid dn.\r\n");
            } else {
                strncpy(dinfo->dn, match, strlen(match) + 1);
                flag |= 0x08;
            }
        } else if ((match = strstr(line, DEVICE_SECRET_STR)) != NULL) {
            match += strlen(DEVICE_SECRET_STR);
            if (strlen(match) > DEVICE_SECRET_MAX) {
                printf("Invalid ds.\r\n");
            } else {
                strncpy(dinfo->ds, match, strlen(match) + 1);
                flag |= 0x10;
            }
        }
    }

    close(fd);

    return flag == 0x1f ? 0 : -1;
}
