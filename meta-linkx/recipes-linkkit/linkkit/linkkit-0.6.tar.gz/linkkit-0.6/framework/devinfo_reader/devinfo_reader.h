#ifndef _DEVINFO_READER_H_
#define _DEVINFO_READER_H_

#include <stdint.h>

typedef struct {
    uint32_t pi;
    char *pk;
    char *ps;
    char *dn;
    char *ds;
} devinfo_set5_t;

int get_devinfo_product_id(uint32_t pi);
int get_devinfo_product_key(char *pk);
int get_devinfo_product_secret(char *ps);
int get_devinfo_device_name(char *dn);
int get_devinfo_device_secret(char *ds);
int get_devinfo_all5(devinfo_set5_t *dinfo);

#endif
