/*
 * Copyright (c) 2014-2016 Alibaba Group. All rights reserved.
 *
 * Alibaba Group retains all right, title and interest (including all
 * intellectual property rights) in and to this computer program, which is
 * protected by applicable intellectual property laws.  Unless you have
 * obtained a separate written license from Alibaba Group., you are not
 * authorized to utilize all or a part of this computer program for any
 * purpose (including reproduction, distribution, modification, and
 * compilation into object code), and you must immediately destroy or
 * return to Alibaba Group all copies of this computer program.  If you
 * are licensed by Alibaba Group, your rights to utilize this computer
 * program are limited by the terms of that license.  To obtain a license,
 * please contact Alibaba Group.
 *
 * This computer program contains trade secrets owned by Alibaba Group.
 * and, unless unauthorized by Alibaba Group in writing, you agree to
 * maintain the confidentiality of this computer program and related
 * information and to not disclose this computer program and related
 * information to any other person or entity.
 *
 * THIS COMPUTER PROGRAM IS PROVIDED AS IS WITHOUT ANY WARRANTIES, AND
 * Alibaba Group EXPRESSLY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED,
 * INCLUDING THE WARRANTIES OF MERCHANTIBILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, TITLE, AND NONINFRINGEMENT.
 */
#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <endian.h>
#include "platform/platform.h"
#include "iot_import_awss.h"
//#include "os.h"


uint32_t os_htole32(uint32_t data)
{
	return htole32(data);
}

uint32_t os_be32toh(uint32_t data)
{
	return be32toh(data);
}

uint32_t os_htobe32(uint32_t data)
{
	return htobe32(data);
}

int awss_debug(const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);

    fflush(stdout);
}

/**
 * @brief   获取Wi-Fi的接受信号强度(`RSSI`)
 *
 * @return  信号强度数值, 单位是dBm
 */
int HAL_Wifi_Get_Rssi_Dbm(void)
{
    //LOGW("awss", "%s not implemented yet!", __func__);
    return 0;
}

/**
 * @brief   使WiFi模组进入省电模式, 并持续一段时间
 *
 * @param   指定在多长时间内, WiFi模组都处于省电模式, 单位是毫秒
 * @retval  0 : 设置成功
 * @retval  -1 : 设置失败
 *
 * @note sample code
 * int HAL_Wifi_Low_Power(int timeout_ms)
 * {
 *      wifi_enter_power_saving_mode();
 *      msleep(timeout_ms);
 *      wifi_exit_power_saving_mode();
 *
 *      return 0;
 * }
 */
int HAL_Wifi_Low_Power(_IN_ int timeout_ms)
{
    //aos_msleep(timeout_ms);
    return 0;
}

/**
 * @brief   获取RF433的接收信号强度(`RSSI`)
 *
 * @return  信号强度数值, 单位是dBm
 */
int HAL_RF433_Get_Rssi_Dbm(void)
{
    //LOGW("awss", "%s not implemented yet!", __func__);
    return 0;
}

/**
 * @brief   获取Wi-Fi网口的MAC地址, 格式应当是"XX:XX:XX:XX:XX:XX"
 *
 * @param   mac_str : 用于存放MAC地址字符串的缓冲区数组
 * @return  指向缓冲区数组起始位置的字符指针
 */
char *HAL_Wifi_Get_Mac(_OU_ char mac_str[18])
{
    snprintf(mac_str, 18, "%02x:%02x:%02x:%02x:%02x:%02x",
             0x01, 0x02, 0x03, 0x04, 0x05, 0x06);

    return mac_str;
}

/**
 * @brief   获取Wi-Fi模块上的操作系统版本字符串
 *
 * @param   version_str : 存放版本字符串的缓冲区数组
 * @return  指向缓冲区数组的起始地址
 */
#define AOS_VERSION_STR "aos1.2.0"
char *HAL_Wifi_Get_Os_Version(_OU_ char version_str[])
{
    return strncpy(version_str, AOS_VERSION_STR, sizeof(AOS_VERSION_STR));
}

/**
 * @brief   获取配网服务(`AWSS`)的超时时间长度, 单位是毫秒
 *
 * @return  超时时长, 单位是毫秒
 * @note    推荐时长是60,0000毫秒
 */
int HAL_Awss_Get_Timeout_Interval_Ms(void)
{
    return 3 * 60 * 1000;
}

/**
 * @brief   获取配网服务(`AWSS`)超时时长到达之后, 去连接默认SSID时的超时时长, 单位是毫秒
 *
 * @return  超时时长, 单位是毫秒
 * @note    推荐时长是0毫秒, 含义是永远持续
 */
int HAL_Awss_Get_Connect_Default_Ssid_Timeout_Interval_Ms(void)
{
    return 0;
}

/**
 * @brief   获取在每个信道(`channel`)上扫描的时间长度, 单位是毫秒
 *
 * @return  时间长度, 单位是毫秒
 * @note    推荐时长是200毫秒到400毫秒
 */
int HAL_Awss_Get_Channelscan_Interval_Ms(void)
{
    return 200;
}

typedef int (*awss_recv_80211_frame_cb_t)(char *buf, int length,
                                          enum AWSS_LINK_TYPE link_type, int with_fcs, signed char rssi);

/**
 * @brief   设置Wi-Fi网卡工作在监听(Monitor)模式, 并在收到802.11帧的时候调用被传入的回调函数
 *
 * @param[in] cb @n A function pointer, called back when wifi receive a frame.
 */
void HAL_Awss_Open_Monitor(_IN_ awss_recv_80211_frame_cb_t cb)
{
}

/**
 * @brief   设置Wi-Fi网卡离开监听(Monitor)模式, 并开始以站点(Station)模式工作
 */
void HAL_Awss_Close_Monitor(void)
{
}

/**
 * @brief   设置Wi-Fi网卡切换到指定的信道(channel)上
 *
 * @param[in] primary_channel @n Primary channel.
 * @param[in] secondary_channel @n Auxiliary channel if 40Mhz channel is supported, currently
 *              this param is always 0.
 * @param[in] bssid @n A pointer to wifi BSSID on which awss lock the channel, most HAL
 *              may ignore it.
 */
void HAL_Awss_Switch_Channel(
    _IN_ char primary_channel,
    _IN_OPT_ char secondary_channel,
    _IN_OPT_ unsigned char bssid[])
{
}

int HAL_Sys_Net_Is_Ready()
{
    //return netmgr_get_ip_state() == true ? 1 : 0;
}

/**
 * @brief   要求Wi-Fi网卡连接指定热点(Access Point)的函数
 *
 * @param[in] connection_timeout_ms @n AP connection timeout in ms or HAL_WAIT_INFINITE
 * @param[in] ssid @n AP ssid
 * @param[in] passwd @n AP passwd
 * @param[in] auth @n optional(AWSS_AUTH_TYPE_INVALID), AP auth info
 * @param[in] encry @n optional(AWSS_ENC_TYPE_INVALID), AP encry info
 * @param[in] bssid @n optional(NULL or zero mac address), AP bssid info
 * @param[in] channel @n optional, AP channel info
 * @return
   @verbatim
     = 0: connect AP & DHCP success
     = -1: connect AP or DHCP fail/timeout
   @endverbatim
 * @see None.
 * @note
 *      If the STA connects the old AP, HAL should disconnect from the old AP firstly.
 */
int HAL_Awss_Connect_Ap(
    _IN_ unsigned int connection_timeout_ms,
    _IN_ char ssid[],
    _IN_ char passwd[],
    _IN_OPT_ enum AWSS_AUTH_TYPE auth,
    _IN_OPT_ enum AWSS_ENC_TYPE encry,
    _IN_OPT_ unsigned char bssid[],
    _IN_OPT_ unsigned char channel)
{
    return -1;
}

#define FRAME_ACTION_MASK       (1 << FRAME_ACTION)
#define FRAME_BEACON_MASK       (1 << FRAME_BEACON)
#define FRAME_PROBE_REQ_MASK    (1 << FRAME_PROBE_REQ)
#define FRAME_PROBE_RESP_MASK   (1 << FRAME_PROBE_RESPONSE)
#define FRAME_DATA_MASK         (1 << FRAME_DATA)

/**
 * @brief   在当前信道(channel)上以基本数据速率(1Mbps)发送裸的802.11帧(raw 802.11 frame)
 *
 * @param[in] type @n see enum HAL_Awss_frame_type, currently only FRAME_BEACON
 *                      FRAME_PROBE_REQ is used
 * @param[in] buffer @n 80211 raw frame, include complete mac header & FCS field
 * @param[in] len @n 80211 raw frame length
 * @return
   @verbatim
   =  0, send success.
   = -1, send failure.
   = -2, unsupported.
   @endverbatim
 * @see None.
 * @note awss use this API send raw frame in wifi monitor mode & station mode
 */
int HAL_Wifi_Send_80211_Raw_Frame(_IN_ enum HAL_Awss_Frame_Type type,
                                  _IN_ unsigned char *buffer, _IN_ int len)
{
    return 0;
}


/**
 * @brief   在站点(Station)模式下使能或禁用对管理帧的过滤
 *
 * @param[in] filter_mask @n see mask macro in enum HAL_Awss_frame_type,
 *                      currently only FRAME_PROBE_REQ_MASK & FRAME_BEACON_MASK is used
 * @param[in] vendor_oui @n oui can be used for precise frame match, optional
 * @param[in] callback @n see awss_wifi_mgmt_frame_cb_t, passing 80211
 *                      frame or ie to callback. when callback is NULL
 *                      disable sniffer feature, otherwise enable it.
 * @return
   @verbatim
   =  0, success
   = -1, fail
   = -2, unsupported.
   @endverbatim
 * @see None.
 * @note awss use this API to filter specific mgnt frame in wifi station mode
 */
int HAL_Wifi_Enable_Mgmt_Frame_Filter(
    _IN_ unsigned int filter_mask,
    _IN_OPT_ unsigned char vendor_oui[3],
    _IN_ awss_wifi_mgmt_frame_cb_t callback)
{
	#if 0
    monitor_cb = callback;

    if (callback != NULL) {
        hal_wlan_register_mgnt_monitor_cb(NULL, mgnt_rx_cb);
    } else {
        hal_wlan_register_mgnt_monitor_cb(NULL, NULL);
    }
#endif
    return 0;
}

/**
 * @brief handle one piece of AP information from wifi scan result
 *
 * @param[in] ssid @n name of AP
 * @param[in] bssid @n mac address of AP
 * @param[in] channel @n AP channel
 * @param[in] rssi @n rssi range[-127, -1].
 *          the higher the RSSI number, the stronger the signal.
 * @param[in] is_last_ap @n this AP information is the last one if is_last_ap > 0.
 *          this AP information is not the last one if is_last_ap == 0.
 * @return 0 for wifi scan is done, otherwise return -1
 * @see None.
 * @note None.
 */
typedef int (*awss_wifi_scan_result_cb_t)(
    const char ssid[],
    const unsigned char bssid[],
    enum AWSS_AUTH_TYPE auth,
    enum AWSS_ENC_TYPE encry,
    unsigned char channel, signed char rssi,
    int is_last_ap);

int HAL_Wifi_Scan(awss_wifi_scan_result_cb_t cb)
{
    return 0;
}

/**
 * @brief   获取所连接的热点(Access Point)的信息
 *
 * @param[out] ssid: array to store ap ssid. It will be null if ssid is not required.
 * @param[out] passwd: array to store ap password. It will be null if ap password is not required.
 * @param[out] bssid: array to store ap bssid. It will be null if bssid is not required.
 * @return
   @verbatim
     = 0: succeeded
     = -1: failed
   @endverbatim
 * @see None.
 * @note None.
 */
int HAL_Wifi_Get_Ap_Info(
    _OU_ char ssid[],
    _OU_ char passwd[],
    _OU_ unsigned char bssid[])
{
	#if 0
    netmgr_ap_config_t config;

    netmgr_get_ap_config(&config);
    if (ssid) {
        strncpy(ssid, config.ssid, PLATFORM_MAX_SSID_LEN);
    }
    if (passwd) {
        strncpy(passwd, config.pwd, PLATFORM_MAX_PASSWD_LEN);
    }
    if (bssid) {
        memcpy(bssid, config.bssid, ETH_ALEN);
    }
#endif
    return 0;
}

#define KEY_LEN 16 // aes 128 cbc

static void dump_content(const unsigned char *data, size_t len)
{
    while (len--) {
        printf("0x%02x ", *data++);
    }
    printf("\r\n");
}

/**
 * @brief   获取`smartconfig`服务的安全等级
 *
 * @param None.
 * @return The security level:
   @verbatim
    0: open (no encrypt)
    1: aes256cfb with default aes-key and aes-iv
    2: aes128cfb with default aes-key and aes-iv
    3: aes128cfb with aes-key per product and aes-iv = 0
    4: aes128cfb with aes-key per device and aes-iv = 0
    5: aes128cfb with aes-key per manufacture and aes-iv = 0
    others: invalid
   @endverbatim
 * @see None.
 * @note The recommended value is 60,000ms.
 */
int HAL_Awss_Get_Encrypt_Type()
{
    return 3;
}

int HAL_Awss_Get_Conn_Encrypt_Type()
{
    return 4;
}



#ifdef __cplusplus
}
#endif
