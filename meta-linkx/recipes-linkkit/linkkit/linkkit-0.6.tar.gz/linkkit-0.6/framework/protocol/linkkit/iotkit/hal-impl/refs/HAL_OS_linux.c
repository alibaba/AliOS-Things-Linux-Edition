/*
 * Copyright (c) 2014-2016 Alibaba Group. All rights reserved.
 * License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */



#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <memory.h>

#include <pthread.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <sys/time.h>
#include <net/if.h>	      // struct ifreq
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <semaphore.h>

#include "iot_import.h"
#include "iot_export.h"

#define KV_FILE_PATH            "/usr/share/linkkit/linkkit.kv"

#define ITEM_MAX_KEY_LEN        128                         /* The max key length for key-value item */
#define ITEM_MAX_VAL_LEN        256                         /* The max value length for key-value item */
#define ITEM_LEN                512

//#define HAL_DEBUG

#ifdef HAL_DEBUG
#define hal_printf     printf
#else
#define hal_printf(...)
#endif

#define __DEMO__

typedef struct {
    int flag;
    int val_len;
    int crc32;
    int reserved[ITEM_LEN - ITEM_MAX_KEY_LEN - ITEM_MAX_VAL_LEN - 12];
}kv_state_t;

typedef struct {
    char key[ITEM_MAX_KEY_LEN];
    char val[ITEM_MAX_VAL_LEN];
    kv_state_t state;
}kv_t;

pthread_mutex_t mutex_kv = PTHREAD_MUTEX_INITIALIZER;

#ifdef __DEMO__
char _product_key[PRODUCT_KEY_LEN + 1];
char _product_secret[41 + 1];
char _device_name[DEVICE_NAME_LEN + 1];
char _device_secret[DEVICE_SECRET_LEN + 1];
#endif

void *HAL_SemaphoreCreate(void)
{
    sem_t *sem = (sem_t *)malloc(sizeof(sem_t));
    if (NULL == sem) {
        return NULL;
    }

    if (0 != sem_init(sem, 0, 0)) {
        free(sem);
        return NULL;
    }

    return sem;
}

void HAL_SemaphoreDestroy(_IN_ void *sem)
{
    sem_destroy((sem_t *)sem);
    free(sem);
}

void HAL_SemaphorePost(_IN_ void *sem)
{
    sem_post((sem_t *)sem);
}

int HAL_SemaphoreWait(_IN_ void *sem, _IN_ uint32_t timeout_ms)
{
    if (PLATFORM_WAIT_INFINITE == timeout_ms) {
        sem_wait(sem);
        return 0;
    } else {
        struct timespec ts;
        int s;
        /* Restart if interrupted by handler */
        do {
            if (clock_gettime(CLOCK_REALTIME, &ts) == -1) {
                return -1;
            }

            s = 0;
            ts.tv_nsec += (timeout_ms % 1000) * 1000000;
            if (ts.tv_nsec >= 1000000000) {
                ts.tv_nsec -= 1000000000;
                s = 1;
            }

            ts.tv_sec += timeout_ms / 1000 + s;

        } while (((s = sem_timedwait(sem, &ts)) != 0) && errno == EINTR);

        return (s == 0) ? 0 : -1;
    }
}

int HAL_ThreadCreate(
            _OU_ void **thread_handle,
            _IN_ void *(*work_routine)(void *),
            _IN_ void *arg,
            _IN_ hal_os_thread_param_t *hal_os_thread_param,
            _OU_ int *stack_used)
{
    int ret = -1;
    if(stack_used != NULL)
        *stack_used = 0;

    ret = pthread_create((pthread_t *)thread_handle, NULL, work_routine, arg);

    return ret;
}

void HAL_ThreadDetach(_IN_ void *thread_handle)
{
    pthread_detach((pthread_t)thread_handle);
}

void HAL_ThreadDelete(_IN_ void *thread_handle)
{
    if (NULL == thread_handle) {
        pthread_exit(0);
    } else {
        /*main thread delete child thread*/
        pthread_cancel((pthread_t)thread_handle);
    }
}

void *HAL_MutexCreate(void)
{
    pthread_mutex_t *mutex = (pthread_mutex_t *)HAL_Malloc(sizeof(pthread_mutex_t));
    if (NULL == mutex) {
        return NULL;
    }

    if (0 != pthread_mutex_init(mutex, NULL)) {
        fprintf(stderr, "create mutex failed");
        HAL_Free(mutex);
        return NULL;
    }
    
    hal_printf("HAL_MutexCreate:%p\n", mutex);

    return mutex;
}

void HAL_MutexDestroy(_IN_ void *mutex)
{
    if(mutex == NULL)
        return;

    if (0 != pthread_mutex_destroy((pthread_mutex_t *)mutex)) {
        fprintf(stderr, "destroy mutex failed");
    }

    hal_printf("HAL_MutexDestroy:%p\n", mutex);

    HAL_Free(mutex);
}

void HAL_MutexLock(_IN_ void *mutex)
{
    if(mutex == NULL)
        return;

    if (0 != pthread_mutex_lock((pthread_mutex_t *)mutex)) {
        fprintf(stderr, "lock mutex failed");
    }

    //hal_printf("HAL_MutexLock:%p\n", mutex);
}

void HAL_MutexUnlock(_IN_ void *mutex)
{
    if(mutex == NULL)
        return;

    if (0 != pthread_mutex_unlock((pthread_mutex_t *)mutex)) {
        fprintf(stderr, "unlock mutex failed");
    }

    //hal_printf("HAL_MutexUnlock:%p\n", mutex);
}

void *HAL_Malloc(_IN_ uint32_t size)
{
    return malloc(size);
}

void HAL_Free(_IN_ void *ptr)
{
    if(ptr == NULL)
    {
        return;
    }
    free(ptr);
}

#ifdef __APPLE__
uint64_t HAL_UptimeMs(void)
{
    struct timeval tv = { 0 };
    uint64_t time_ms;

    gettimeofday(&tv, NULL);

    time_ms = tv.tv_sec * 1000 + tv.tv_usec / 1000;

    return time_ms;
}
#else
uint64_t HAL_UptimeMs(void)
{
    uint64_t            time_ms;
    struct timespec     ts;

    clock_gettime(CLOCK_MONOTONIC, &ts);
    time_ms = ((uint64_t)ts.tv_sec * (uint64_t)1000) + (ts.tv_nsec / 1000 / 1000);

    return time_ms;
}
#endif

void HAL_SleepMs(_IN_ uint32_t ms)
{
    usleep(1000 * ms);
}

void HAL_Srandom(uint32_t seed)
{
    srandom(seed);
}

uint32_t HAL_Random(uint32_t region)
{
    return (region > 0) ? (random() % region) : 0;
}

int HAL_Snprintf(_IN_ char *str, const int len, const char *fmt, ...)
{
    va_list args;
    int     rc;

    va_start(args, fmt);
    rc = vsnprintf(str, len, fmt, args);
    va_end(args);

    return rc;
}

int HAL_Vsnprintf(_IN_ char *str, _IN_ const int len, _IN_ const char *format, va_list ap)
{
    return vsnprintf(str, len, format, ap);
}

void HAL_Printf(_IN_ const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);

    fflush(stdout);
}

// int HAL_GetPartnerID(char* pid_str)
// {
//     memset(pid_str, 0x0, PID_STRLEN_MAX);
// #ifdef __DEMO__
//     strcpy(pid_str, "example.demo.partner-id");
// #endif
//     return strlen(pid_str);
// }

// int HAL_GetModuleID(char* mid_str)
// {
//     memset(mid_str, 0x0, MID_STRLEN_MAX);
// #ifdef __DEMO__
//     strcpy(mid_str, "example.demo.module-id");
// #endif
//     return strlen(mid_str);
// }


// char *HAL_GetChipID(_OU_ char* cid_str)
// {
//     memset(cid_str, 0x0, HAL_CID_LEN);
// #ifdef __DEMO__
//     strncpy(cid_str, "rtl8188eu 12345678", HAL_CID_LEN);
//     cid_str[HAL_CID_LEN - 1] = '\0';
// #endif
//     return cid_str;
// }


// int HAL_GetDeviceID(_OU_ char* device_id)
// {
//     memset(device_id, 0x0, DEVICE_ID_LEN);
// #ifdef __DEMO__
//     HAL_Snprintf(device_id, DEVICE_ID_LEN, "%s.%s", _product_key, _device_name);
//     device_id[DEVICE_ID_LEN - 1] = '\0';
// #endif

//     return strlen(device_id);
// }


// int HAL_SetProductKey(_IN_ char* product_key)
// {
//     int len = strlen(product_key);
// #ifdef __DEMO__
//     if (len > PRODUCT_KEY_LEN) return -1;
//     memset(_product_key, 0x0, PRODUCT_KEY_LEN + 1);
//     strncpy(_product_key, product_key, len);
// #endif
//     return len;
// }


// int HAL_SetDeviceName(_IN_ char* device_name)
// {
//     int len = strlen(device_name);
// #ifdef __DEMO__
//     if (len > DEVICE_NAME_LEN) return -1;
//     memset(_device_name, 0x0, DEVICE_NAME_LEN + 1);
//     strncpy(_device_name, device_name, len);
// #endif
//     return len;
// }


// int HAL_SetDeviceSecret(_IN_ char* device_secret)
// {
//     int len = strlen(device_secret);
// #ifdef __DEMO__
//     if (len > DEVICE_SECRET_LEN) return -1;
//     memset(_device_secret, 0x0, DEVICE_SECRET_LEN + 1);
//     strncpy(_device_secret, device_secret, len);
// #endif
//     return len;
// }


// int HAL_SetProductSecret(_IN_ char* product_secret)
// {
//     int len = strlen(product_secret);
// #ifdef __DEMO__
//     if (len > 41) return -1;
//     memset(_product_secret, 0x0, 41 + 1);
//     strncpy(_product_secret, product_secret, len);
// #endif
//     return len;
// }

// int HAL_GetProductKey(_OU_ char* product_key)
// {
//     int len = strlen(_product_key);
//     memset(product_key, 0x0, PRODUCT_KEY_LEN);

// #ifdef __DEMO__
//     strncpy(product_key, _product_key, len);
// #endif

//     return len;
// }

// int HAL_GetProductSecret(_OU_ char* product_secret)
// {
//     int len = strlen(_product_secret);
//     memset(product_secret, 0x0, 41);

// #ifdef __DEMO__
//     strncpy(product_secret, _product_secret, len);
// #endif

//     return len;
// }

// int HAL_GetDeviceName(_OU_ char* device_name)
// {
//     int len = strlen(_device_name);
//     memset(device_name, 0x0, DEVICE_NAME_LEN);

// #ifdef __DEMO__
//     strncpy(device_name, _device_name, len);
// #endif

//     return strlen(device_name);
// }

// int HAL_GetDeviceSecret(_OU_ char* device_secret)
// {
//     int len = strlen(_device_secret);
//     memset(device_secret, 0x0, DEVICE_SECRET_LEN);

// #ifdef __DEMO__
//     strncpy(device_secret, _device_secret, len);
// #endif

//     return len;
// }


// int HAL_GetFirmwareVesion(_OU_ char* version)
// {
//     char *ver = "1.0";
//     int len = strlen(ver);
//     memset(version, 0x0, FIRMWARE_VERSION_MAXLEN);
// #ifdef __DEMO__
//     strncpy(version, ver, len);
//     version[len] = '\0';
// #endif
//     return strlen(version);
// }

static FILE *fp;

#define otafilename "/tmp/alinkota.bin"

void HAL_Firmware_Persistence_Start(void)
{
#ifdef __DEMO__
    fp = fopen(otafilename, "w");
//    assert(fp);
#endif
    return;
}

int HAL_Firmware_Persistence_Write(_IN_ char *buffer, _IN_ uint32_t length)
{
#ifdef __DEMO__
    unsigned int written_len = 0;
    written_len = fwrite(buffer, 1, length, fp);

    if (written_len != length) {
        return -1;
    }
#endif
    return 0;
}

int HAL_Firmware_Persistence_Stop(void)
{
#ifdef __DEMO__
    if (fp != NULL) {
        fclose(fp);
    }
#endif

    /* check file md5, and burning it to flash ... finally reboot system */

    return 0;
}

int HAL_Config_Write(const char *buffer, int length)
{
    FILE *fp;
    size_t written_len;
    char filepath[128] = {0};

    if (!buffer || length <= 0) {
        return -1;
    }

    snprintf(filepath, sizeof(filepath), "./%s", "alinkconf");
    fp = fopen(filepath, "w");
    if (!fp) {
        return -1;
    }

    written_len = fwrite(buffer, 1, length, fp);

    fclose(fp);

    return ((written_len != length) ? -1 : 0);
}

int HAL_Config_Read(char *buffer, int length)
{
    FILE *fp;
    size_t read_len;
    char filepath[128] = {0};

    if (!buffer || length <= 0) {
        return -1;
    }

    snprintf(filepath, sizeof(filepath), "./%s", "alinkconf");
    fp = fopen(filepath, "r");
    if (!fp) {
        return -1;
    }

    read_len = fread(buffer, 1, length, fp);
    fclose(fp);

    return ((read_len != length) ? -1 : 0);
}

#define REBOOT_CMD "reboot"
void HAL_Sys_reboot(void)
{
    if (system(REBOOT_CMD)) {
        perror("HAL_Sys_reboot failed");
    }
}

#define ROUTER_INFO_PATH        "/proc/net/route"
#define ROUTER_RECORD_SIZE      256

char *_get_default_routing_ifname(char *ifname, int ifname_size)
{
    FILE *fp = NULL;
    char line[ROUTER_RECORD_SIZE] = {0};
    char iface[IFNAMSIZ] = {0};
    char *result = NULL;
    unsigned int destination, gateway, flags, mask;
    unsigned int refCnt, use, metric, mtu, window, irtt;

    fp = fopen(ROUTER_INFO_PATH, "r");
    if (fp == NULL) {
        perror("fopen");
        return result;
    }

    char *buff = fgets(line, sizeof(line), fp);
    if (buff == NULL) {
        perror("fgets");
        goto out;
    }

    while (fgets(line, sizeof(line), fp)) {
        if (11 !=
            sscanf(line, "%s %08x %08x %x %d %d %d %08x %d %d %d",
                   iface, &destination, &gateway, &flags, &refCnt, &use,
                   &metric, &mask, &mtu, &window, &irtt)) {
            perror("sscanf");
            continue;
        }

        /*default route */
        if ((destination == 0) && (mask == 0)) {
            strncpy(ifname, iface, ifname_size - 1);
            result = ifname;
            break;
        }
    }

out:
    if (fp) {
        fclose(fp);
    }

    return result;
}


uint32_t HAL_Wifi_Get_IP(char ip_str[NETWORK_ADDR_LEN], const char *ifname)
{
    struct ifreq ifreq;
    int sock = -1;
    char ifname_buff[IFNAMSIZ] = {0};

    if((NULL == ifname || strlen(ifname) == 0) &&
        NULL == (ifname = _get_default_routing_ifname(ifname_buff, sizeof(ifname_buff)))){
        perror("get default routeing ifname");
        return -1;
    }

    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("socket");
        return -1;
    }

    ifreq.ifr_addr.sa_family = AF_INET; //ipv4 address
    strncpy(ifreq.ifr_name, ifname, IFNAMSIZ - 1);

    if (ioctl(sock, SIOCGIFADDR, &ifreq) < 0) {
        close(sock);
        perror("ioctl");
        return -1;
    }

    close(sock);

    strncpy(ip_str,
            inet_ntoa(((struct sockaddr_in *)&ifreq.ifr_addr)->sin_addr),
            NETWORK_ADDR_LEN);

    return ((struct sockaddr_in *)&ifreq.ifr_addr)->sin_addr.s_addr;
}


/*!
 * @brief compute word's crc32
 *
 * @param[in] data : input word
 *
 * @return value of crc32
 */
static unsigned int _hal_crc32_value(unsigned int data)
{
    register unsigned int crc = data;
    register unsigned int polynomial = 0xedb88320;

    for (unsigned int i = 8 ; i > 0; i--)
    {
        if (crc & 1)
            crc = (crc >> 1) ^ polynomial;
        else
            crc >>= 1;
    }
    return crc;
}

/*!
 * @brief compute block's crc
 *
 * @param[in] buffer : pointer of buffer
 *
 * @param[in] size   : number of block in byte
 *
 * @return crc of block memory
 */
static unsigned int _hal_crc32_block(const unsigned char *buffer, unsigned int size)
{
    register unsigned int crc = 0xffffffff;

    while (size--)
        crc = _hal_crc32_value((crc ^ *buffer++) & 0xff) ^ (crc >> 8);
    crc ^= 0xffffffff;

    return crc;
}

/* get file size and item num */
static int _hal_fopen(FILE **fp, int *size, int *num)
{
    /* create an file to save the kv */
    if((*fp = fopen(KV_FILE_PATH, "rb+")) == NULL)
    {
        fprintf(stderr, "fopen(create) %s error:%s\n", KV_FILE_PATH, strerror(errno));
        return -1;
    }

    fseek(*fp, 0L, SEEK_END);

    printf("ftell:%d\n", (int)ftell(*fp));
    if((*size = ftell(*fp)) % ITEM_LEN)
    {
        fprintf(stderr, "%s is not an kv file\n", KV_FILE_PATH);
        fclose(*fp);
        return -1;
    }

    *num = ftell(*fp) / ITEM_LEN;

    fseek(*fp, 0L, SEEK_SET);

    hal_printf("file size:%d, block num:%d\n", *size, *num);

    return 0;
}

/* pthread mutex protect? */
int HAL_Kv_Set(const char *key, const void *val, int len, int sync)
{
    FILE *fp = NULL;
    int file_size = 0, block_num = 0, same_kv = 0, ret = 0, cur_pos = 0;
    kv_t kv_item;

    /* check parameter */
    if(key == NULL || val == NULL)
    {
        return -1;
    }

    pthread_mutex_lock(&mutex_kv);

    if(_hal_fopen(&fp, &file_size, &block_num) != 0)
    {
        goto _hal_set_error;
    }

    for(int i = 0; i < block_num; i++)
    {
        memset(&kv_item, 0, sizeof(kv_t));
        cur_pos = ftell(fp);
        //fseek(fp, i * ITEM_LEN, SEEK_SET);
        //printf("cur pos:%d\n", cur_pos);
        /* read an kv item(512 bytes) from file */
        if((ret = fread(&kv_item, 1, ITEM_LEN, fp)) != ITEM_LEN)
        {
            goto _hal_set_error;
        }

        /* key compared */
        if(strcmp(kv_item.key, key) == 0)
        {
            hal_printf("HAL_Kv_Set@key compared:%s\n", key);
            /* set value and write to file */
            memset(kv_item.val, 0, ITEM_MAX_VAL_LEN);
            memcpy(kv_item.val, val, len);
            kv_item.state.val_len = len;
            kv_item.state.crc32 = _hal_crc32_block(val, len);
            fseek(fp, cur_pos, SEEK_SET);
            fwrite(&kv_item, 1, ITEM_LEN, fp);
            
            goto _hal_set_ok;
        }
    }

    hal_printf("HAL_Kv_Set key:%s\n", key);
    /* key not compared, append an kv to file */
    memset(&kv_item, 0, sizeof(kv_t));
    strcpy(kv_item.key, key);
    memcpy(kv_item.val, val, len);
    kv_item.state.val_len = len;
    kv_item.state.crc32 = _hal_crc32_block(val, len);

    fseek(fp, 0L, SEEK_END);
    fwrite(&kv_item, 1, ITEM_LEN, fp);
    
    goto _hal_set_ok;

_hal_set_error:
    if(fp == NULL)
    {
        pthread_mutex_unlock(&mutex_kv);
        return -1;
    }
    fprintf(stderr, "read %s error:%s\n", KV_FILE_PATH, strerror(errno));
    fflush(fp);
    fclose(fp);
    pthread_mutex_unlock(&mutex_kv);

    return -1;
_hal_set_ok:
    fflush(fp);
    fclose(fp);
    pthread_mutex_unlock(&mutex_kv);

    return 0;
}

/* 0: get key ok  
   -1: get key failed or read file error
*/
int HAL_Kv_Get(const char *key, void *buffer, int *buffer_len)
{
    FILE *fp = NULL;
    /* read from file */
    int file_size = 0, block_num = 0, same_kv = 0;
    kv_t kv_item;

    /* check parameter */
    if(key == NULL || buffer == NULL || buffer_len == NULL)
    {
        return -1;
    }

    pthread_mutex_lock(&mutex_kv);

    if(_hal_fopen(&fp, &file_size, &block_num) != 0)
    {
        goto _hal_get_error;
    }

    for(int i = 0; i < block_num; i++)
    {
        memset(&kv_item, 0, sizeof(kv_t));

        /* read an kv item(512 bytes) from file */
        if(fread(&kv_item, 1, ITEM_LEN, fp) != ITEM_LEN)
        {
            goto _hal_get_error;
        }

        /* key compared */
        if(strcmp(kv_item.key, key) == 0)
        {
            hal_printf("HAL_Kv_Get@key compared:%s\n", key);

            /* set value and write to file */
            *buffer_len = kv_item.state.val_len;
            memcpy(buffer, kv_item.val, *buffer_len);
            
            goto _hal_get_ok;
        }
    }

    hal_printf("can not find the key:%s\n", key);

    goto _hal_get_ok;

_hal_get_error:
    if(fp == NULL)
    {
        pthread_mutex_unlock(&mutex_kv);
        return -1;
    }
    fprintf(stderr, "read %s error:%s\n", KV_FILE_PATH, strerror(errno));
    fflush(fp);
    fclose(fp);
    pthread_mutex_unlock(&mutex_kv);

    return -1;
_hal_get_ok:
    fflush(fp);
    fclose(fp);
    pthread_mutex_unlock(&mutex_kv);

    return 0;
}

int HAL_Kv_Del(const char *key)
{
    FILE *fp = NULL;
    /* read from file */
    int file_size = 0, block_num = 0, same_kv = 0, cur_pos = 0;
    kv_t kv_item;
    kv_t kv_item_last;

    /* check parameter */
    if(key == NULL)
    {
        return -1;
    }

    pthread_mutex_lock(&mutex_kv);

    if(_hal_fopen(&fp, &file_size, &block_num) != 0)
    {
        goto _hal_del_error;
    }

    for(int i = 0; i < block_num; i++)
    {
        memset(&kv_item, 0, sizeof(kv_t));
        cur_pos = ftell(fp);

        /* read an kv item(512 bytes) from file */
        if(fread(&kv_item, 1, ITEM_LEN, fp) != ITEM_LEN)
        {
            goto _hal_del_error;
        }

        /* key compared */
        if(strcmp(kv_item.key, key) == 0)
        {
            /* use last kv item merge this kv item and delete the last kv item */
            hal_printf("HAL_Kv_Del@key compared:%s, cur_pos:%d\n", kv_item.key, cur_pos);
            
            /* fp pointer to last kv item */
            fseek(fp, -ITEM_LEN, SEEK_END);
            /* read an kv item(512 bytes) from file */
            if(fread(&kv_item_last, 1, ITEM_LEN, fp) != ITEM_LEN)
            {
                goto _hal_del_error;
            }

            hal_printf("last item key:%s, val:%s\n", kv_item_last.key, kv_item_last.val);

            /* pointer to currect kv item */
            fseek(fp, cur_pos, SEEK_SET);
            fwrite(&kv_item_last,1, ITEM_LEN, fp);
            goto _hal_del_ok;
        }
    }
    hal_printf("HAL_Kv_Del@ can not find the key:%s\n", key);
    goto _hal_del_ok;

_hal_del_error:
    if(fp == NULL)
    {
        pthread_mutex_unlock(&mutex_kv);
        return -1;
    }
    fprintf(stderr, "read %s error:%s\n", KV_FILE_PATH, strerror(errno));
    fflush(fp);
    fclose(fp);
    pthread_mutex_unlock(&mutex_kv);

    return -1;
_hal_del_ok:

    fflush(fp);
    fclose(fp);
    if(truncate(KV_FILE_PATH, file_size - ITEM_LEN) != 0)
    {
        fprintf(stderr, "truncate %s error:%s\n", KV_FILE_PATH, strerror(errno));
        pthread_mutex_unlock(&mutex_kv);
        return -1;
    }
    pthread_mutex_unlock(&mutex_kv);

    return 0;
}

int HAL_Erase_All_Kv(void)
{
    FILE *fp = NULL;

    pthread_mutex_lock(&mutex_kv);

    hal_printf("HAL_Erase_All_Kv\n");

    if(truncate(KV_FILE_PATH, 0) != 0)
    {
        fprintf(stderr, "truncate %s error:%s\n", KV_FILE_PATH, strerror(errno));
        pthread_mutex_unlock(&mutex_kv);
        return -1;
    }

    pthread_mutex_unlock(&mutex_kv);
    return 0;
}

/* posix timer is thread-safe, ref:http://pubs.opengroup.org/onlinepubs/9699919799/functions/V2_chap02.html#tag_15_09_01 */
void *HAL_Timer_Create(const char *name, void (*func)(void *), void *user_data)
{
    timer_t *timer = NULL;

    struct sigevent ent;

    /* unused */
    //(void)name;

    /* check parameter */
    if(func == NULL)    return NULL;

    timer = (timer_t *)malloc(sizeof(time_t));
    if (!timer) {
        fprintf(stderr, "%s malloc failed", __func__);
        return NULL;
    }

    /* Init */
    memset(&ent, 0x00, sizeof(struct sigevent));
    
    /* create a timer */
    ent.sigev_notify = SIGEV_THREAD;
    ent.sigev_notify_function = (void (*)(union sigval))func;
    ent.sigev_value.sival_ptr = user_data;

    hal_printf("HAL_Timer_Create:%p\n", timer);

    if(timer_create(CLOCK_MONOTONIC, &ent, timer) != 0) {
        fprintf(stderr, "timer_create");
        return NULL;
    }

    return (void *)timer;
}

int HAL_Timer_Start(void *timer, int ms)
{
    struct itimerspec ts;

    /* check parameter */
    if(timer == NULL)   return -1;

    /* it_interval=0: timer run only once */
    ts.it_interval.tv_sec = 0;
    ts.it_interval.tv_nsec = 0;

    /* it_value=0: stop timer */
    ts.it_value.tv_sec = ms / 1000;
    ts.it_value.tv_nsec = (ms % 1000) * 1000;

    hal_printf("HAL_Timer_Start:%p\n", timer);

    return timer_settime(*(timer_t *)timer, 0, &ts, NULL);
}

int HAL_Timer_Stop(void *timer)
{
    struct itimerspec ts;

    /* check parameter */
    if(timer == NULL)   return -1;

    /* it_interval=0: timer run only once */
    ts.it_interval.tv_sec = 0;
    ts.it_interval.tv_nsec = 0;

    /* it_value=0: stop timer */
    ts.it_value.tv_sec = 0;
    ts.it_value.tv_nsec = 0;

    hal_printf("HAL_Timer_Stop:%p\n", timer);

    return timer_settime(*(timer_t *)timer, 0, &ts, NULL);
}

int HAL_Timer_Delete(void *timer)
{
    int ret = 0;

    /* check parameter */
    if(timer == NULL)   return -1;

    hal_printf("HAL_Timer_Delete:%p\n", timer);

    ret = timer_delete(*(timer_t *)timer);

    free(timer);

    return ret;
}
