#ifndef _DEV_INFO_H_
#define _DEV_INFO_H_

/* for demo only, subject to change to user's specific ones. */
#if 0
#ifdef PRODUCT_ID
#undef PRODUCT_ID
#endif
#define PRODUCT_ID     577245

#ifdef DEVICE_SECRET
#undef DEVICE_SECRET
#endif
#define DEVICE_SECRET  "W4UaIZDWmfmTKgI0rU1YpIJko5dV2mGJ"

#ifdef DEVICE_NAME
#undef DEVICE_NAME
#endif
#define DEVICE_NAME    "xGvGuHkbk2845Ta3vZUy"

#ifdef PRODUCT_KEY
#undef PRODUCT_KEY
#endif
#define PRODUCT_KEY    "a1qWr3Wk3Oo"

#ifdef PRODUCT_SECRET
#undef PRODUCT_SECRET
#endif
#define PRODUCT_SECRET "oFTYrP7idjkYEBL9"

#else

#ifdef PRODUCT_ID
#undef PRODUCT_ID
#endif
#define PRODUCT_ID     213226

#ifdef DEVICE_SECRET
#undef DEVICE_SECRET
#endif
#define DEVICE_SECRET  "cNwnA4W7amnkgG6s8zGXSJD3nI1c7kO1"

#ifdef DEVICE_NAME
#undef DEVICE_NAME
#endif
#define DEVICE_NAME    "112233445566"

#ifdef PRODUCT_KEY
#undef PRODUCT_KEY
#endif
#define PRODUCT_KEY    "b1XVhqfan1X"

#ifdef PRODUCT_SECRET
#undef PRODUCT_SECRET
#endif
#define PRODUCT_SECRET "iX6XqAjaCTXBv4h3"

#endif

#endif
