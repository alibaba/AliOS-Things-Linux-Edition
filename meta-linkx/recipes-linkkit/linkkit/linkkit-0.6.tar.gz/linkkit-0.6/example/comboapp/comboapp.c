/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/reboot.h>
#include <pthread.h>
#include <netmgr.h>
#include <wifi.h>
#include <signal.h>
#include <api_export.h>
#include "linkkit_export.h"
#include "iot_import.h"
#include "tls_str.h"
#include "devinfo_reader.h"
#include "ota_service.h"

// ---------

#include "../../framework/protocol/linkkit/iotkit/base/event/iot_export_event.h"

#define AWSS_COMFIRM_FILE "/tmp/.enable_combo"

#define LINKKIT_PRINTF(...)  \
    do {                                                     \
        printf("\e[0;32m%s@line%d:\t", __FUNCTION__, __LINE__);  \
        printf(__VA_ARGS__);                                 \
        printf("\e[0m");                                   \
    } while (0)

/* identifier of property/service/event, users should modify this macros according to your own product TSL. */
#define EVENT_ERROR_IDENTIFIER                 "Error"
#define EVENT_ERROR_OUTPUT_INFO_IDENTIFIER     "ErrorCode"
#define EVENT_CUSTOM_IDENTIFIER                "Custom"

/* specify ota buffer size for ota service, ota service will use this buffer for bin download. */
#define OTA_BUFFER_SIZE                  (512+1)
/* PLEASE set RIGHT tsl string according to your product. */

int awss_success_notify();
static void notify_wifi_status(void *arg);
static void* combo_work(void *arg);
static void linkkit_event_monitor(int event);
static void combo_apinfo_ready_handler(breeze_apinfo_t *info);
void set_iotx_info();

static int             linkkit_started = 0;
static int             awss_running    = 0;
static bool            is_ble_connected = false;
static breeze_apinfo_t apinfo;
static bool awss_success = false;
static bool ota_enabled = true;
static bool ota_started = false;
static uint8_t connect_type;

enum {
    CONNECT_TYPE_WIFI,
    CONNECT_TYPE_COMBO,
    CONNECT_TYPE_ETH,
};

/* user sample context struct. */
typedef struct _sample_context {
    const void*   thing;
    int           cloud_connected;
#ifdef LOCAL_CONN_ENABLE
    int           local_connected;
#endif
    int           thing_enabled;

    int           service_custom_input_transparency;
    int           service_custom_output_contrastratio;
#ifdef SERVICE_OTA_ENABLED
    char          ota_buffer[OTA_BUFFER_SIZE];
#endif /* SERVICE_OTA_ENABLED */
} sample_context_t;

sample_context_t g_sample_context;

#define EVENT_CUSTOM_INFO		"test_info"
#define EVENT_CUSTOM_WARN		"test_warnning"
#define EVENT_CUSTOM_ERROR		"test_error"

void post_property_cb(const void* thing_id, int respons_id, int code, const char* response_message, void* ctx)
{
    LINKKIT_PRINTF("thing@%p: response arrived:\nid:%d\tcode:%d\tmessage:%s\n", thing_id, respons_id, code, response_message == NULL ? "NULL" : response_message);
}

#ifdef SERVICE_OTA_ENABLED
/* callback function for fota service. */
static void fota_callback(service_fota_callback_type_t callback_type, const char* version)
{
    sample_context_t* sample_ctx;

    assert(callback_type < service_fota_callback_type_number);

    sample_ctx = &g_sample_context;

    /* temporarily disable thing when ota service invoked */
    sample_ctx->thing_enabled = 0;

    linkkit_invoke_ota_service(sample_ctx->ota_buffer, OTA_BUFFER_SIZE);

    sample_ctx->thing_enabled = 1;

    /* reboot the device... */
}
#endif /* SERVICE_OTA_ENABLED */
#ifdef LOCAL_CONN_ENABLE
static int on_connect(void* ctx, int cloud)
#else
static int on_connect(void* ctx)
#endif
{
    sample_context_t* sample_ctx = ctx;

#ifdef LOCAL_CONN_ENABLE
    if (cloud) {
        sample_ctx->cloud_connected = 1;
    } else {
        sample_ctx->local_connected = 1;
    }
    LINKKIT_PRINTF("%s is connected\n", cloud ? "cloud" : "local");
#else
    sample_ctx->cloud_connected = 1;
    LINKKIT_PRINTF("%s is connected\n", "cloud");
#endif

    if (ota_enabled && cloud && !ota_started) {
        ota_service_init(NULL);
        ota_started = true;
    }

    return 0;
}

#ifdef LOCAL_CONN_ENABLE
static int on_disconnect(void* ctx, int cloud)
#else
static int on_disconnect(void* ctx)
#endif
{
    sample_context_t* sample_ctx = ctx;

#ifdef LOCAL_CONN_ENABLE
    if (cloud) {
        sample_ctx->cloud_connected = 0;
    } else {
        sample_ctx->local_connected = 0;
    }
    LINKKIT_PRINTF("%s is disconnect\n", cloud ? "cloud" : "local");
#else
    sample_ctx->cloud_connected = 0;
    LINKKIT_PRINTF("%s is disconnect\n", "cloud");
#endif
    return 0;
}

static int raw_data_arrived(const void* thing_id, const void* data, int len, void* ctx)
{
    char raw_data[128] = {0};

    LINKKIT_PRINTF("raw data arrived,len:%d\n", len);

    /* do user's raw data process logical here. */

    /* ............................... */

    /* user's raw data process logical complete */

    snprintf(raw_data, sizeof(raw_data), "test down raw reply data %lld", (long long)HAL_UptimeMs());

    linkkit_invoke_raw_service(thing_id, 0, raw_data, strlen(raw_data));

    return 0;
}

static int thing_create(const void* thing_id, void* ctx)
{
    sample_context_t* sample_ctx = ctx;

    LINKKIT_PRINTF("new thing@%p created.\n", thing_id);
    sample_ctx->thing = thing_id;

    return 0;
}

static int thing_enable(const void* thing_id, void* ctx)
{
    sample_context_t* sample_ctx = ctx;

    sample_ctx->thing_enabled = 1;

    return 0;
}

static int thing_disable(const void* thing_id, void* ctx)
{
    sample_context_t* sample_ctx = ctx;

    sample_ctx->thing_enabled = 0;

    return 0;
}
#ifdef RRPC_ENABLED
static int handle_service_custom(sample_context_t* _sample_ctx, const void* thing, const char* service_identifier, int request_id, int rrpc)
#else
static int handle_service_custom(sample_context_t* _sample_ctx, const void* thing, const char* service_identifier, int request_id)
#endif /* RRPC_ENABLED */
{
    char identifier[128] = {0};
    sample_context_t* sample_ctx = _sample_ctx;

    /*
     * get iutput value.
     */
    snprintf(identifier, sizeof(identifier), "%s.%s", service_identifier, "transparency");
    linkkit_get_value(linkkit_method_get_service_input_value, thing, identifier, &sample_ctx->service_custom_input_transparency, NULL);

    /*
     * set output value according to user's process result.
     */

    snprintf(identifier, sizeof(identifier), "%s.%s", service_identifier, "Contrastratio");

    sample_ctx->service_custom_output_contrastratio = sample_ctx->service_custom_input_transparency >= 0 ? sample_ctx->service_custom_input_transparency : sample_ctx->service_custom_input_transparency * -1;

    linkkit_set_value(linkkit_method_set_service_output_value, thing, identifier, &sample_ctx->service_custom_output_contrastratio, NULL);
#ifdef RRPC_ENABLED
    linkkit_answer_service(thing, service_identifier, request_id, 200, rrpc);
#else
    linkkit_answer_service(thing, service_identifier, request_id, 200);
#endif /* RRPC_ENABLED */

    return 0;
}
#ifdef RRPC_ENABLED
static int thing_call_service(const void* thing_id, const char* service, int request_id, int rrpc, void* ctx)
#else
static int thing_call_service(const void* thing_id, const char* service, int request_id, void* ctx)
#endif /* RRPC_ENABLED */
{
    sample_context_t* sample_ctx = ctx;

    LINKKIT_PRINTF("service(%s) requested, id: thing@%p, request id:%d\n",
                   service, thing_id, request_id);

    if (strcmp(service, "Custom") == 0) {
#ifdef RRPC_ENABLED
        handle_service_custom(sample_ctx, thing_id, service, request_id, rrpc);
#else
        handle_service_custom(sample_ctx, thing_id, service, request_id);
#endif /* RRPC_ENABLED */
    }

    return 0;
}

static int thing_prop_changed(const void* thing_id, const char* property, void* ctx)
{
    char* value_str = NULL;
    char property_buf[64] = {0};

    /* get new property value */
    if (strstr(property, "HSVColor") != 0) {
        int hue, saturation, value;

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Hue");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &hue, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Saturation");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &saturation, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Value");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &value, &value_str);

        LINKKIT_PRINTF("property(%s), Hue:%d, Saturation:%d, Value:%d\n", property, hue, saturation, value);

        /* XXX: do user's process logical here. */
    } else if (strstr(property, "HSLColor") != 0) {
        int hue, saturation, lightness;

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Hue");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &hue, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Saturation");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &saturation, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Lightness");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &lightness, &value_str);

        LINKKIT_PRINTF("property(%s), Hue:%d, Saturation:%d, Lightness:%d\n", property, hue, saturation, lightness);
        /* XXX: do user's process logical here. */
    }  else if (strstr(property, "RGBColor") != 0) {
        int red, green, blue;

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Red");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &red, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Green");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &green, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Blue");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &blue, &value_str);

        LINKKIT_PRINTF("property(%s), Red:%d, Green:%d, Blue:%d\n", property, red, green, blue);
        /* XXX: do user's process logical here. */
    } else {
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property, NULL, &value_str);

        LINKKIT_PRINTF("property(%s) new value set: %s\n", property, value_str);
    }

    /* do user's process logical here. */
    linkkit_post_property(thing_id, property, post_property_cb);
    return 0;
}

static int linkit_data_arrived(const void* thing_id, const void* params, int len, void* ctx)
{
    LINKKIT_PRINTF("thing@%p: masterdev_linkkit_data(%d byte): %s\n", thing_id, len, (const char*)params);
    return 0;
}

static linkkit_ops_t alink_ops = {
    .on_connect           = on_connect,
    .on_disconnect        = on_disconnect,
    .raw_data_arrived     = raw_data_arrived,
    .thing_create         = thing_create,
    .thing_enable         = thing_enable,
    .thing_disable        = thing_disable,
    .thing_call_service   = thing_call_service,
    .thing_prop_changed   = thing_prop_changed,
    .linkit_data_arrived  = linkit_data_arrived,
};

static unsigned long long uptime_sec(void)
{
    static unsigned long long start_time = 0;

    if (start_time == 0) {
        start_time = HAL_UptimeMs();
    }

    return (HAL_UptimeMs() - start_time) / 1000;
}


static int post_all_prop(sample_context_t* sample)
{
    return linkkit_post_property(sample->thing, NULL, post_property_cb);
}

static int is_active(sample_context_t* sample_ctx)
{
#ifdef LOCAL_CONN_ENABLE
    return (sample_ctx->cloud_connected && sample_ctx->thing_enabled) || (sample_ctx->local_connected && sample_ctx->thing_enabled);
#else
    return sample_ctx->cloud_connected && sample_ctx->thing_enabled;
#endif
}

#ifdef POST_WIFI_STATUS
static int post_property_wifi_status_once(sample_context_t* sample_ctx)
{
    int ret = -1;
    int i = 0;
    static int is_post = 0;
    char val_buf[32];
    char ssid[HAL_MAX_SSID_LEN];
    char passwd[HAL_MAX_PASSWD_LEN];
    uint8_t bssid[ETH_ALEN];
    hal_wireless_info_t wireless_info;

    char* band = NULL;
    int channel = 0;
    int rssi = 0;
    int snr = 0;
    int tx_rate = 0;
    int rx_rate = 0;

    if(is_active(sample_ctx) && 0 == is_post) {
        HAL_GetWirelessInfo(&wireless_info);
        HAL_Wifi_Get_Ap_Info(ssid, passwd, bssid);

        band = wireless_info.band == 0 ? "2.4G" : "5G";
        channel = wireless_info.channel;
        rssi = wireless_info.rssi;
        snr = wireless_info.snr;
        tx_rate = wireless_info.tx_rate;
        rx_rate = wireless_info.rx_rate;

        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Band", band, NULL);
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Channel", &channel, NULL);
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WiFI_RSSI", &rssi, NULL);
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WiFI_SNR", &snr, NULL);

        memset(val_buf, 0, sizeof(val_buf));
        for(i = 0; i < ETH_ALEN; i++) {
            snprintf(val_buf + strlen(val_buf), sizeof(val_buf) - strlen(val_buf), "%c:", bssid[i]);
        }
        if(strlen(val_buf) > 0 && val_buf[strlen(val_buf) - 1] == ':') val_buf[strlen(val_buf) - 1] = '\0';
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_AP_BSSID", val_buf, NULL);

        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Tx_Rate", &tx_rate, NULL);
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Rx_Rate", &rx_rate, NULL);

        is_post = 1;
        ret = 0;
    }
    return ret;
}
#endif

extern void awss_report_reset(void);

void _awss_reset(int sig)
{
    static int cnt = 0;
    cnt++;
    printf("%s (the %dth)\n", __func__, cnt);
    awss_report_reset();
    usleep(1 * 1000 * 1000);
    if (connect_type == CONNECT_TYPE_WIFI || connect_type == CONNECT_TYPE_COMBO) {
        netmgr_clear_ap_config();
        system("ifconfig wlan0 down");
    }
    exit(1);
}

static int post_event_error(sample_context_t *sample)
{
    int errorCode = 0;
    linkkit_set_value(linkkit_method_set_event_output_value,
                      sample->thing,
                      "Error.ErrorCode",
                      &errorCode, NULL);
    linkkit_trigger_event(sample->thing, "Error", post_property_cb);

    linkkit_set_value(linkkit_method_set_event_output_value,
                  sample->thing,
                  "TamperAlarm",
                  &errorCode, NULL);
    linkkit_trigger_event(sample->thing, "TamperAlarm", post_property_cb);
}

static void* linkkit_helper(void *arg)
{
    signal(SIGUSR1, _awss_reset);

    sample_context_t* sample_ctx = &g_sample_context;
    int execution_time = 0;
    int get_tsl_from_cloud = 0;
    int exit = 0;
    unsigned long long now = 0;
    unsigned long long prev_sec = 0;

    execution_time = execution_time < 1 ? 1 : execution_time;
    LINKKIT_PRINTF("sample execution time: %d minutes\n", execution_time);
    LINKKIT_PRINTF("%s tsl from cloud\n", get_tsl_from_cloud == 0 ? "Not get" : "get");

    memset(sample_ctx, 0, sizeof(sample_context_t));
    sample_ctx->thing_enabled = 1;

    linkkit_start(8, get_tsl_from_cloud, linkkit_loglevel_info, &alink_ops, linkkit_cloud_domain_shanghai, sample_ctx);
    if (!get_tsl_from_cloud) {
        linkkit_set_tsl(TSL_STRING, strlen(TSL_STRING));
    }

    while (1) {
#ifndef CM_SUPPORT_MULTI_THREAD
        linkkit_dispatch();
#endif
        now = uptime_sec();
        if (prev_sec == now) {
#ifdef CM_SUPPORT_MULTI_THREAD
            HAL_SleepMs(100);
#else
            linkkit_yield(100);
#endif /* CM_SUPPORT_MULTI_THREAD */
            continue;
        }

        /* about 30 seconds, assume trigger post property event about every 30s. */

        //static int channel = 50.0;
        if (now % 60 == 0 && is_active(sample_ctx)) {
        	
        	//post_event_error(sample_ctx);
        	//linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Channel", &channel, NULL);
        }

        static double percentage = 50.0;
        if (now % 30 == 0 && is_active(sample_ctx)) {
        	percentage = percentage + 1.0;
        	if(percentage > 99.0)
        		percentage = 1.0;
        	int BatteryPercentage = 
        	linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "BatteryPercentage", &percentage, NULL);
        	//post_all_prop(sample_ctx);
        }

        if (exit) break;

        /* after all, this is an sample, give a chance to return... */
        /* modify this value for this sample executaion time period */
        //if (now > 60 * execution_time) exit = 1;

        prev_sec = now;
    }

    linkkit_end();
    LINKKIT_PRINTF("out of sample!\n");
}

static void* awss_notify_work(void *arg)
{
    (void)arg;
    awss_success_notify();
    awss_success = true;
}

static void reboot_system(void *parms)
{
    printf("Rebooting system ...\r\n");
    system("reboot");
    while (1);
}

// ---------

static void apinfo_ready_handler(breeze_apinfo_t *ap)
{
    if (!ap)
        return;

    memcpy(&apinfo, ap, sizeof(apinfo));
    combo_apinfo_ready_handler(&apinfo);
}

static void notify_wifi_status(void *arg)
{
    /* tlv response */
    uint8_t rsp[] = { 0x01, 0x01, 0x01 };

    /* tx_cmd is defaulted to ALI_CMD_STATUS so we don't worry here. */
    breeze_post(rsp, sizeof(rsp));
}

void got_ip_work(void)
{
    int ret;
    pthread_t id1, id2;

    iotx_event_regist_cb(linkkit_event_monitor);

    if (connect_type != CONNECT_TYPE_ETH && is_ble_connected) {
        notify_wifi_status(NULL);
    }

    if (/*awss_running &&*/ !awss_success) {
        ret = pthread_create(&id1, NULL, awss_notify_work, NULL);
        if (ret != 0) {
            printf("Failed to crreate awss notify process.\r\n");
        } else {
            awss_success = true;
        }
    }

    if (!linkkit_started) {
        ret = pthread_create(&id2, NULL, linkkit_helper, NULL);
        if (ret != 0) {
            printf("Failed to create linkkit process.\r\n");
        } else {
            linkkit_started = 1;
        }
    }

    if (connect_type != CONNECT_TYPE_ETH)
        breeze_awss_stop();
}

static void combo_apinfo_ready_handler(breeze_apinfo_t *info)
{
        int ret;
        pthread_t tid;

        awss_running = 1;

        ret = pthread_create(&tid, NULL, combo_work, (void *)info);
        if (ret != 0) {
            printf("Failed to crreate combo thread.\r\n");
        }
}

/*
 * Note:
 * the linkkit_event_monitor must not block and should run to complete fast
 * if user wants to do complex operation with much time,
 * user should post one task to do this, not implement complex operation in
 * linkkit_event_monitor
 */

static void linkkit_event_monitor(int event)
{
    switch (event) {
        case IOTX_AWSS_START: // AWSS start without enbale, just supports device
                              // discover
            // operate led to indicate user
            printf("IOTX_AWSS_START");
            break;
        case IOTX_AWSS_ENABLE: // AWSS enable
            printf("IOTX_AWSS_ENABLE");
            // operate led to indicate user
            break;
        case IOTX_AWSS_LOCK_CHAN: // AWSS lock channel(Got AWSS sync packet)
            printf("IOTX_AWSS_LOCK_CHAN");
            // operate led to indicate user
            break;
        case IOTX_AWSS_PASSWD_ERR: // AWSS decrypt passwd error
            printf("IOTX_AWSS_PASSWD_ERR");
            // operate led to indicate user
            break;
        case IOTX_AWSS_GOT_SSID_PASSWD:
            printf("IOTX_AWSS_GOT_SSID_PASSWD");
            // operate led to indicate user
            break;
        case IOTX_AWSS_CONNECT_ADHA: // AWSS try to connnect adha (device
                                     // discover, router solution)
            printf("IOTX_AWSS_CONNECT_ADHA");
            // operate led to indicate user
            break;
        case IOTX_AWSS_CONNECT_ADHA_FAIL: // AWSS fails to connect adha
            printf("IOTX_AWSS_CONNECT_ADHA_FAIL");
            // operate led to indicate user
            break;
        case IOTX_AWSS_CONNECT_AHA: // AWSS try to connect aha (AP solution)
            printf("IOTX_AWSS_CONNECT_AHA");
            // operate led to indicate user
            break;
        case IOTX_AWSS_CONNECT_AHA_FAIL: // AWSS fails to connect aha
            printf("IOTX_AWSS_CONNECT_AHA_FAIL");
            // operate led to indicate user
            break;
        case IOTX_AWSS_SETUP_NOTIFY: // AWSS sends out device setup information
                                     // (AP and router solution)
            printf("IOTX_AWSS_SETUP_NOTIFY");
            // operate led to indicate user
            break;
        case IOTX_AWSS_CONNECT_ROUTER: // AWSS try to connect destination router
            printf("IOTX_AWSS_CONNECT_ROUTER");
            // operate led to indicate user
            break;
        case IOTX_AWSS_CONNECT_ROUTER_FAIL: // AWSS fails to connect destination
                                            // router.
            printf("IOTX_AWSS_CONNECT_ROUTER_FAIL");
            // operate led to indicate user
            break;
        case IOTX_AWSS_GOT_IP: // AWSS connects destination successfully and got
                               // ip address
            printf("IOTX_AWSS_GOT_IP");
            // operate led to indicate user
            break;
        case IOTX_AWSS_SUC_NOTIFY: // AWSS sends out success notify (AWSS
                                   // sucess)
            printf("IOTX_AWSS_SUC_NOTIFY");
            // operate led to indicate user
            break;
        case IOTX_AWSS_BIND_NOTIFY: // AWSS sends out bind notify information to
                                    // support bind between user and device
            printf("IOTX_AWSS_BIND_NOTIFY");
            // operate led to indicate user
            break;
        case IOTX_CONN_CLOUD: // Device try to connect cloud
            printf("IOTX_CONN_CLOUD");
            // operate led to indicate user
            break;
        case IOTX_CONN_CLOUD_FAIL: // Device fails to connect cloud, refer to
                                   // net_sockets.h for error code
            printf("IOTX_CONN_CLOUD_FAIL");
            // operate led to indicate user
            break;
        case IOTX_CONN_CLOUD_SUC: // Device connects cloud successfully
            printf("IOTX_CONN_CLOUD_SUC");
            //do_report();
            // operate led to indicate user
            break;
        case IOTX_RESET: // Linkkit reset success (just got reset response from
                         // cloud without any other operation)
            printf("IOTX_RESET");
            // operate led to indicate user
            break;
        default:
            break;
    }
}

static void linkkit_reset(void *p)
{
    netmgr_clear_ap_config();
    HAL_Sys_reboot();
}

#if 0
extern int  awss_report_reset();
static void do_awss_reset()
{
    aos_task_new("reset", (void (*)(void *))awss_report_reset, NULL, 2560);
    aos_post_delayed_action(2000, linkkit_reset, NULL);
}

void linkkit_key_process(input_event_t *eventinfo, void *priv_data)
{
    if (eventinfo->type != EV_KEY) {
        return;
    }
    printf("awss config press %d\n", eventinfo->value);

    if (eventinfo->code == CODE_BOOT) {
        if (eventinfo->value == VALUE_KEY_CLICK) {
            //Do something here.
        } else if (eventinfo->value == VALUE_KEY_LTCLICK) {
            do_awss_reset();
        }
    }
}
#endif

static void* combo_work(void *arg)
{
    netmgr_ap_config_t config;
    breeze_apinfo_t *info = arg;

    if (!info)
        return NULL;

#if 0
    printf("%s %d, ssid: %s, pw: %s\r\n", __func__, __LINE__, info->ssid,
           info->pw);
#endif

    strncpy(config.ssid, info->ssid, sizeof(config.ssid) - 1);
    strncpy(config.pwd, info->pw, sizeof(config.pwd) - 1);
    memcpy(config.bssid, info->bssid, ETH_ALEN);
    netmgr_set_ap_config(&config);
    hal_wifi_suspend_station(NULL);
    printf("Will reconnect wifi: %s\r\n", config.ssid);
    netmgr_reconnect_wifi();
}

static int combo_init(uint8_t use_static, netmgr_ap_config_t *ap)
{
    netmgr_register_got_ip_handler(got_ip_work);
    netmgr_init();

    if (use_static) {
        netmgr_set_ap_config(ap);
    }

    /* Do not start BLE if wifi AP available */
    if (netmgr_start(false) == 1) {
        return 1;
    }

    return 0;
}

static void set_lk_dev_info(breeze_dev_info_t *info)
{
    HAL_SetProductKey(info->product_key);
    HAL_SetProductSecret(info->product_secret);
    HAL_SetDeviceName(info->device_name);
    HAL_SetDeviceSecret(info->device_secret);
}

#if 0
static void dump_dev_info(breeze_dev_info_t *info)
{
    printf("Device info:\r\n");
    printf("  pi: %d\r\n", info->product_id);
    printf("  pk: %s\r\n", info->product_key);
    printf("  ps: %s\r\n", info->product_secret);
    printf("  dn: %s\r\n", info->device_name);
    printf("  ds: %s\r\n", info->device_secret);
}
#endif

static int check_combo_enable(char *file_str)
{
    FILE *file = NULL;

    if (!file_str) return 0;

    if ((file = fopen(file_str, "r")) != NULL) {
        if (fgetc(file) == '1') {
            return 1;
        }

        fclose(file);
    }

    return 0;
}

#ifndef DEV_INFO_ENC
#define DEV_INFO_ENC
#endif

#ifdef DEV_INFO_ENC
#include <triple.h>
static void fetch_enc_dev_info(breeze_dev_info_t *dinfo)
{
    char pi_str[PRODUCT_ID_MAXLEN] = {0};

    get_product_key(dinfo->product_key);
    get_product_secret(dinfo->product_secret);
    get_device_name(dinfo->device_name);
    get_device_secret(dinfo->device_secret);
    get_product_id(pi_str);
    dinfo->product_id = (uint32_t)atoi(pi_str);
}
#endif

#define AWSS_TYPE_BLE "ble"
#define AWSS_TYPE_ETH "eth"

#define NETWORK_CHECKOUT_TIMEOUT_SEC 60
#define NETWORK_TEST_URL "iot-as-mqtt.cn-shanghai.aliyuncs.com"
static int check_network_timeout(unsigned int timeuout_s)
{
    int ret;
    unsigned int t = 0, step = 5;

    ret = system("ping -c 3 "NETWORK_TEST_URL);
    if (ret == 0) {
        return 0;
    }

    while (t < timeuout_s) {
        sleep(step);
        ret = system("ping -c 3 "NETWORK_TEST_URL);
        if (ret == 0) return 0;
        printf("Waiting for network to be ready ...\r\n");
        t += step;
    }

    return -1;
}

static void ethernet_work()
{
    if (check_network_timeout(NETWORK_CHECKOUT_TIMEOUT_SEC) != 0) {
        printf("Bad!!! Network is not ready, please check the network and try again.\r\n");
        exit(1);
    }

    got_ip_work();

#if 0
   int ret;
    pthread_t id;

    iotx_event_regist_cb(linkkit_event_monitor);

    if (!linkkit_started) {
        ret = pthread_create(&id, NULL, linkkit_helper, NULL);
        if (ret != 0) {
            printf("Failed to create linkkit process.\r\n");
        } else {
            linkkit_started = 1;
            printf("Linkkit started.\r\n");
        }
    }
#endif 
}

int main(int argc, char* argv[])
{
    char pk[20+1] = {0}, ps[64+1] = {0}, dn[32+1] = {0}, ds[64+1] = {0};
    breeze_dev_info_t dinfo = {
        .product_key = pk,
        .product_secret = ps,
        .device_name = dn,
        .device_secret = ds
    };
    netmgr_ap_config_t config;
    uint8_t use_static_ap = 0;

#ifdef DEV_INFO_ENC
    fetch_enc_dev_info(&dinfo);
#else
    if (get_devinfo_all5((devinfo_set5_t *)&dinfo) != 0) {
        printf("Error: failed to fetch device information, "
               "please make sure the device information is set.\r\n");
        return -1;
    }
#endif

    //dump_dev_info(&dinfo);
    set_lk_dev_info(&dinfo);

    if (argc == 3) {
        printf("You have specified the AP information (ssid: %s, pw: %s), let's use it.\n", argv[1], argv[2]);
        strncpy(config.ssid, argv[1], sizeof(config.ssid) - 1);
        strncpy(config.pwd, argv[2], sizeof(config.pwd) - 1);
        memset(config.bssid, 0, ETH_ALEN);
        use_static_ap = 1;
    } else if (argc == 2) {
        if (strcmp(argv[1], "ota=0") == 0) {
            printf("OTA is enabled\n");
            ota_enabled = false;
        } else if (strcmp(argv[1], AWSS_TYPE_ETH) == 0) {
            printf("Ethernet network specified.\r\n");
            connect_type = CONNECT_TYPE_ETH;
            ethernet_work();
            goto end;
        }
    }

    /* Default connect type is wifi/ble combo */
    connect_type = CONNECT_TYPE_COMBO;
    if (combo_init(use_static_ap, &config) == 0) {
        while (check_combo_enable(AWSS_COMFIRM_FILE) == 0) usleep(200 * 1000);
        breeze_awss_start(apinfo_ready_handler, &dinfo);
        breeze_event_dispatcher();
    }

end:
    while (1) sleep(1);

    return 0;
}
