/** USER NOTIFICATION
 *  this sample code is only used for evaluation or test of the iLop project.
 *  Users should modify this sample code freely according to the product/device TSL, like
 *  property/event/service identifiers, and the item value type(type, length, etc...).
 *  Create user's own execution logic for specific products.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>
#include <signal.h>
#include <stdbool.h>
#if !defined(_WIN32)
#include <unistd.h>
#endif

#include <netmgr.h>
#include <pthread.h>

#include "linkkit_export.h"

#include "iot_import.h"
#include "tls_str.h"

#include <ali_common.h>
#include <api_export.h>
#include <ali_ext.h>
#include <wifi.h>

#define SOFTWARE_VERSION                                                     \
    "0.2.0" /* Version number defined by user. Must be in format "%d.%d.%d". \
             */
#define SOFTWARE_VERSION_LEN 5

#define BLE_PRODUCT_ID    213226
#define BLE_DEVICE_SECRET "IwO2GVQhG2jyMDe4ryIr3qvaeCG7wV7B"
#define BLE_DEVICE_NAME   "2EuSBrhJHWVb8MIDFpkz"
#define BLE_PRODUCT_KEY   "b1XVhqfan1X"

#include "../../framework/protocol/linkkit/iotkit/base/event/iot_export_event.h"

#define LINKKIT_PRINTF(...)  \
    do {                                                     \
        printf("\e[0;32m%s@line%d:\t", __FUNCTION__, __LINE__);  \
        printf(__VA_ARGS__);                                 \
        printf("\e[0m");                                   \
    } while (0)

/* identifier of property/service/event, users should modify this macros according to your own product TSL. */
#define EVENT_ERROR_IDENTIFIER                 "Error"
#define EVENT_ERROR_OUTPUT_INFO_IDENTIFIER     "ErrorCode"
#define EVENT_CUSTOM_IDENTIFIER                "Custom"

/* specify ota buffer size for ota service, ota service will use this buffer for bin download. */
#define OTA_BUFFER_SIZE                  (512+1)
/* PLEASE set RIGHT tsl string according to your product. */

int awss_config_press();
int awss_success_notify();
int awss_report_cloud();
static void notify_wifi_status(void *arg);

static int            linkkit_started = 0;
static int            awss_running    = 0;
static alink_apinfo_t apinfo;
static bool           is_ble_connected = false;

/* user sample context struct. */
typedef struct _sample_context {
    const void*   thing;
    int           cloud_connected;
#ifdef LOCAL_CONN_ENABLE
    int           local_connected;
#endif
    int           thing_enabled;

    int           service_custom_input_transparency;
    int           service_custom_output_contrastratio;
#ifdef SERVICE_OTA_ENABLED
    char          ota_buffer[OTA_BUFFER_SIZE];
#endif /* SERVICE_OTA_ENABLED */
} sample_context_t;

sample_context_t g_sample_context;

#define EVENT_CUSTOM_INFO		"test_info"
#define EVENT_CUSTOM_WARN		"test_warnning"
#define EVENT_CUSTOM_ERROR		"test_error"

void post_property_cb(const void* thing_id, int respons_id, int code, const char* response_message, void* ctx)
{
    LINKKIT_PRINTF("thing@%p: response arrived:\nid:%d\tcode:%d\tmessage:%s\n", thing_id, respons_id, code, response_message == NULL ? "NULL" : response_message);
}

#ifdef SERVICE_OTA_ENABLED
/* callback function for fota service. */
static void fota_callback(service_fota_callback_type_t callback_type, const char* version)
{
    sample_context_t* sample_ctx;

    assert(callback_type < service_fota_callback_type_number);

    sample_ctx = &g_sample_context;

    /* temporarily disable thing when ota service invoked */
    sample_ctx->thing_enabled = 0;

    linkkit_invoke_ota_service(sample_ctx->ota_buffer, OTA_BUFFER_SIZE);

    sample_ctx->thing_enabled = 1;

    /* reboot the device... */
}
#endif /* SERVICE_OTA_ENABLED */
#ifdef LOCAL_CONN_ENABLE
static int on_connect(void* ctx, int cloud)
#else
static int on_connect(void* ctx)
#endif
{
    sample_context_t* sample_ctx = ctx;

#ifdef LOCAL_CONN_ENABLE
    if (cloud) {
        sample_ctx->cloud_connected = 1;
    } else {
        sample_ctx->local_connected = 1;
    }
    LINKKIT_PRINTF("%s is connected\n", cloud ? "cloud" : "local");
#else
    sample_ctx->cloud_connected = 1;
    LINKKIT_PRINTF("%s is connected\n", "cloud");
#endif

    return 0;
}

#ifdef LOCAL_CONN_ENABLE
static int on_disconnect(void* ctx, int cloud)
#else
static int on_disconnect(void* ctx)
#endif
{
    sample_context_t* sample_ctx = ctx;

#ifdef LOCAL_CONN_ENABLE
    if (cloud) {
        sample_ctx->cloud_connected = 0;
    } else {
        sample_ctx->local_connected = 0;
    }
    LINKKIT_PRINTF("%s is disconnect\n", cloud ? "cloud" : "local");
#else
    sample_ctx->cloud_connected = 0;
    LINKKIT_PRINTF("%s is disconnect\n", "cloud");
#endif
    return 0;
}

static int raw_data_arrived(const void* thing_id, const void* data, int len, void* ctx)
{
    char raw_data[128] = {0};

    LINKKIT_PRINTF("raw data arrived,len:%d\n", len);

    /* do user's raw data process logical here. */

    /* ............................... */

    /* user's raw data process logical complete */

    snprintf(raw_data, sizeof(raw_data), "test down raw reply data %lld", (long long)HAL_UptimeMs());

    linkkit_invoke_raw_service(thing_id, 0, raw_data, strlen(raw_data));

    return 0;
}

static int thing_create(const void* thing_id, void* ctx)
{
    sample_context_t* sample_ctx = ctx;

    LINKKIT_PRINTF("new thing@%p created.\n", thing_id);
    sample_ctx->thing = thing_id;

    return 0;
}

static int thing_enable(const void* thing_id, void* ctx)
{
    sample_context_t* sample_ctx = ctx;

    sample_ctx->thing_enabled = 1;

    return 0;
}

static int thing_disable(const void* thing_id, void* ctx)
{
    sample_context_t* sample_ctx = ctx;

    sample_ctx->thing_enabled = 0;

    return 0;
}
#ifdef RRPC_ENABLED
static int handle_service_custom(sample_context_t* _sample_ctx, const void* thing, const char* service_identifier, int request_id, int rrpc)
#else
static int handle_service_custom(sample_context_t* _sample_ctx, const void* thing, const char* service_identifier, int request_id)
#endif /* RRPC_ENABLED */
{
    char identifier[128] = {0};
    sample_context_t* sample_ctx = _sample_ctx;

    /*
     * get iutput value.
     */
    snprintf(identifier, sizeof(identifier), "%s.%s", service_identifier, "transparency");
    linkkit_get_value(linkkit_method_get_service_input_value, thing, identifier, &sample_ctx->service_custom_input_transparency, NULL);

    /*
     * set output value according to user's process result.
     */

    snprintf(identifier, sizeof(identifier), "%s.%s", service_identifier, "Contrastratio");

    sample_ctx->service_custom_output_contrastratio = sample_ctx->service_custom_input_transparency >= 0 ? sample_ctx->service_custom_input_transparency : sample_ctx->service_custom_input_transparency * -1;

    linkkit_set_value(linkkit_method_set_service_output_value, thing, identifier, &sample_ctx->service_custom_output_contrastratio, NULL);
#ifdef RRPC_ENABLED
    linkkit_answer_service(thing, service_identifier, request_id, 200, rrpc);
#else
    linkkit_answer_service(thing, service_identifier, request_id, 200);
#endif /* RRPC_ENABLED */

    return 0;
}
#ifdef RRPC_ENABLED
static int thing_call_service(const void* thing_id, const char* service, int request_id, int rrpc, void* ctx)
#else
static int thing_call_service(const void* thing_id, const char* service, int request_id, void* ctx)
#endif /* RRPC_ENABLED */
{
    sample_context_t* sample_ctx = ctx;

    LINKKIT_PRINTF("service(%s) requested, id: thing@%p, request id:%d\n",
                   service, thing_id, request_id);

    if (strcmp(service, "Custom") == 0) {
#ifdef RRPC_ENABLED
        handle_service_custom(sample_ctx, thing_id, service, request_id, rrpc);
#else
        handle_service_custom(sample_ctx, thing_id, service, request_id);
#endif /* RRPC_ENABLED */
    }

    return 0;
}

static int thing_prop_changed(const void* thing_id, const char* property, void* ctx)
{
    char* value_str = NULL;
    char property_buf[64] = {0};

    /* get new property value */
    if (strstr(property, "HSVColor") != 0) {
        int hue, saturation, value;

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Hue");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &hue, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Saturation");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &saturation, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Value");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &value, &value_str);

        LINKKIT_PRINTF("property(%s), Hue:%d, Saturation:%d, Value:%d\n", property, hue, saturation, value);

        /* XXX: do user's process logical here. */
    } else if (strstr(property, "HSLColor") != 0) {
        int hue, saturation, lightness;

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Hue");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &hue, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Saturation");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &saturation, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Lightness");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &lightness, &value_str);

        LINKKIT_PRINTF("property(%s), Hue:%d, Saturation:%d, Lightness:%d\n", property, hue, saturation, lightness);
        /* XXX: do user's process logical here. */
    }  else if (strstr(property, "RGBColor") != 0) {
        int red, green, blue;

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Red");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &red, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Green");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &green, &value_str);

        snprintf(property_buf, sizeof(property_buf), "%s.%s", property, "Blue");
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property_buf, &blue, &value_str);

        LINKKIT_PRINTF("property(%s), Red:%d, Green:%d, Blue:%d\n", property, red, green, blue);
        /* XXX: do user's process logical here. */
    } else {
        linkkit_get_value(linkkit_method_get_property_value, thing_id, property, NULL, &value_str);

        LINKKIT_PRINTF("property(%s) new value set: %s\n", property, value_str);
    }

    /* do user's process logical here. */
    linkkit_post_property(thing_id, property, post_property_cb);
    return 0;
}

static int linkit_data_arrived(const void* thing_id, const void* params, int len, void* ctx)
{
    LINKKIT_PRINTF("thing@%p: masterdev_linkkit_data(%d byte): %s\n", thing_id, len, (const char*)params);
    return 0;
}

static linkkit_ops_t alink_ops = {
    .on_connect           = on_connect,
    .on_disconnect        = on_disconnect,
    .raw_data_arrived     = raw_data_arrived,
    .thing_create         = thing_create,
    .thing_enable         = thing_enable,
    .thing_disable        = thing_disable,
    .thing_call_service   = thing_call_service,
    .thing_prop_changed   = thing_prop_changed,
    .linkit_data_arrived  = linkit_data_arrived,
};

static unsigned long long uptime_sec(void)
{
    static unsigned long long start_time = 0;

    if (start_time == 0) {
        start_time = HAL_UptimeMs();
    }

    return (HAL_UptimeMs() - start_time) / 1000;
}


static int post_all_prop(sample_context_t* sample)
{
    return linkkit_post_property(sample->thing, NULL, post_property_cb);
}

static int is_active(sample_context_t* sample_ctx)
{
#ifdef LOCAL_CONN_ENABLE
    return (sample_ctx->cloud_connected && sample_ctx->thing_enabled) || (sample_ctx->local_connected && sample_ctx->thing_enabled);
#else
    return sample_ctx->cloud_connected && sample_ctx->thing_enabled;
#endif
}

#ifdef POST_WIFI_STATUS
static int post_property_wifi_status_once(sample_context_t* sample_ctx)
{
    int ret = -1;
    int i = 0;
    static int is_post = 0;
    char val_buf[32];
    char ssid[HAL_MAX_SSID_LEN];
    char passwd[HAL_MAX_PASSWD_LEN];
    uint8_t bssid[ETH_ALEN];
    hal_wireless_info_t wireless_info;

    char* band = NULL;
    int channel = 0;
    int rssi = 0;
    int snr = 0;
    int tx_rate = 0;
    int rx_rate = 0;

    if(is_active(sample_ctx) && 0 == is_post) {
        HAL_GetWirelessInfo(&wireless_info);
        HAL_Wifi_Get_Ap_Info(ssid, passwd, bssid);

        band = wireless_info.band == 0 ? "2.4G" : "5G";
        channel = wireless_info.channel;
        rssi = wireless_info.rssi;
        snr = wireless_info.snr;
        tx_rate = wireless_info.tx_rate;
        rx_rate = wireless_info.rx_rate;

        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Band", band, NULL);
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Channel", &channel, NULL);
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WiFI_RSSI", &rssi, NULL);
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WiFI_SNR", &snr, NULL);

        memset(val_buf, 0, sizeof(val_buf));
        for(i = 0; i < ETH_ALEN; i++) {
            snprintf(val_buf + strlen(val_buf), sizeof(val_buf) - strlen(val_buf), "%c:", bssid[i]);
        }
        if(strlen(val_buf) > 0 && val_buf[strlen(val_buf) - 1] == ':') val_buf[strlen(val_buf) - 1] = '\0';
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_AP_BSSID", val_buf, NULL);

        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Tx_Rate", &tx_rate, NULL);
        linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Rx_Rate", &rx_rate, NULL);

        is_post = 1;
        ret = 0;
    }
    return ret;
}
#endif

extern void awss_report_reset(void);

void _awss_reset(int sig){
    LINKKIT_PRINTF("_awss_reset\n");
    awss_report_reset();
}

static int post_event_error(sample_context_t *sample)
{
    int errorCode = 0;
    linkkit_set_value(linkkit_method_set_event_output_value,
                      sample->thing,
                      "Error.ErrorCode",
                      &errorCode, NULL);
    linkkit_trigger_event(sample->thing, "Error", post_property_cb);

    linkkit_set_value(linkkit_method_set_event_output_value,
                  sample->thing,
                  "TamperAlarm",
                  &errorCode, NULL);
    linkkit_trigger_event(sample->thing, "TamperAlarm", post_property_cb);
}

static void* linkkit_work(void *arg)
{
    //signal(SIGUSR1,_awss_reset);

    sample_context_t* sample_ctx = &g_sample_context;
    int execution_time = 0;
    int get_tsl_from_cloud = 0;
    int exit = 0;
    unsigned long long now = 0;
    unsigned long long prev_sec = 0;

    execution_time = execution_time < 1 ? 1 : execution_time;
    LINKKIT_PRINTF("sample execution time: %d minutes\n", execution_time);
    LINKKIT_PRINTF("%s tsl from cloud\n", get_tsl_from_cloud == 0 ? "Not get" : "get");

    memset(sample_ctx, 0, sizeof(sample_context_t));
    sample_ctx->thing_enabled = 1;

    linkkit_start(8, get_tsl_from_cloud, linkkit_loglevel_debug, &alink_ops, linkkit_cloud_domain_shanghai, sample_ctx);
    if (!get_tsl_from_cloud) {
        linkkit_set_tsl(TSL_STRING, strlen(TSL_STRING));
    }

    while (1) {
#ifndef CM_SUPPORT_MULTI_THREAD
        linkkit_dispatch();
#endif
        now = uptime_sec();
        if (prev_sec == now) {
#ifdef CM_SUPPORT_MULTI_THREAD
            HAL_SleepMs(100);
#else
            linkkit_yield(100);
#endif /* CM_SUPPORT_MULTI_THREAD */
            continue;
        }

        /* about 30 seconds, assume trigger post property event about every 30s. */

        //static int channel = 50.0;
        if (now % 60 == 0 && is_active(sample_ctx)) {
        	
        	post_event_error(sample_ctx);
        	//linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "WIFI_Channel", &channel, NULL);
        }

        static double percentage = 50.0;
        if (now % 30 == 0 && is_active(sample_ctx)) {
        	percentage = percentage + 1.0;
        	if(percentage > 99.0)
        		percentage = 1.0;
        	//int BatteryPercentage = 
        	linkkit_set_value(linkkit_method_set_property_value, sample_ctx->thing, "BatteryPercentage", &percentage, NULL);
        	post_all_prop(sample_ctx);
        }

        if (exit) break;

        /* after all, this is an sample, give a chance to return... */
        /* modify this value for this sample executaion time period */
        //if (now > 60 * execution_time) exit = 1;

        prev_sec = now;
    }

    linkkit_end();
    LINKKIT_PRINTF("out of sample!\n");
}

static void linkkit_event_monitor(int event)
{
    switch (event) {
    case IOTX_AWSS_START:                // AWSS start without enbale, just supports device discover
        // operate led to indicate user
        printf("IOTX_AWSS_START");
        break;
    case IOTX_AWSS_ENABLE:               // AWSS enable
        printf("IOTX_AWSS_ENABLE");
        // operate led to indicate user
        break;
    case IOTX_AWSS_LOCK_CHAN:            // AWSS lock channel(Got AWSS sync packet)
        printf("IOTX_AWSS_LOCK_CHAN");
        // operate led to indicate user
        break;
    case IOTX_AWSS_PASSWD_ERR:           // AWSS decrypt passwd error
        printf("IOTX_AWSS_PASSWD_ERR");
        // operate led to indicate user
        break;
    case IOTX_AWSS_GOT_SSID_PASSWD:
        printf("IOTX_AWSS_GOT_SSID_PASSWD");
        // operate led to indicate user
        break;
    case IOTX_AWSS_CONNECT_ADHA:         // AWSS try to connnect adha (device discover, router solution)
        printf("IOTX_AWSS_CONNECT_ADHA");
        // operate led to indicate user
        break;
    case IOTX_AWSS_CONNECT_ADHA_FAIL:    // AWSS fails to connect adha
        printf("IOTX_AWSS_CONNECT_ADHA_FAIL");
        // operate led to indicate user
        break;
    case IOTX_AWSS_CONNECT_AHA:          // AWSS try to connect aha (AP solution)
        printf("IOTX_AWSS_CONNECT_AHA");
        // operate led to indicate user
        break;
    case IOTX_AWSS_CONNECT_AHA_FAIL:     // AWSS fails to connect aha
        printf("IOTX_AWSS_CONNECT_AHA_FAIL");
        // operate led to indicate user
        break;
    case IOTX_AWSS_SETUP_NOTIFY:         // AWSS sends out device setup information (AP and router solution)
        printf("IOTX_AWSS_SETUP_NOTIFY");
        // operate led to indicate user
        break;
    case IOTX_AWSS_CONNECT_ROUTER:       // AWSS try to connect destination router
        printf("IOTX_AWSS_CONNECT_ROUTER");
        // operate led to indicate user
        break;
    case IOTX_AWSS_CONNECT_ROUTER_FAIL:  // AWSS fails to connect destination router.
        printf("IOTX_AWSS_CONNECT_ROUTER_FAIL");
        // operate led to indicate user
        break;
    case IOTX_AWSS_GOT_IP:               // AWSS connects destination successfully and got ip address
        printf("IOTX_AWSS_GOT_IP");
        // operate led to indicate user
        break;
    case IOTX_AWSS_SUC_NOTIFY:           // AWSS sends out success notify (AWSS sucess)
        printf("IOTX_AWSS_SUC_NOTIFY");
        // operate led to indicate user
        break;
    case IOTX_AWSS_BIND_NOTIFY:          // AWSS sends out bind notify information to support bind between user and device
        printf("IOTX_AWSS_BIND_NOTIFY");
        // operate led to indicate user
        break;
    case IOTX_CONN_CLOUD:                // Device try to connect cloud
        printf("IOTX_CONN_CLOUD");
        // operate led to indicate user
        break;
    case IOTX_CONN_CLOUD_FAIL:           // Device fails to connect cloud, refer to net_sockets.h for error code
        printf("IOTX_CONN_CLOUD_FAIL");
        // operate led to indicate user
        break;
    case IOTX_CONN_CLOUD_SUC:            // Device connects cloud successfully
        printf("IOTX_CONN_CLOUD_SUC");
        awss_report_cloud();
        // operate led to indicate user
        break;
    case IOTX_RESET:                     // Linkkit reset success (just got reset response from cloud without any other operation)
        printf("IOTX_RESET");
        // operate led to indicate user
        break;
    default:
        break;
    }
}

static void* awss_notify_work(void *arg)
{
    static bool awss_reported = false;

    if (!awss_reported) {
        awss_success_notify();
        awss_reported = true;
    }
}

void got_ip_work(void)
{
    int ret;
    pthread_t id1, id2;

    iotx_event_regist_cb(linkkit_event_monitor);

    if (is_ble_connected) {
        notify_wifi_status(NULL);
    }

    if (!linkkit_started) {
        ret = pthread_create(&id1, NULL, awss_notify_work, NULL);
        if (ret != 0) {
            printf("Failed to crreate awss notify process.\r\n");
        }

        ret = pthread_create(&id2, NULL, linkkit_work, NULL);
        if (ret != 0) {
            printf("Failed to crreate linkkit process.\r\n");
        }
        linkkit_started = 1;
    }
}

static void reboot_system(void *parms)
{
    printf("Rebooting system ...\r\n");
    system("reboot");
    while (1);
}

/* -------------------ble part begin------------------ */

/* @brief Event handler for Ali-SDK. */
static void dev_status_changed_handler(alink_event_t event)
{
    switch (event) {
        case CONNECTED:
            is_ble_connected = true;
            printf("dev_status_changed(): Connected.\n");
            break;

        case DISCONNECTED:
            is_ble_connected = false;
            printf("dev_status_changed(): Disconnected.\n");
            break;

        case AUTHENTICATED:
            printf("dev_status_changed(): Authenticated.\n");
            break;

        case TX_DONE:
            printf("dev_status_changed(): Tx-done.\n");
            break;

        default:
            break;
    }
}

static void* combo_work(void *arg)
{
    netmgr_ap_config_t config;
    alink_apinfo_t *info = arg;

    if (!info)
        return NULL;

    printf("%s %d, ssid: %s, pw: %s\r\n", __func__, __LINE__, info->ssid,
           info->pw);

    strncpy(config.ssid, info->ssid, sizeof(config.ssid) - 1);
    strncpy(config.pwd, info->pw, sizeof(config.pwd) - 1);
    memcpy(config.bssid, info->bssid, ETH_ALEN);
    netmgr_set_ap_config(&config);
    hal_wifi_suspend_station(NULL);
    printf("Will reconnect wifi: %s %s", config.ssid, config.pwd);
    netmgr_reconnect_wifi();
}

static pthread_t id3;
static void combo_apinfo_ready_handler(alink_apinfo_t *info)
{
        int ret;

        ret = pthread_create(&id3, NULL, combo_work, (void *)info);
        if (ret != 0) {
            printf("Failed to crreate combo thread.\r\n");
        }
}

static void combo_event_handler(char *str, uint32_t len)
{
    char    *ssid = apinfo.ssid, *pw = apinfo.pw, *p = str;
    uint8_t *bssid = apinfo.bssid;
    int      i, j;

    i = 0;
    while (*p != '\0' && i < len) {
        if (*p == ',') {
            p++;
            break;
        }
        ssid[i++] = *p++;
    }
    ssid[i] = '\0';

    j = 0;
    while (*p != '\0' && j < (len - i)) {
        pw[j++] = *p++;
    }
    pw[j] = '\0';

    printf("ssid: %s, pw: %s\r\n", ssid, pw);

    //aos_post_event(EV_COMBO, CODE_COMBO_AP_INFO_READY, (unsigned long)&apinfo);
    combo_apinfo_ready_handler(&apinfo);
}

/* @brief Data handler for control command 0x00. */
static void set_dev_status_handler(uint8_t *buffer, uint32_t length)
{
    char *p, *combo_prefix = "+comboevt:";

    printf("%s command (len: %d) received.\r\n", __func__, length);

    p = (char *)buffer;
    if (memcmp(p, combo_prefix, strlen(combo_prefix)) == 0) {
        printf("Combo event found.\r\n");
        p += strlen(combo_prefix);
        length -= strlen(combo_prefix);
        combo_event_handler(p, length);
    }
}

/* @brief Data handler for query command 0x02. */
static void get_dev_status_handler(uint8_t *buffer, uint32_t length)
{
    /* Flip one of the bits and then echo. */
    buffer[length - 1] ^= 2;
    alink_post(buffer, length);
}

static void apinfo_ready_handler(alink_apinfo_t *ap)
{
    if (!ap)
        return;

    memcpy(&apinfo, ap, sizeof(apinfo));
    //aos_post_event(EV_COMBO, CODE_COMBO_AP_INFO_READY, (unsigned long)&apinfo);
    combo_apinfo_ready_handler(&apinfo);
}

static void notify_wifi_status(void *arg)
{
    /* tlv response */
    uint8_t rsp[] = { 0x01, 0x01, 0x01 };

    /* tx_cmd is defaulted to ALI_CMD_STATUS so we don't worry here. */
    alink_post(rsp, sizeof(rsp));
}

static void alink_work(void *arg)
{
    bool                 ret;
    uint32_t             err_code;
    struct device_config init_alink;
    uint8_t              bd_addr[BD_ADDR_LEN] = { 0 };

    (void)arg;

    memset(&init_alink, 0, sizeof(struct device_config));
    init_alink.product_id        = BLE_PRODUCT_ID;
    init_alink.status_changed_cb = dev_status_changed_handler;
    init_alink.set_cb            = set_dev_status_handler;
    init_alink.get_cb            = get_dev_status_handler;
    init_alink.apinfo_cb         = apinfo_ready_handler;

#ifdef CONFIG_AIS_OTA
    init_alink.enable_ota = false;
#endif
    init_alink.enable_auth = true;
    init_alink.auth_type   = ALI_AUTH_BY_PRODUCT_SECRET;

    init_alink.secret_len = strlen(BLE_DEVICE_SECRET);
    memcpy(init_alink.secret, BLE_DEVICE_SECRET, init_alink.secret_len);

    init_alink.product_key_len = strlen(BLE_PRODUCT_KEY);
    memcpy(init_alink.product_key, BLE_PRODUCT_KEY, init_alink.product_key_len);

    init_alink.device_key_len = strlen(BLE_DEVICE_NAME);
    memcpy(init_alink.device_key, BLE_DEVICE_NAME, init_alink.device_key_len);

    memcpy(init_alink.version, SOFTWARE_VERSION, SOFTWARE_VERSION_LEN);

    //linkkit_init();

    /* Do not start BLE if wifi AP available */
    if (netmgr_start(false) == 1) {
        return;
    }

    ret = alink_start(&init_alink);
    if (ret != 0) {
        printf("alink_start failed.\r\n");
    } else {
        printf("alink_start succeed.\r\n");
    }
}

/* -------------------ble part end------------------ */


int main(int argc, char* argv[])
{
    netmgr_register_got_ip_handler(got_ip_work);
    netmgr_init();
    alink_work(NULL);

    /* !!!main process should not exit!!! */
    while (1);

    return 0;
}
