#include <stdio.h>
#include <string.h>
#include "kv.h"

int main(int argc, char** argv)
{
    char *cmd, buf[64];
    int ret, len;

    if (argc < 3) {
        printf("Invalid argument (argc < 3).\r\n");
        return -1;
    }

    if (strcmp(argv[1], "del") == 0) {
        hal_kv_del(argv[2]);
        printf("kv deleted %s\r\n", argv[2]);
    } else if (strcmp(argv[1], "get") == 0) {
        len = sizeof(buf);
        memset(buf, 0, len);
        ret = hal_kv_get(argv[2], buf, &len);
        if (ret == 0) {
            printf("kv got %s, value: %s, len: %d\r\n", argv[2], buf, len);
        } else {
            printf("Failed to get kv %s, ret = %d\r\n", argv[2], ret);
        }
    } else if (strcmp(argv[1], "set") == 0) {
        ret = hal_kv_set(argv[2], (const void *)argv[3], strlen(argv[3]), 1);
        if (ret == 0) {
            printf("kv set %s.\r\n", argv[2]);
        } else {
            printf("Failed to set kv %s, ret = %d\r\n", argv[2], ret);
        }
    } else {
        printf("Invalid argument.\r\n");
        return -1;
    }

    return 0;
}
