/*
 *  BlueZ - Bluetooth protocol stack for Linux
 *
 *  Copyright (C) 2018  Realtek Inc.
 *
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <errno.h>

#include <pthread.h>

#include "lib/bluetooth.h"
#include "lib/hci.h"
#include "lib/hci_lib.h"
#include "lib/l2cap.h"
#include "lib/uuid.h"

#include "src/shared/mainloop.h"
#include "src/shared/util.h"
#include "src/shared/att.h"
#include "src/shared/queue.h"
#include "src/shared/timeout.h"
#include "src/shared/gatt-db.h"
#include "src/shared/gatt-server.h"

#include "breeze_hal_ble.h"

#define ATT_CID 	4
#define NOTIFICATION 	1
#define INDICATION	2

static ais_adv_init_t *adv_copy = NULL;

void rc_read_cb(struct gatt_db_attribute *attrib,
					unsigned int id, uint16_t offset,
					uint8_t opcode, struct bt_att *att,
					void *user_data);

ais_err_t ble_adv_set_advdata(ais_adv_init_t *adv);

void *thread_run(void *arg);

static void hex_dump(char *pref, int width, unsigned char *buf, int len)
{
	register int i,n;

	for (i = 0, n = 1; i < len; i++, n++) {
		if (n == 1)
			printf("%s", pref);
		printf("%2.2X ", buf[i]);
		if (n == width) {
			printf("\n");
			n = 0;
		}
	}
	if (i && n!=1)
		printf("\n");
}

struct data_entry {
	int type;
	uint8_t *data;
	uint16_t length;
};

struct server {
	int fd;
	struct bt_att *att;
	struct gatt_db *db;
	struct bt_gatt_server *gatt;

	pthread_t mainloop_thread;

	struct queue *data_queue;
	pthread_mutex_t data_queue_mutex;
	
	bool ind_enabled;
	bool not_enabled;

	uint16_t not_handle;
	uint16_t ind_handle;

	bdaddr_t client_addr;
	uint16_t conn_handle;
};

struct server *server;
static int fds[2];
ais_bt_init_t * bt_init_info = NULL;


void rc_read_cb(struct gatt_db_attribute *attrib,
					unsigned int id, uint16_t offset,
					uint8_t opcode, struct bt_att *att,
					void *user_data)
{
	uint8_t error = 0;
	size_t len = 0;
	const uint8_t *value = NULL;

	printf("Char Read called\n");

	len = 5;

	if (offset > len) {
		error = BT_ATT_ERROR_INVALID_OFFSET;
		goto done;
	}

	len -= offset;
	value = "12345";

done:
	gatt_db_attribute_read_result(attrib, id, error, value, len);
}

static void wc_write_cb(struct gatt_db_attribute *attrib,
					unsigned int id, uint16_t offset,
					const uint8_t *value, size_t len,
					uint8_t opcode, struct bt_att *att,
					void *user_data)
{
	uint8_t error = 0;

	printf("Char Write called\n");

	
	if (value) {
		printf("value: ");
		hex_dump("  ", 8, (unsigned char *)value, len); fflush(stdout);
	}
	
	// calling on_write.
	
    	if (bt_init_info && bt_init_info->wc.on_write) {
    	    bt_init_info->wc.on_write((void *)value, len);
    	}

//done:
	gatt_db_attribute_write_result(attrib, id, error);
}

static void ic_write_cb(struct gatt_db_attribute *attrib,
                                       unsigned int id, uint16_t offset,
                                       const uint8_t *value, size_t len,
                                       uint8_t opcode, struct bt_att *att,
                                       void *user_data)
{
}

static void nc_write_cb(struct gatt_db_attribute *attrib,
                                       unsigned int id, uint16_t offset,
                                       const uint8_t *value, size_t len,
                                       uint8_t opcode, struct bt_att *att,
                                       void *user_data)
{
}


static void wwnc_write_cb(struct gatt_db_attribute *attrib,
					unsigned int id, uint16_t offset,
					const uint8_t *value, size_t len,
					uint8_t opcode, struct bt_att *att,
					void *user_data)
{
	uint8_t error = 0;

	printf("Char Write called\n");

	
	if (value) {
		printf("value: ");
		hex_dump("  ", 8, (unsigned char *)value, len); fflush(stdout);
	}
	
	// calling on_write.
    	if (bt_init_info && bt_init_info->wwnrc.on_write) {
    	    bt_init_info->wwnrc.on_write((void *)value, len);
    	}

//done:
	gatt_db_attribute_write_result(attrib, id, error);
}

static void bt_uuid_create(bt_uuid_t *uuid, ais_uuid_t *uuid_char)
{
	ais_uuid_16_t *uuid16;
	uint128_t uuid128_val;
	ais_uuid_32_t *uuid32;
	ais_uuid_128_t *uuid128;
	
	if (uuid_char->type == AIS_UUID_TYPE_16) {
		uuid16 = (ais_uuid_16_t *)uuid_char;
		bt_uuid16_create(uuid, uuid16->val);
	} else if(uuid_char->type == AIS_UUID_TYPE_32) {
		uuid32 = (ais_uuid_32_t *)uuid_char;
		bt_uuid32_create(uuid, uuid32->val);
	} else {
		uuid128 = (ais_uuid_128_t *)uuid_char;
		memcpy((void *)&uuid128_val, (void *)(uuid128->val), 16);
		bt_uuid128_create(uuid, uuid128_val);
	}
}

static void ais_gatt_add_read_char(struct gatt_db_attribute *service, 
					ais_char_init_t rc, void *user_data)
{
	bt_uuid_t uuid;

	bt_uuid_create(&uuid, rc.uuid);

	gatt_db_service_add_characteristic(service, &uuid, rc.perm, 
						rc.prop, rc_read_cb, NULL, user_data);

}

static void ais_gatt_add_write_char(struct gatt_db_attribute *service, 
					ais_char_init_t wc, void *user_data)
{
	bt_uuid_t uuid;

	bt_uuid_create(&uuid, wc.uuid);

	gatt_db_service_add_characteristic(service, &uuid, wc.perm, 
						wc.prop, rc_read_cb, wc_write_cb, user_data);

}

static void ais_gatt_add_wwnc_char(struct gatt_db_attribute *service, 
					ais_char_init_t wc, void *user_data)
{
	bt_uuid_t uuid;

	bt_uuid_create(&uuid, wc.uuid);

	gatt_db_service_add_characteristic(service, &uuid, wc.perm, 
						wc.prop, rc_read_cb, wwnc_write_cb, user_data);

}
static void ic_ccc_write_cb(struct gatt_db_attribute *attrib,
					unsigned int id, uint16_t offset,
					const uint8_t *value, size_t len,
					uint8_t opcode, struct bt_att *att,
					void *user_data)
{
	struct server *server = user_data;
	uint8_t ecode = 0;
    	ais_ccc_value_t val;

	printf("ic CCC Write called\n");

	if (!value || len != 2) {
		ecode = BT_ATT_ERROR_INVALID_ATTRIBUTE_VALUE_LEN;
		goto done;
	}

	if (offset) {
		ecode = BT_ATT_ERROR_INVALID_OFFSET;
		goto done;
	}

	if (value[0] == 0x00) {
		server->ind_enabled = false;
		server->not_enabled = false;
            	val = AIS_CCC_VALUE_NONE;
		if (bt_init_info && bt_init_info->ic.on_ccc_change) {
	    	    bt_init_info->ic.on_ccc_change(val);
		}
	}
	else if (value[0] == 0x02) {
		server->not_enabled = true;
		server->ind_enabled = false;
            	val = AIS_CCC_VALUE_INDICATE;
		printf("ic enabled\n");
    		if (bt_init_info && bt_init_info->ic.on_ccc_change) {
    		    bt_init_info->ic.on_ccc_change(val);
    		}
	}
	else
		ecode = 0x80;

done:
	gatt_db_attribute_write_result(attrib, id, ecode);
}
static void nc_ccc_write_cb(struct gatt_db_attribute *attrib,
					unsigned int id, uint16_t offset,
					const uint8_t *value, size_t len,
					uint8_t opcode, struct bt_att *att,
					void *user_data)
{
	struct server *server = user_data;
	uint8_t ecode = 0;
    	ais_ccc_value_t val;

	printf("nc CCC Write called\n");

	if (!value || len != 2) {
		ecode = BT_ATT_ERROR_INVALID_ATTRIBUTE_VALUE_LEN;
		goto done;
	}

	if (offset) {
		ecode = BT_ATT_ERROR_INVALID_OFFSET;
		goto done;
	}

	if (value[0] == 0x00) {
		server->ind_enabled = false;
		server->not_enabled = false;
            	val = AIS_CCC_VALUE_NONE;
		if (bt_init_info && bt_init_info->nc.on_ccc_change) {
	    	    bt_init_info->nc.on_ccc_change(val);
		}
	}
	else if (value[0] == 0x01) {
		server->not_enabled = true;
		server->ind_enabled = false;
            	val = AIS_CCC_VALUE_NOTIFY;
		printf("nc enabled\n");
    		if (bt_init_info && bt_init_info->nc.on_ccc_change) {
    		    bt_init_info->nc.on_ccc_change(val);
    		}
	}
	else
		ecode = 0x80;

done:
	gatt_db_attribute_write_result(attrib, id, ecode);
}

static void ccc_read_cb(struct gatt_db_attribute *attrib,
					unsigned int id, uint16_t offset,
					uint8_t opcode, struct bt_att *att,
					void *user_data)
{
	struct server *server = user_data;
	uint8_t value[2];

	value[0] = server->ind_enabled ? 0x02 : 0x00;
	value[1] = 0x00;

	gatt_db_attribute_read_result(attrib, id, 0, value, 2);
}

static void ais_gatt_add_ind_char(struct gatt_db_attribute *service, 
					ais_char_init_t ic, void *user_data)
{
	bt_uuid_t uuid;
	struct gatt_db_attribute *attr_ic;

	bt_uuid_create(&uuid, ic.uuid);

	attr_ic = gatt_db_service_add_characteristic(service, &uuid, ic.perm, 
						ic.prop, rc_read_cb,
					       	wc_write_cb, user_data);

	server->ind_handle = gatt_db_attribute_get_handle(attr_ic);


	bt_uuid16_create(&uuid, GATT_CLIENT_CHARAC_CFG_UUID);
	gatt_db_service_add_descriptor(service, &uuid,
					BT_ATT_PERM_READ | BT_ATT_PERM_WRITE,
					ccc_read_cb,
					ic_ccc_write_cb, server);

}

static void ais_gatt_add_notif_char(struct gatt_db_attribute *service, 
					ais_char_init_t nc, void *user_data)
{
	bt_uuid_t uuid;
	struct gatt_db_attribute *attr_nc;

	bt_uuid_create(&uuid, nc.uuid);

	attr_nc = gatt_db_service_add_characteristic(service, &uuid, nc.perm, 
						nc.prop, rc_read_cb, 
						nc_write_cb, user_data);

	server->not_handle = gatt_db_attribute_get_handle(attr_nc);

	bt_uuid16_create(&uuid, GATT_CLIENT_CHARAC_CFG_UUID);
	gatt_db_service_add_descriptor(service, &uuid,
					BT_ATT_PERM_READ | BT_ATT_PERM_WRITE,
					ccc_read_cb,
					nc_ccc_write_cb, server);
}

static void populate_db(struct gatt_db *db, ais_bt_init_t *ais_init)
{
	bt_uuid_t uuid;
	struct gatt_db_attribute *service;

	bt_uuid_create(&uuid, ais_init->uuid_svc);
	/*
	 * AIS primary service
	 */
	service = gatt_db_add_service(server->db, &uuid, true, 13);


	/* AIS read char */
	ais_gatt_add_read_char(service, ais_init->rc, server);
	
	/* AIS write char */
	ais_gatt_add_write_char(service, ais_init->wc, server);

	/* AIS ind char */
	ais_gatt_add_ind_char(service, ais_init->ic, server);

	/* AIS write char */
	ais_gatt_add_wwnc_char(service, ais_init->wwnrc, server);

	/* AIS notif char */
	//ais_gatt_add_ind_char(service, ais_init->nc, server);
	ais_gatt_add_notif_char(service, ais_init->nc, server);

	gatt_db_service_set_active(service, true);

}

static int l2cap_le_att_accept(int sk)
{
	int nsk;
	socklen_t optlen;
	struct sockaddr_l2 addr;
	char ba[18];

	if (sk < 0)
		goto fail;

	memset(&addr, 0, sizeof(addr));
	optlen = sizeof(addr);
	nsk = accept(sk, (struct sockaddr *) &addr, &optlen);
	if (nsk < 0) {
		perror("Accept failed");
		goto fail;
	}

	ba2str(&addr.l2_bdaddr, ba);
	server->client_addr = addr.l2_bdaddr;
	printf("Connect from %s\n", ba);

	return nsk;
fail:
	return -1;

}


static int l2cap_le_att_listen(bdaddr_t *src, int sec, uint8_t src_type)
{
	int sk;
	struct sockaddr_l2 srcaddr;
	struct bt_security btsec;

	sk = socket(PF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
	if (sk < 0) {
		perror("Failed to create L2CAP socket");
		return -1;
	}

	/* Set up source address */
	memset(&srcaddr, 0, sizeof(srcaddr));
	srcaddr.l2_family = AF_BLUETOOTH;
	srcaddr.l2_cid = htobs(ATT_CID);
	srcaddr.l2_bdaddr_type = src_type;
	bacpy(&srcaddr.l2_bdaddr, src);

	if (bind(sk, (struct sockaddr *) &srcaddr, sizeof(srcaddr)) < 0) {
		perror("Failed to bind L2CAP socket");
		goto fail;
	}

	/* Set the security level */
	memset(&btsec, 0, sizeof(btsec));
	btsec.level = sec;
	if (setsockopt(sk, SOL_BLUETOOTH, BT_SECURITY, &btsec,
							sizeof(btsec)) != 0) {
		fprintf(stderr, "Failed to set L2CAP security level\n");
		goto fail;
	}

	if (listen(sk, 10) < 0) {
		perror("Listening on socket failed");
		goto fail;
	}

	printf("Started listening on ATT channel. Waiting for connections\n");

	return sk;

fail:
	close(sk);
	return -1;
}

static void gatt_destroy(struct server *server)
{
	bt_gatt_server_unref(server->gatt);
}

static void att_disconnect_cb(int err, void *user_data)
{
	struct server *server = user_data;

	printf("Device disconnected: %s\n", strerror(err));

    	if (bt_init_info && (bt_init_info->on_disconnected)) {
    	    bt_init_info->on_disconnected();
    	}

	ble_advertising_start(adv_copy);

	if(server->gatt)
		gatt_destroy(server);

	/* mainloop_quit(); */
}

static void server_listen_cb(int fd, uint32_t events, void *user_data)
{
	int accept_fd;
	int mtu = 517;

	if (events & (EPOLLRDHUP | EPOLLHUP | EPOLLERR)) {
		mainloop_remove_fd(fd);
		return;
	}

	accept_fd = l2cap_le_att_accept(fd);
	if (accept_fd < 0) {
		fprintf(stderr, "Accept error\n");
		return;
	}

	// calling on_connected();
        if (bt_init_info && (bt_init_info->on_connected)) {
            bt_init_info->on_connected();
        }

	server->att = bt_att_new(accept_fd, false);
	if (!server->att) {
		fprintf(stderr, "Failed to initialze ATT transport layer\n");
		goto fail;
	}

	if (!bt_att_set_close_on_unref(server->att, true)) {
		fprintf(stderr, "Failed to set up ATT transport layer\n");
		goto fail;
	}

	if (!bt_att_register_disconnect(server->att, att_disconnect_cb, server,
									NULL)) {
		fprintf(stderr, "Failed to set ATT disconnect handler\n");
		goto fail;
	}

	server->gatt = bt_gatt_server_new(server->db, server->att, mtu);
	if (!server->gatt) {
		fprintf(stderr, "Failed to create GATT server\n");
		goto fail;
	}
	

fail:
	return;

	//server = server_create(accept_fd, att_mtu, hr_visible);
	//if (!server) {
	//	fprintf(stderr, "Server creation failed\n");
	//	close(accept_fd);
	//	return;
	//}

	//gatt_server = server;
}

static void conf_cb(void *user_data)
{
	printf("Received confirmation\n");
}
/* Functions provided in shared-mainloop library is not multi-thread safe.
 * The functions must be called in mainloop.
 * Calling out of mainloop will result in race condition and unpredictable
 * result.
 * */
static void pipe_read_cb(int fd, uint32_t events, void *user_data)
{
	struct server *server = user_data;
	ssize_t res;
	uint8_t byte, num = 8;
	bool result;
	struct data_entry *data;

	printf("Pipe read\n");

	if (events & (EPOLLRDHUP | EPOLLHUP | EPOLLERR)) {
		fprintf(stderr, "Pipe error\n");
		return;
	}

	res = read(fd, &byte, 1);
	if (res < 0)
		return;

	printf("byte %d\n", byte);

	if (byte == 0) {
		do {
			pthread_mutex_lock(&server->data_queue_mutex);
			data = queue_pop_head(server->data_queue);
			pthread_mutex_unlock(&server->data_queue_mutex);

			if (!data)
				break;

			printf("Send data from notif_queue\n");

			if (data->type == NOTIFICATION) {
				result = bt_gatt_server_send_notification(server->gatt,
						server->not_handle, data->data, data->length);
				if (!result)
					fprintf(stderr, "Failed to transmit notification\n");
			} else {
				result = bt_gatt_server_send_indication(server->gatt,
						server->ind_handle, data->data, data->length,
						conf_cb, NULL, NULL);
				if (!result)
					fprintf(stderr, "Failed to transmit notification\n");
			
			}

			free(data->data);
			free(data);
		} while (--num);
	} else {
		fprintf(stderr, "WRONG BYTE\n");
	}
}



void *thread_run(void *arg) 
{
	int fd;
	int sec = BT_SECURITY_LOW;
	uint8_t src_type = BDADDR_LE_PUBLIC;
	bdaddr_t src_addr; 
	//struct server *server = (struct server *)arg;

	bacpy(&src_addr, BDADDR_ANY);
	fd = l2cap_le_att_listen(&src_addr, sec, src_type);

	if (pipe(fds) < 0) {
		perror("pipe error");
		return NULL;
	}

	mainloop_init();

	if (mainloop_add_fd(fd, EPOLLIN, server_listen_cb, server, NULL) < 0) {
		fprintf(stderr, "Failed to add listen socket\n");
		close(fd);
		return NULL;
	}
	
	if (mainloop_add_fd(fds[0], EPOLLIN, pipe_read_cb, server, NULL) < 0) {
		fprintf(stderr, "Failed to add listen socket\n");
		close(fd);
		return NULL;
	}

	mainloop_run();

	return NULL;
}


ais_err_t ble_stack_init(ais_bt_init_t *ais_init)
{
	struct gatt_db *db;
	pthread_t mainloop;
	int ret;

        system("hciconfig hci0 up");

    	bt_init_info = ais_init;
	server = new0(struct server, 1);
	if (!server)
		return AIS_ERR_MEM_FAIL;

	db = gatt_db_new();
	if (!db)
		goto fail;
	server->db = db;

	server->data_queue = queue_new();
	pthread_mutex_init(&server->data_queue_mutex, NULL);

	populate_db(server->db, ais_init);

	ret = pthread_create(&mainloop, NULL, thread_run, server);
	server->mainloop_thread = mainloop;

	if (ret) {
		printf("pthread_create error\n");
		return AIS_ERR_STACK_FAIL;
	}
	printf("stack running\n");

	return AIS_ERR_SUCCESS;

fail:
	free(server);
	
	return AIS_ERR_MEM_FAIL;
}

static ais_err_t ble_adv_enable(void)
{
	struct hci_request rq;
	le_set_advertise_enable_cp advertise_cp;
	le_set_advertising_parameters_cp adv_params_cp;
	uint8_t status;
	int dd, ret;
	int hdev = 0;

	if (hdev < 0)
		hdev = hci_get_route(NULL);

	dd = hci_open_dev(hdev);
	if (dd < 0) {
		perror("Could not open device");
		return AIS_ERR_ADV_FAIL;
	}

	memset(&adv_params_cp, 0, sizeof(adv_params_cp));
	adv_params_cp.min_interval = htobs(0x00A0);
	adv_params_cp.max_interval = htobs(0x00A0);
	adv_params_cp.advtype = 0x00 ;
	adv_params_cp.chan_map = 7;

	memset(&rq, 0, sizeof(rq));
	rq.ogf = OGF_LE_CTL;
	rq.ocf = OCF_LE_SET_ADVERTISING_PARAMETERS;
	rq.cparam = &adv_params_cp;
	rq.clen = LE_SET_ADVERTISING_PARAMETERS_CP_SIZE;
	rq.rparam = &status;
	rq.rlen = 1;

	ret = hci_send_req(dd, &rq, 1000);
	if (ret < 0)
		goto done;

	memset(&advertise_cp, 0, sizeof(advertise_cp));
	advertise_cp.enable = 0x01;

	memset(&rq, 0, sizeof(rq));
	rq.ogf = OGF_LE_CTL;
	rq.ocf = OCF_LE_SET_ADVERTISE_ENABLE;
	rq.cparam = &advertise_cp;
	rq.clen = LE_SET_ADVERTISE_ENABLE_CP_SIZE;
	rq.rparam = &status;
	rq.rlen = 1;

	ret = hci_send_req(dd, &rq, 1000);

done:
	hci_close_dev(dd);

	if (ret < 0) {
		fprintf(stderr, "Can't set advertise mode on hci%d: %s (%d)\n",
						hdev, strerror(errno), errno);
		return AIS_ERR_ADV_FAIL;
	}

	if (status) {
		fprintf(stderr,
			"LE set advertise enable on hci%d returned status %d\n",
								hdev, status);
		return AIS_ERR_ADV_FAIL;
		
	}
	return AIS_ERR_SUCCESS;
}


ais_err_t ble_adv_set_advdata(ais_adv_init_t *adv) 
{
	int hdev = 0;
	int dd;
	char advdata[32] = { 0 };
	uint16_t ogf, ocf;
	int index;
	
	if (hdev < 0)
		hdev = hci_get_route(NULL);

	dd = hci_open_dev(hdev);
	if (dd < 0) {
		perror("Could not open device");
		return AIS_ERR_ADV_FAIL;
	}
	if (adv == NULL)
		return AIS_ERR_ADV_FAIL;

	/* add device name */
	if (adv->name.ntype == AIS_ADV_NAME_SHORT)
		advdata[2] = 0x08; // code for short name
	else
		advdata[2] = 0x09; // complete name

	strcpy(advdata + 3, adv->name.name);

	advdata[1] = 1 + strlen(adv->name.name);
	advdata[0] = 1 + advdata[1]; // 1+ for length itself

	///* add flag */
	index = 1 + advdata[1] + 1;
	advdata[index] = 0x02; // flag field length
	advdata[++index] = 0x01; // flag field type code
	advdata[++index] = adv->flag;

	advdata[0] += 1 + 0x02;

	/* add vendor data */
	advdata[++index] = adv->vdata.len + 1; // manuf field length
	advdata[++index] = 0xff;  // manuf field type code 
	memcpy(&advdata[++index], adv->vdata.data, adv->vdata.len);

	advdata[0] += 1 + adv->vdata.len + 1;

	hex_dump("  ", 8, (unsigned char *)advdata, 32); fflush(stdout);
	
	ogf = 0x0008; ocf = 0x0008;
	if (hci_send_cmd(dd, ogf, ocf, 32, advdata) < 0) {
		perror("Send failed");
		return AIS_ERR_ADV_FAIL;
	}

	return AIS_ERR_SUCCESS;


}
ais_err_t ble_advertising_start(ais_adv_init_t *adv) 
{
	ais_err_t err;

	if (NULL == adv_copy) {
		if (NULL == (adv_copy = (ais_adv_init_t *)malloc(sizeof(ais_adv_init_t)))) {
			perror("malloc failed");
			return AIS_ERR_MEM_FAIL;
		}
		memcpy((void *)adv_copy, adv, sizeof(ais_adv_init_t));
	}

	err = ble_adv_set_advdata(adv);
	if (err)
		return err;
	err = ble_adv_enable();
	
	return err;
}

#if 0
ais_bt_init_t ais_attr_info = {
	/* service */
	AIS_UUID_DECLARE_16(BLE_UUID_AIS_SERVICE),
	/* rc */
	{
  	  .uuid = AIS_UUID_DECLARE_16(BLE_UUID_AIS_RC),
	  .prop = AIS_GATT_CHRC_READ,
	  .perm = AIS_GATT_PERM_READ,
	  //.perm = AIS_GATT_PERM_READ | AIS_GATT_PERM_READ_AUTHEN,
	  .on_read = NULL,
	  .on_write = NULL,
	  .on_ccc_change = NULL 
	},

	/* wc */
	{
	  .uuid = AIS_UUID_DECLARE_16(BLE_UUID_AIS_WC),
	  .prop = AIS_GATT_CHRC_READ | AIS_GATT_CHRC_WRITE,
	  .perm = AIS_GATT_PERM_READ | AIS_GATT_PERM_WRITE,
	  .on_read = NULL,
	  .on_write = NULL,
	  //.on_write = (on_char_write_t)wc_write_handler,
	  .on_ccc_change = NULL
       	},

	///* ic */
	{	
       	  .uuid = AIS_UUID_DECLARE_16(BLE_UUID_AIS_IC),
	  .prop = AIS_GATT_CHRC_READ | AIS_GATT_CHRC_INDICATE,
	  .perm = AIS_GATT_PERM_READ,
	  .on_read = NULL,
	  .on_write = NULL,
	  //.on_ccc_change = ic_ccc_handler 
	  .on_ccc_change = NULL, 
	},

	///* wwnrc */
	{ 
	  .uuid = AIS_UUID_DECLARE_16(BLE_UUID_AIS_WWNRC), 
	  .prop = AIS_GATT_CHRC_READ | AIS_GATT_CHRC_WRITE_WITHOUT_RESP,
	  .perm = AIS_GATT_PERM_READ | AIS_GATT_PERM_WRITE,
	  .on_read = NULL,
	  //.on_write = (on_char_write_t)wwnrc_write_handler,
	  .on_write = NULL,
	  .on_ccc_change = NULL },
	
	///* nc */
	{ 
	  .uuid = AIS_UUID_DECLARE_16(BLE_UUID_AIS_NC),
	  .prop = AIS_GATT_CHRC_READ | AIS_GATT_CHRC_NOTIFY,
	  .perm = AIS_GATT_PERM_READ,
	  .on_read = NULL,
	  .on_write = NULL,
	  //.on_ccc_change = nc_ccc_handler,
	  .on_ccc_change = NULL, 
	},

	//connected,
	//disconnected
};
#endif

/**
 * API to de-initialize ble stack.
 * @return     0 on success, error code if failure.
 */
ais_err_t ble_stack_deinit()
{
	int ret;
	
	ret = pthread_cancel(server->mainloop_thread);
	if(!ret) {
		perror("pthread_cancel error");
		return 8;
	}

	bt_gatt_server_unref(server->gatt);
	gatt_db_unref(server->db);

	mainloop_exit_success();
 	printf("mainloop thread cancelled\n");

	if (adv_copy) free(adv_copy);

	return 0;
}


/**
 * API to send data via AIS's Notify Characteristics.
 * @parma[in]  p_data  data buffer.
 * @parma[in]  length  data length.
 * @return     0 on success, error code if failure.
 */
ais_err_t ble_send_notification(uint8_t *p_data, uint16_t length)
{
	struct queue *data_queue = server->data_queue;
	uint8_t byte = 0, *datacpy;

	struct data_entry *notif = new0(struct data_entry, 1);
	if (!notif) {
		perror("malloc error");
		return AIS_ERR_MEM_FAIL; 
	}

	if (NULL == (datacpy = (uint8_t *)malloc(length))) {
		perror("malloc failed");
		free(notif);
		return AIS_ERR_MEM_FAIL;
	}
	memcpy((void *)datacpy, (void *)p_data, length);

	notif->type = NOTIFICATION;
	notif->data = datacpy;
	notif->length = length;

	pthread_mutex_lock(&server->data_queue_mutex);
	queue_push_tail(data_queue, notif);
	pthread_mutex_unlock(&server->data_queue_mutex);

	if (write(fds[1], &byte, 1) < 0) {
		perror("write error");
		return AIS_ERR_GATT_NOTIFY_FAIL;
	}
	
	return 0;
}

/**
 * API to send data via AIS's Indicate Characteristics.
 * @parma[in]  p_data  data buffer.
 * @parma[in]  length  data length.
 * @return     0 on success, erro code if failure.
 */
ais_err_t ble_send_indication(uint8_t *p_data, uint16_t length)
{
	struct queue *data_queue= server->data_queue;
	uint8_t byte = 0, *datacpy;

	struct data_entry *ind = new0(struct data_entry, 1);
	if (!ind) {
		perror("malloc error");
		return AIS_ERR_MEM_FAIL; 
	}

	if (NULL == (datacpy = (uint8_t *)malloc(length))) {
		perror("malloc failed");
		free(ind);
		return AIS_ERR_MEM_FAIL;
	}
	memcpy((void *)datacpy, (void *)p_data, length);

	ind->type = INDICATION;
	ind->data = datacpy;
	ind->length = length;

	pthread_mutex_lock(&server->data_queue_mutex);
	queue_push_tail(data_queue, ind);
	pthread_mutex_unlock(&server->data_queue_mutex);

	if (write(fds[1], &byte, 1) < 0) {
		perror("write error");
		return AIS_ERR_GATT_INDICATE_FAIL;
	}

	return 0;
}

static int conn_list(int s, int dev_id, long arg)
{
	struct hci_conn_list_req *cl;
	struct hci_conn_info *ci;
	int id = arg;
	int i;

	if (id != -1 && dev_id != id)
		return 0;

	if (!(cl = malloc(10 * sizeof(*ci) + sizeof(*cl)))) {
		perror("Can't allocate memory");
		exit(1);
	}
	cl->dev_id = dev_id;
	cl->conn_num = 10;
	ci = cl->conn_info;

	if (ioctl(s, HCIGETCONNLIST, (void *) cl)) {
		perror("Can't get connection list");
		exit(1);
	}

	for (i = 0; i < cl->conn_num; i++, ci++) {
		if (!bacmp(&ci->bdaddr, &server->client_addr)) {
			server->conn_handle = ci->handle;
			break;
		}
	}
	printf("handle %d\n", server->conn_handle);

	free(cl);
	return 0;
}
/**
 * API to disconnect BLE connection.
 * @param[in]  reason  the reason to disconnect the connection.
 */
void ble_disconnect(uint8_t reason)
{
	uint16_t dev_id = 0;
	int err;
	int dd;
	
	printf("Connections:\n");

	hci_for_each_dev(HCI_UP, conn_list, dev_id);

	dd = hci_open_dev(dev_id);
	if (dd < 0) {
		perror("Could not open device");
		return;
	}

	err = hci_disconnect(dd, server->conn_handle, reason, 10000);
	if (err < 0) {
		perror("Could not disconnect");
		return; 
	}

	hci_close_dev(dd);
	
}

/**
 * API to stop bluetooth advertising.
 * @return     0 on success, erro code if failure.
 */
ais_err_t ble_advertising_stop()
{
	struct hci_request rq;
	le_set_advertise_enable_cp advertise_cp;
	uint8_t status;
	int dd, ret;
	int hdev = 0;

	if (hdev < 0)
		hdev = hci_get_route(NULL);

	dd = hci_open_dev(hdev);
	if (dd < 0) {
		perror("Could not open device");
		return AIS_ERR_ADV_FAIL;
	}

	memset(&advertise_cp, 0, sizeof(advertise_cp));
	advertise_cp.enable = 0x00;

	memset(&rq, 0, sizeof(rq));
	rq.ogf = OGF_LE_CTL;
	rq.ocf = OCF_LE_SET_ADVERTISE_ENABLE;
	rq.cparam = &advertise_cp;
	rq.clen = LE_SET_ADVERTISE_ENABLE_CP_SIZE;
	rq.rparam = &status;
	rq.rlen = 1;

	ret = hci_send_req(dd, &rq, 1000);

	hci_close_dev(dd);

	if (ret < 0) {
		fprintf(stderr, "Can't set advertise mode on hci%d: %s (%d)\n",
						hdev, strerror(errno), errno);
		return AIS_ERR_ADV_FAIL;
	}

	if (status) {
		fprintf(stderr,
			"LE set advertise enable on hci%d returned status %d\n",
								hdev, status);
		return AIS_ERR_ADV_FAIL;
	}

	return AIS_ERR_SUCCESS;
}

static void bdaddrcpy(uint8_t *d, uint8_t *s)
{
	int i;
	for (i = 0; i < 6; i++)
		d[i] = s[5-i];
}

/**
 * API to start bluetooth advertising.
 * @parma[out]  mac  the uint8_t[BD_ADDR_LEN] space the save the mac address.
 * @return     0 on success, erro code if failure.
 */
ais_err_t ble_get_mac(uint8_t *mac)
{
	int ctl;
	struct hci_dev_info di;

	di.dev_id = 0;

	if ((ctl = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI)) < 0) {
		perror("Can't open HCI socket.");
		return 8;
	}
	
	if (ioctl(ctl, HCIGETDEVINFO, (void *) &di)) {
		perror("Can't get device info");
		return 8;
	}

	bdaddrcpy(mac, di.bdaddr.b);

	return 0;
}

#if 0
ais_adv_init_t adv = {
	.name = { .ntype = 1, .name = "AliIoT-test" },
};

uint8_t data[] = {1, 2, 3, 4, 5, 6};

int main()
{
	int i;
	uint8_t mac[6] = {0};
	ble_get_mac(mac);
	printf("address: ");
	for (i = 0; i < 6; i++){
		if ( i < 5) {
			printf("%02X:",  mac[i]);
			continue;
		}
		printf("%02X",  mac[i]);
	}
	printf("\n");
	ble_stack_init(&ais_attr_info);
	ble_advertising_start(&adv);
	sleep(30);
	ble_send_notification(data, 6);
	ble_send_indication(data, 6);
	
	sleep(5);
	ble_disconnect(0x13);
	pthread_exit(NULL);
}
#endif
