#!/bin/sh

### BEGIN INIT INFO
# Provides:          dpsd
# Required-Start:    $syslog $networking
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: dps deamon server
### END INIT INFO

PATH=/system/dps/bin:/sbin:/bin:/usr/sbin:/usr/bin
DAEMON=/system/dps/bin/dpsd
NAME=dpsd
DESC="DPS daemon"

case $1 in
    start)
        echo -n "Starting $DESC: "
        start-stop-daemon --start --quiet --background --exec $DAEMON
        echo "done."
        ;;
    stop)
        echo -n "Stopping $DESC: "
        start-stop-daemon --stop --quiet --exec $DAEMON
        echo "done."
        ;;
    restart|reload)
        echo -n "Restarting $DESC: "
		start-stop-daemon --stop --quiet --exec $DAEMON
		sleep 1
		start-stop-daemon --start --quiet --background --exec $DAEMON
		echo "done."
        ;;
    *)
        echo "$0 start|stop|restart|reload"
        ;;
esac
