/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

#include "kv.h"
#include "kv_helper/kv_helper.h"
#include <stddef.h>

#define DEFAULT_KV_FILE "/data/.mesh_kv.db"
static kv_file_t *kvfile = NULL;

int hal_kv_set(const char *key, const void *val, int len, int sync)
{
    if (!kvfile) {
        kvfile = kv_open(DEFAULT_KV_FILE);
        if (!kvfile) {
            return -1;
        }
    }

    return kv_set_blob(kvfile, (char *)key, (char *)val, len);
}

int hal_kv_get(const char *key, void *buffer, int *buffer_len)
{
    if (!kvfile) {
        kvfile = kv_open(DEFAULT_KV_FILE);
        if (!kvfile) {
            return -1;
        }
    }

    return kv_get_blob(kvfile, (char *)key, buffer, buffer_len);
}

int hal_kv_del(const char *key)
{
    if (!kvfile) {
        kvfile = kv_open(DEFAULT_KV_FILE);
        if (!kvfile) {
            return -1;
        }
    }

    return kv_del(kvfile, (char *)key);
}

