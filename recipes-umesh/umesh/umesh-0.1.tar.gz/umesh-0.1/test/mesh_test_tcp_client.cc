/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <aos/aos.h>
#include <netmgr.h>
#include <signal.h>

#include "mesh.h"
#include "umesh.h"
#include "mesh_socket.h"

#define RCV_BUF_SIZE 1024

int g_socket_fd = 0;
bool g_socket_ready = false;
pthread_t mesh_recv_thread;
pthread_t mesh_send_thread;

typedef void (*FuncHandleMeshRecvOnEvent)(const uint8_t *recvdata, uint16_t len, char *srcaddr);

FuncHandleMeshRecvOnEvent on_event_handle_mesh_recv; //callback for mesh recv process
void *MeshSocketSendThread(void *arg);
void *MeshSocketRecvThread(void *arg);

void mesh_status_callback(void)
{
    int ret;

    printf("=======================================================\n");
    printf("mesh status callback\n");

    if (umesh_get_device_state() == DEVICE_STATE_LEADER ||
        umesh_get_device_state() == DEVICE_STATE_ROUTER)
    {
        if (!g_socket_ready)
        {
            ret = MeshSocketCreate();
            if (ret == MESH_SUCCESS) {
                g_socket_ready = true;
            }
            else
            {
                return;
            }

            // throw mesh recv thread
            pthread_create(&mesh_recv_thread, NULL, MeshSocketRecvThread, NULL);
        }
        else if (umesh_get_device_state() == DEVICE_STATE_ROUTER)
        {
            // rebind the port due to the role changes
            // if we bind the same port no matter of roles,
            // we can remove below code here.
            struct mesh_sockaddr_in sock_addr;

            memset(&(sock_addr), 0, sizeof(sock_addr));
            sock_addr.sin_family = AF_INET;
            sock_addr.sin_port = htons(NODE_PORT);

            ret = lwip_bind(g_socket_fd, (const struct sockaddr *)&sock_addr, sizeof(sock_addr));
            if (ret < 0)
            {
                printf("MeshSocketCreate:bind failed\n");
                lwip_close(g_socket_fd);
            }
        }
    }
    else if (umesh_get_device_state() == DEVICE_STATE_DETACHED)
    {
        // release allocated resource previously
        if (g_socket_ready)
        {
            g_socket_ready = false;
            pthread_cancel(mesh_recv_thread);
            lwip_close(g_socket_fd);
            printf("close (%d)\n", g_socket_fd);
        }
    }
    else
    {
        // do nothing
        return;
    }
}

static void app_delayed_action(void *arg)
{
    (void)arg;
    printf("start mesh\n");
    umesh_init(MODE_RX_ON);
    umesh_stop();
    umesh_start(mesh_status_callback);
}

void app_main_entry(void *arg)
{
    (void)arg;
    aos_post_delayed_action(1000, app_delayed_action, arg);
    aos_loop_run();
}

void *MeshSocketInitEntry(void *arg)
{
    (void)arg;
    aos_main_entry(0, NULL);
    aos_task_new("mesh", app_main_entry, NULL, 8192);
}

//create mesh socket-UDP
void MeshSocketInit(void)
{
    MeshSocketInitEntry(NULL);

    // throw mesh send thread
    pthread_create(&mesh_send_thread, NULL, MeshSocketSendThread, NULL);
}

void MeshSocketRelease(void)
{
    umesh_stop();
}

int MeshSocketCreate(void)
{
    int ret;
    struct mesh_sockaddr_in sock_addr;

    printf("MeshSocketCreate!\n");

    // create the socket fd
    g_socket_fd = lwip_socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (g_socket_fd < 0) {
        printf("MeshSocketCreate: Creating socket failed\n");
        return SOCKET_CREATE_ERROR;
    }
    printf("MeshSocketCreate:g_socket_fd=%d\n", g_socket_fd);

    // bind listen port
    memset(&(sock_addr), 0, sizeof(sock_addr));
    sock_addr.sin_family = AF_INET;
 
    if (umesh_get_device_state() == DEVICE_STATE_LEADER) {
        printf("Gateway mode, will bind the gateway port\n");
        sock_addr.sin_port = htons(GATEWAY_PORT);
    } else {
        printf("None gateway mode, will bind the node port\n");
        sock_addr.sin_port = htons(NODE_PORT);
    }

    ret = lwip_bind(g_socket_fd, (const struct sockaddr *)&sock_addr, sizeof(sock_addr));
    if(ret < 0) {
        printf("MeshSocketCreate:bind failed\n");
        lwip_close(g_socket_fd);
        return SOCKET_BIND_ERROR;
    }

    return MESH_SUCCESS;
}

int MeshSocketSend(int socket_fd, char *buff, int port, int len, char *dstaddr)
{
    int sendlen=-1; 
    struct mesh_sockaddr_in sock_addr;
    sock_addr.sin_len = sizeof(sock_addr);
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_port = htons(port);
    sock_addr.sin_addr.s_addr = inet_addr(dstaddr);
    sendlen = lwip_sendto(socket_fd, buff, len, 0, (struct sockaddr *)&sock_addr, sizeof(sock_addr));
    return sendlen;
}

void *MeshSocketRecvThread(void *arg)
{
    (void)arg;
    uint32_t recvlen = 0;
    uint8_t  buff[RCV_BUF_SIZE];
    struct mesh_sockaddr_in sock_addr;
    uint32_t len = sizeof(struct sockaddr);
    printf("MeshSocketRecv:start recving\n");

    while(1) {
        if (g_socket_ready) {
            memset(buff, 0, RCV_BUF_SIZE);
            recvlen = lwip_recvfrom(g_socket_fd, buff, RCV_BUF_SIZE, 0, (struct sockaddr *)&sock_addr, &len);
            if (recvlen > 0) {
                on_event_handle_mesh_recv(buff, recvlen, inet_ntoa(sock_addr.sin_addr));
                recvlen = 0;
            }
        }
        else {
            // if sockfd is not ready
            // sleep 50ms
            usleep(1000*50);
        }
    }
}

void *MeshSocketSendThread(void *arg)
{
    (void)arg;
    int ret;
    static int count;
    char buf1[100];
    char buf2[100];

    while (1) {
        usleep(1000 * 1000 * 1); //1s
        if (g_socket_ready) {
            count++;
            if (umesh_get_device_state() == DEVICE_STATE_LEADER) {
                printf("Gateway:send msg to child, count=%d\n", count);
                memset(buf1, 0, 100);
                sprintf(buf1, "hello,this msg from gateway, count=%d\n", count);
                ret = MeshSocketSend(g_socket_fd, buf1, NODE_PORT, sizeof(buf1), MULTICAST_IP);
                if (ret < 0) {
                    printf("MeshSocketSend: fail to send msg\n");
                }
            }
            else {
                printf("Child:send msg to gateway, count=%d\n", count);
                memset(buf2, 0, 100);
                sprintf(buf2, "hello,this msg from child, count=%d\n", count);
                ret = MeshSocketSend(g_socket_fd, buf2, GATEWAY_PORT, sizeof(buf2), GATEWAY_IP);
                if (ret < 0) {
                    printf("MeshSocketSend: fail to send msg\n");
                }
            }
        }
    }
}

void MeshHandleRecvPrint(const uint8_t *recvdata, uint16_t len, char *srcaddr)
{
    printf("MeshSocketRecv data %d Bytes from %s\n", len, srcaddr);
    printf("%s\n", recvdata);
}

#define BUFLEN 100

const char *tcp_serv = "192.168.4.1";

int main()
{
    int sockfd;
    struct sockaddr_in s_addr;
    socklen_t len;
    unsigned int port = 7777;
    char recv_buf[BUFLEN];
    char send_buf[BUFLEN];
    static int count = 0;

    MeshSocketInit();
    on_event_handle_mesh_recv = MeshHandleRecvPrint;

    // linux tcp client init in the main process
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("fail to create tcp socket");
        exit(errno);
    }

    bzero(&s_addr, sizeof(s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons(port);

    if (inet_aton(tcp_serv, (struct in_addr*)&s_addr.sin_addr.s_addr) == 0) {
        perror("IP error");
        exit(errno);
    }

    if (connect(sockfd,(struct sockaddr*)&s_addr,sizeof(struct sockaddr)) == -1) {
        perror("connect");
        exit(errno);
    } else {
        printf("*****************tcp client start***************\n");
    }

    while(1) {
        bzero(recv_buf, BUFLEN);
        bzero(send_buf, BUFLEN);

        len = recv(sockfd, recv_buf, BUFLEN, 0);
        if (len > 0)
            printf("tcp receive massage:%s\n", recv_buf);
        else {
            printf("tcp server stop\n");
            //break;
        }

        // send message
        sprintf(send_buf, "hello,this msg sends to tcp server from %d, count=%d\n", sockfd, count++);
        len = send(sockfd, send_buf, strlen(send_buf), 0);

        if (len > 0)
            printf("tcp send successful\n");
        else {
            printf("tcp send failed\n");
            //break;
        }
    }

    close(sockfd);

    return 0;
}
