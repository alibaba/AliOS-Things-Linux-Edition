/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 */

#ifndef MESH_SOCKET_H_
#define MESH_SOCKET_H_

#include <stdio.h> 
#include <string.h> 
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include "mesh.h"

#define GATEWAY_PORT 12345
#define NODE_PORT 45678
#define GATEWAY_IP "10.0.0.2"
#define MULTICAST_IP "224.0.0.252"

struct mesh_sockaddr_in {
  uint8_t sin_len;
  uint8_t sin_family;
  uint16_t sin_port;
  struct in_addr  sin_addr;
#define SIN_ZERO_LEN 8
  char sin_zero[SIN_ZERO_LEN];
};

void MeshSocketInit(void);
void MeshSocketRelease(void);
int MeshSocketCreate(void);
//int GetGatewayMode(void);
int MeshSocketSend(int socket_fd, char *buff, int port, int len, char *dstaddr);
void *MeshSocketRecv(void *arg);
typedef void (*FuncHandleMeshRecvOnEvent)(const uint8_t *recvdata, uint16_t len, char *srcaddr);
void MeshSocketTest();
extern FuncHandleMeshRecvOnEvent on_event_handle_mesh_recv; //callback for mesh recv process 
void MeshHandleRecvPrint(const uint8_t *recvdata, uint16_t len, char *srcaddr);

#endif // MESH_SOCKET_H_
