#!/bin/sh
openvpn --rmtun --dev $1
