/** @file
 *  @brief Bluetooth Mesh Profile APIs.
 */

/*
 * Copyright (c) 2017 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef __WIFI_MESH_H
#define __WIFI_MESH_H

#ifdef __cplusplus
extern "C"
{
#endif

int aos_main_entry(int argc, char **argv);

void linux_wifi_register(void);


#if defined(__cplusplus)
}
#endif

#endif /* __WIFI_MESH_H */

