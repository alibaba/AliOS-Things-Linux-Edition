/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>

#define BUFLEN 100

const char* IP = "192.168.4.1";
const unsigned int SERV_PORT = 7777;
void packet_exchange(int sockfd);

int main(int argc, char *argv[])
{
	int listenfd, connectfd;
	struct sockaddr_in s_addr, c_addr;
	char buf[BUFLEN];
	unsigned int port, listnum;
	pid_t childpid;
	socklen_t len;

	if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
		perror("socket");
		exit(errno);
	}

	port = SERV_PORT;

	listnum = 5;

	bzero(&s_addr, sizeof(s_addr));
	s_addr.sin_family = AF_INET;
	s_addr.sin_port = htons(port);
	s_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	if ((bind(listenfd, (struct sockaddr*) &s_addr,sizeof(struct sockaddr))) == -1) {
		perror("bind");
		exit(errno);
	}

	if (listen(listenfd, listnum) == -1) {
		perror("listen");
		exit(errno);
	}

	while(1) {
		printf("*****************server start***************\n");
		len = sizeof(struct sockaddr);
		if((connectfd = accept(listenfd, (struct sockaddr*) &c_addr, &len)) == -1){
			perror("accept");        
			exit(errno);
		}
		else
		{
			printf("connected with client, IP is: %s, PORT is: %d\n", inet_ntoa(c_addr.sin_addr), ntohs(c_addr.sin_port));
		}

		if((childpid = fork()) == 0)
		{
			packet_exchange(connectfd);

			close(connectfd);

			printf("exit?: y->yess; n->no\n");
			bzero(buf, BUFLEN);
			fgets(buf, BUFLEN, stdin);
			if (!strncasecmp(buf,"y",1)) {
				printf("server stop\n");
				break;
			}

			exit(0);
		}
	}

	close(listenfd);
	return 0;
}

void packet_exchange(int sockfd)
{
    socklen_t len;
    char recv_buf[BUFLEN];
    char send_buf[BUFLEN];
    static int count = 0;

    while (1) {
	    bzero(recv_buf, BUFLEN);
	    bzero(send_buf, BUFLEN);

            sprintf(send_buf, "hello,this msg send to %d client, count=%d\n", sockfd, count++);
            len = send(sockfd, send_buf, strlen(send_buf), 0);

	    if (len > 0)
		    printf("tcp server send successful\n");
	    else {
		    printf("tcp server send fail\n");
		    break;
	    }

	    len = recv(sockfd, recv_buf, BUFLEN, 0);
	    if (len > 0)
		    printf("recv message: %s\n", recv_buf);
	    else {
		    printf("client stop\n");
	            break;
	    }

	    // send one packet every second
	    sleep(1);
    }
}
