/*
 * Copyright (C) 2015-2018 Alibaba Group Holding Limited
 *
 */

#define TAG "MESH"

#include <stdio.h> 
#include <stdlib.h>
#include <string.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <sys/select.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <aos/aos.h>
#include <netmgr.h>
#include <signal.h>

#include <linux/if.h>
#include <linux/if_packet.h>
#include <sys/ioctl.h>

#include "mesh.h"
#include "umesh.h"
#include "mesh_socket.h"

#define RCV_BUF_SIZE 1024

int g_socket_fd = 0;
bool g_socket_ready = false;
bool g_leader_down = false;
pthread_t recv_thread;

typedef void (*FuncHandleMeshRecvOnEvent)(const uint8_t *recvdata, uint16_t len, char *srcaddr);

FuncHandleMeshRecvOnEvent on_event_handle_mesh_recv; //callback for mesh socket recv process

// callback for mesh bcast data recv
void mesh_bcast_recv_callback(uint8_t *buf, uint32_t len);

/* either using ucast socket or bcast to process arbitration msg
 * - unicast socket: arbitration depends on leader
 * - bcast: arbitration depends on each distributed node
 */
void mesh_bcast_recv_callback(uint8_t *buf, uint32_t len)
{
    if (g_socket_ready) {
        printf("won't process bcast data since socket is ready for message exchange\n");
        printf("\n");
        return;
    }
    else {
        printf("hello, this is a bcast data frame, arbitration parameters: %s, len: %d\n", buf, len);
        printf("\n");
        // add arbitration logic here during leader is offline
    }
}

// is_leader_down: indicates whether or not leader has been offline,
// detection depends on the keep alive mechanism implemented at
// the mesh layer.
void mesh_status_callback(bool is_leader_down)
{
    int ret;

    printf("=======================================================\n");
    printf("mesh status callback\n");

    if (umesh_get_device_state() == DEVICE_STATE_ROUTER ||
        umesh_get_device_state() == DEVICE_STATE_LEAF) {
        if (is_leader_down) {
            printf("leader is offline\n");
            g_leader_down = true;

            // release socket resource when detecting leader offline,
            // using bcast method to transfer arbitration parameters now
            if (g_socket_ready) {
                g_socket_ready = false;
                pthread_cancel(recv_thread);
                lwip_close(g_socket_fd);
                printf("close (%d) due to leader down\n", g_socket_fd);
            }
            return;
        }
        else {
            if (g_leader_down) {
                // occur just when leader recovers from offline,
                // then will switch back to socket method
                printf("leader recovers from offline\n");
                g_leader_down = false;
            }
            else {
                printf("leader exists\n");
            }
        }
    }

    // below logic keeps the same as before
    if (umesh_get_device_state() == DEVICE_STATE_LEADER ||
        umesh_get_device_state() == DEVICE_STATE_ROUTER)
    {
        if (!g_socket_ready) {
            ret = MeshSocketCreate();
            if (ret == MESH_SUCCESS) {
                g_socket_ready = true;
            }
            else {
                return;
            }

            // throw mesh recv thread
            pthread_create(&recv_thread, NULL, MeshSocketRecv, NULL);
        }
        else if (umesh_get_device_state() == DEVICE_STATE_ROUTER) {
            // rebind the port due to the role changes
            // if we bind the same port no matter of roles,
            // we can remove below code here.
            struct mesh_sockaddr_in sock_addr;

            memset(&(sock_addr), 0, sizeof(sock_addr));
            sock_addr.sin_family = AF_INET;
            sock_addr.sin_port = htons(NODE_PORT);

            ret = lwip_bind(g_socket_fd, (const struct sockaddr *)&sock_addr, sizeof(sock_addr));
            if (ret < 0) {
                printf("MeshSocketCreate:bind failed\n");
                lwip_close(g_socket_fd);
            }
        }
    }
    else if (umesh_get_device_state() == DEVICE_STATE_DETACHED)
    {
        // release allocated resource previously
        if (g_socket_ready) {
            g_socket_ready = false;
            pthread_cancel(recv_thread);
            lwip_close(g_socket_fd);
            printf("close (%d) due to becoming detached\n", g_socket_fd);
        }
    }
    else {
        // do nothing
        return;
    }
}

static void app_delayed_action(void *arg)
{
    (void)arg;
    //uint8_t netid[] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06};
    uint8_t netid[] = {0x02, 0x03, 0x04, 0x05, 0x06, 0x07};

    printf("start mesh\n");
    umesh_init(MODE_RX_ON);
    umesh_register_bcast_callback(mesh_bcast_recv_callback);
    umesh_stop();
    umesh_start(mesh_status_callback);

    // set new extnetid
    umesh_extnetid_t extnetid;
    memcpy(extnetid.netid, netid, 6);
    extnetid.len = 6;
    umesh_set_extnetid(&extnetid);
}

void app_main_entry(void *arg)
{
    (void)arg;
    aos_post_delayed_action(1000, app_delayed_action, arg);
    aos_loop_run();
}

void *MeshSocketInitEntry(void *arg)
{
    (void)arg;
    aos_main_entry(0, NULL);
    aos_task_new("mesh", app_main_entry, NULL, 8192);
}

//create mesh socket-UDP
void MeshSocketInit(void)
{
    MeshSocketInitEntry(NULL);
}

void MeshSocketRelease(void)
{
    umesh_stop();
}

int MeshSocketCreate(void)
{
    int ret;
    struct mesh_sockaddr_in sock_addr;

    printf("MeshSocketCreate!\n");

    // create the socket fd
    g_socket_fd = lwip_socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (g_socket_fd < 0) {
        printf("MeshSocketCreate: Creating socket failed\n");
        return SOCKET_CREATE_ERROR;
    }
    printf("MeshSocketCreate:g_socket_fd=%d\n", g_socket_fd);

    // bind listen port
    memset(&(sock_addr), 0, sizeof(sock_addr));
    sock_addr.sin_family = AF_INET;
 
    if (umesh_get_device_state() == DEVICE_STATE_LEADER) {
        printf("Gateway mode, will bind the gateway port\n");
        sock_addr.sin_port = htons(GATEWAY_PORT);
    } else {
        printf("None gateway mode, will bind the node port\n");
        sock_addr.sin_port = htons(NODE_PORT);
    }

    ret = lwip_bind(g_socket_fd, (const struct sockaddr *)&sock_addr, sizeof(sock_addr));
    if(ret < 0) {
        printf("MeshSocketCreate:bind failed\n");
        lwip_close(g_socket_fd);
        return SOCKET_BIND_ERROR;
    }

    return MESH_SUCCESS;
}

char *GetMeshIpAddr(void) {
    const ip4_addr_t *src;
    struct in_addr ip4_addr;
    src = (const ip4_addr_t *)ur_adapter_get_default_ipaddr();
    ip4_addr.s_addr = src->addr;
    return (inet_ntoa(ip4_addr));
}

int MeshSocketSend(int socket_fd, char *buff, int port, int len, char *dstaddr)
{
    int sendlen=-1;
    struct mesh_sockaddr_in sock_addr;

    sock_addr.sin_len = sizeof(sock_addr);
    sock_addr.sin_family = AF_INET;
    sock_addr.sin_port = htons(port);
    sock_addr.sin_addr.s_addr = inet_addr(dstaddr);

    if (g_socket_ready) {
        sendlen = lwip_sendto(socket_fd, buff, len, 0, (struct sockaddr *)&sock_addr, sizeof(sock_addr));
    }

    return sendlen;
}

void *MeshSocketRecv(void *arg)
{
    (void)arg;
    static int count=0;
    int recvlen = 0;
    uint8_t  buff[RCV_BUF_SIZE];
    struct mesh_sockaddr_in sock_addr;
    uint32_t len = sizeof(struct sockaddr);
    printf("MeshSocketRecv:start recving\n");

    while(1) {
        if (g_socket_ready) {
            recvlen = lwip_recvfrom(g_socket_fd, buff, RCV_BUF_SIZE, 0, (struct sockaddr *)&sock_addr, &len);
            if (recvlen > 0) {
                printf("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n");
                printf("recv_count=%d, recv %d Bytes, dst_addr: %s",
                        ++count,
                        recvlen,
                        GetMeshIpAddr());
                printf(" <- src_addr: %s\n", (inet_ntoa(sock_addr.sin_addr)));

                //on_event_handle_mesh_recv(buff, recvlen, inet_ntoa(sock_addr.sin_addr));
                printf("MeshSocketRecv data %d Bytes from %s, recv count=%d\n", recvlen, inet_ntoa(sock_addr.sin_addr), ++count);
                printf("%s\n", buff);
                //memset(buff, 0, RCV_BUF_SIZE);
                recvlen = 0;
            }
            else if (recvlen <= 0) {
                printf("recvlen < 0\n");
            }
        }
        else {
            // if sockfd is not ready
            // sleep 10ms
            usleep(1000*10);
        }
    }
}

void MeshHandleRecvPrint(const uint8_t *recvdata, uint16_t len, char *srcaddr)
{
    static int count=0;
    printf("MeshSocketRecv data %d Bytes from %s, recv count=%d\n", len, srcaddr, ++count);
    printf("%s\n", recvdata);
}

//test
int main()
{
    static int count=0;
    char buf1[100] = {0};
    char buf2[100] = {0};
    int ret;
    int sockfd;
    char source_ip[32];

    MeshSocketInit();
    on_event_handle_mesh_recv = MeshHandleRecvPrint;

    // create socket to fetch mac addr
    if ((sockfd = socket(PF_PACKET, SOCK_RAW, IPPROTO_RAW)) == -1) {
        printf("send socket fail\n");
        return -1;
    }

    // address resolution
    struct ifreq ifreq_ip;
    memset(&ifreq_ip, 0, sizeof(ifreq_ip));
    strncpy(ifreq_ip.ifr_name, "wlan0", IFNAMSIZ-1); // giving name of Interface
    if (ioctl(sockfd, SIOCGIFADDR, &ifreq_ip) < 0) {  // get ipv4 address
        printf("error in SIOCGIFADDR\n");
    }

    strcpy(source_ip, inet_ntoa(((struct sockaddr_in*)&(ifreq_ip.ifr_ifru.ifru_addr))->sin_addr));

    while (1) {
        usleep(1000 * 1000 * 1);
        if (g_socket_ready) {  // if socket is avaiable, using socket to send, otherwise, using bcast to send
            count++;
            if (umesh_get_device_state() == DEVICE_STATE_LEADER) {
              /*  printf("Gateway:send msg to child, count=%d\n", count);
                memset(buf1, 0, 100);
                sprintf(buf1, "hello,this msg from gateway, count=%d\n", count);
                ret = MeshSocketSend(g_socket_fd, buf1, NODE_PORT, sizeof(buf1), MULTICAST_IP);
                if (ret < 0) {
                    printf("MeshSocketSend: fail to send msg\n");
                }
                */
            }
            else {
                printf("Child:send socket to gateway, count=%d\n", count);
                //memset(buf2, 0, 100);
                sprintf(buf2, "hello,this msg from child, count=%d\n", count);
                ret = MeshSocketSend(g_socket_fd, buf2, GATEWAY_PORT, sizeof(buf2), GATEWAY_IP);
                if (ret < 0) {
                    printf("MeshSocketSend: fail to send msg\n");
                }
            }
        }
        else if (g_leader_down) {
            count++;
            printf("Child:send bcast msg to its nbrs, count=%d\n", count);
            //memset(buf2, 0, 100);
            sprintf(buf2, "hello,this msg from node:%s, count=%d\n", source_ip, count);
            umesh_bcast_send((uint8_t *)buf2, sizeof(buf2));
        }
    }
    return 1;
}
