/** @file
 *  @brief Bluetooth Mesh Profile APIs.
 */

/*
 * Copyright (c) 2017 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef __WIFI_MESH_H
#define __WIFI_MESH_H

#ifdef __cplusplus
extern "C"
{
#endif

enum MeshResultCode {
  MESH_SUCCESS = 0,
  MESH_ERROR,
  SOCKET_INIT_ERROR,
  SOCKET_CREATE_ERROR,
  SOCKET_BIND_ERROR,
  MESH_STRING_ERROR,
  JSON_ERROR,
  CONNECTION_TIMEOUT,
};

struct ip4_addr_t {
  uint32_t addr;
};

const void *ur_adapter_get_default_ipaddr(void);

int aos_main_entry(int argc, char **argv);

void linux_wifi_register(void);

int lwip_socket(int domain, int type, int protocol);
int lwip_bind(int s, const struct sockaddr *name, socklen_t namelen);

int lwip_sendto(int s, const void *dataptr, size_t size, int flags,
		const struct sockaddr *to, socklen_t tolen);
int lwip_recvfrom(int s, void *mem, size_t len, int flags,
		  struct sockaddr *from, socklen_t *fromlen);
int lwip_close(int s);

#if defined(__cplusplus)
}
#endif

#endif /* __WIFI_MESH_H */
