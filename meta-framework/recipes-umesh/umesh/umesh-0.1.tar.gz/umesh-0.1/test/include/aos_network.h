/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */
 #ifndef __AOS_NETWORK_H
#define __AOS_NETWORK_H
 

#ifdef __cplusplus
extern "C"
{
#endif


typedef struct {
    char *host; /**< host ip(dotted-decimal notation) or host name(string) */
    uint16_t port; /**< udp port or tcp port */
} platform_netaddr_t, *pplatform_netaddr_t;



#define _IN_            /**< indicate that this is a input parameter. */
#define _OUT_           /**< indicate that this is a output parameter. */
#define _INOUT_         /**< indicate that this is a io parameter. */
#define _IN_OPT_        /**< indicate that this is a optional input parameter. */
#define _OUT_OPT_       /**< indicate that this is a optional output parameter. */
#define _INOUT_OPT_     /**< indicate that this is a optional io parameter. */


#define EXTERN_FUN extern

void *platform_udp_server_create(_IN_ uint16_t port);

void *platform_udp_client_create(void);


void *platform_udp_multicast_server_create(pplatform_netaddr_t netaddr);

void platform_udp_close(void *handle);

int platform_udp_sendto(
    _IN_ void *handle,
    _IN_ const char *buffer,
    _IN_ uint32_t length,
    _IN_ pplatform_netaddr_t netaddr);


int platform_udp_recvfrom(
    _IN_ void *handle,
    _OUT_ char *buffer,
    _IN_ uint32_t length,
    _OUT_OPT_ pplatform_netaddr_t netaddr);


#if defined(__cplusplus)
}
#endif

#endif /* __AOS_NETWORK_H */


