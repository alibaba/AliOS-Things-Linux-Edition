#ifndef _IOTX_DM_CONFIG_H_
#define _IOTX_DM_CONFIG_H_

#define CONFIG_DM_RRPC_ENABLED
#define CONFIG_DM_RRPC_NEW

#endif