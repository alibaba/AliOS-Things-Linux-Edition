/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

#ifndef __LITE_UTILS_CONFIG_H__
#define __LITE_UTILS_CONFIG_H__

#ifdef _PLATFORM_IS_LINUX_
#define WITH_MEM_STATS  0
#else
#define WITH_MEM_STATS  0
#endif

#endif  /* __LITE_UTILS_CONFIG_H__ */
