/*
 * Copyright (C) 2015-2017 Alibaba Group Holding Limited
 */

#ifndef __COMMON_UTILS_H__
#define __COMMON_UTILS_H__

#include "lite-utils_internal.h"


#endif  /* __COMMON_UTILS_H__ */

