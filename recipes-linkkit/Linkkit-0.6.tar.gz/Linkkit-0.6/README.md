
### modify the `ProductKey` `ProductSecret` `DeviceName` `DeviceSecret`

open the file: `framework/protocol/linkkit/iotkit/sdk-encap/imports/iot_import_product.h`
modify like this:

```c
#define PRODUCT_KEY             "a14CibDCcac"
#define PRODUCT_SECRET          "a1Lp7Yz4STV"
#define DEVICE_NAME             "rpi_01"
#define DEVICE_SECRET           "1IVpCRDCCP7XjGnfE5Biwcb16y0NN1KW"
```

### modify the TSL
open the file: `example/linkkitapp/linkkit_sample.c`,modify the `TSL_STRING` variable.

## build

```sh
make
```

## run

```sh
./linkkitapp
```
