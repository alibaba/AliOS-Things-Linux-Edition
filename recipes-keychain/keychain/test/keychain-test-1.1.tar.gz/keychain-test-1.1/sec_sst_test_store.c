#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "keychain.h"

// two client
// case 1: store: client1(key) get: client1(key)
uint32_t main()
{
    char *key = "test_key";
    char *secret = "sec_sst_test_store_secret";
    uint32_t ret = 0;
    kc_key_type_t key_type = KEY_CHAIN_USERDATA;
    uint8_t *out_buf = NULL;
    uint32_t out_buf_len = 0;

    ret = kc_init();
    if (ret) {
        printf("kc init failed\n");
        return ret;
    }

    ret = kc_add_item(key, secret, strlen(secret), key_type);
    if (ret) {
        printf("kc add item failed\n");
        goto clean1;
    }

    key_type = 0;
    ret = kc_get_item(key, out_buf, &out_buf_len, &key_type);
    if (ret != KC_ERROR_SHORT_BUFFER) {
        printf("kc get item size failed ret 0x%x\n", ret);
        goto clean1;
    }

    out_buf = (uint8_t *)malloc(out_buf_len + 1);
    if (out_buf == NULL) {
        printf("malloc failed\n");
        ret = KC_ERROR_OUT_OF_MEMORY;
        goto clean1;
    }
    memset(out_buf, 0, out_buf_len + 1);

    ret = kc_get_item(key, out_buf, &out_buf_len, &key_type);
    if (ret != KC_SUCCESS || key_type != KEY_CHAIN_USERDATA) {
        printf("kc get item failed ret 0x%x, key_type\n", ret, key_type);
        goto clean2;
    }
    printf("sec_sst_test_store secret type %d is: %s\n", key_type, out_buf);

clean2:
    if (out_buf) {
        free(out_buf);
        out_buf = NULL;
    }
clean1:
    kc_destroy();

    return ret;
}


