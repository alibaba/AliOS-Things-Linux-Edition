#ifndef _IROT_H_
#define _IROT_H_

#include <stdint.h>

uint32_t irot_init();
void irot_destroy();

#endif /* _IROT_H_ */
