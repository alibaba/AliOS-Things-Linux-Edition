#!/bin/sh

### BEGIN INIT INFO
# Provides:          irot
# Required-Start:
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: iot root of trust
### END INIT INFO


run_tfs() {
    echo "Executing tfsbusd ..."
    su tfs -c /usr/bin/tfsbusd  > /dev/null 2>&1
    echo "Executing irot service ..."
    su tfs -c /usr/bin/irot_service &
}

case $1 in
    start)
        run_tfs
        ;;
    stop)
        killall irot_service > /dev/null 2>&1
        if [ -f /tmp/var/run/tfs_dbus/tfs_dbus.pid ]; then
          LAST_PID="`cat /tmp//var/run/tfs_dbus/tfs_dbus.pid`"
          echo "PID [${LAST_PID}] as dbus-daemon instance existed, kill it anyway..."
          kill -9 ${LAST_PID}
          rm -vf /tmp/var/run/tfs_dbus/tfs_dbus.pid
				fi
        ;;
    restart|reload)
        $0 stop && sleep 1 && $0 start
        ;;
    *)
        echo "$0 start|stop|restart|reload"
        ;;
esac
