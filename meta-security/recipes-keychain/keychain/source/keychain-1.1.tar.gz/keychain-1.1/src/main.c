#include <dbus/dbus.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <signal.h>
#include "tfs_log.h"
#include "irot.h"
#include "kc_private.h"
#include "kcManage.h"
#if CONFIG_LINKAGE_SUPPORT
#include "watchdog_dbus_api.h"
#endif /* CONFIG_LINKAGE_SUPPORT */

#define DBUS_READ_WRITE_TIMEOUT_MS      (1000)
#define FEED_WATCHDOG_INTERVAL_S        (2)
#define COUNT_DOWN_INTERVAL_S           (5)
#define SIGNAL_REQUIRE_EXIT_VALID       (0x5aa5)

int g_signal_require_exit = 0;
void sig_handler(int sig)
{
    if (sig) {
        log_d(TAG, "Caught signal: %s, exiting...\r\n", strsignal(sig));
        if (SIGINT == sig || SIGTERM == sig) {
            g_signal_require_exit = SIGNAL_REQUIRE_EXIT_VALID;
        }
    }
}

int main(void)
{
    DBusConnection *connection;
    DBusError error;
    dbus_bool_t dbus_ret;
    int ret = -1;
    struct sigaction sig_act;
#if CONFIG_LINKAGE_SUPPORT
    struct timeval tv_start, tv_now;
    log_init(SEC_WELL_KNOWN_NAME, LOG_FILE_DB, LOG_LEVEL_DEBUG, LOG_MOD_VERBOSE);
#endif /* CONFIG_LINKAGE_SUPPORT */

    memset(&sig_act, 0, sizeof(struct sigaction));
    sigemptyset(&sig_act.sa_mask);
    sig_act.sa_handler = sig_handler;
    sigaction(SIGINT, &sig_act, NULL);
    sigaction(SIGTERM, &sig_act, NULL);

    dbus_error_init(&error);

    connection = dbus_connection_open(bus_address, &error);
    dbus_error_parse(error);
    if(NULL == connection) {
        log_e(TAG, "dbus_connection_open fail\n");
        ret = -1;
        goto clean;
    }

    dbus_ret = dbus_bus_register(connection, &error);
    dbus_error_parse(error);
    if (TRUE != dbus_ret) {
        log_e(TAG, "dbus_bus_register fail\n");
        ret = -1;
        goto clean;
    }

    ret = sec_sst_init(connection);
    if (0 != ret) {
        log_e(TAG, "sec_sst_init fail, code [%x]\n", ret);
        ret = -1;
        goto clean;
    }

    dbus_ret = dbus_bus_name_has_owner(connection, SEC_WELL_KNOWN_NAME, &error);
    dbus_error_parse(error);
    if(TRUE == dbus_ret) {
        log_e(TAG, "dbus_bus_name_has_owner true\n");
        ret = -1;
        goto clean;
    }

    ret = dbus_bus_request_name(connection, SEC_WELL_KNOWN_NAME, 0, &error);
    dbus_error_parse(error);
    if (DBUS_REQUEST_NAME_REPLY_PRIMARY_OWNER != ret) {
        log_e(TAG, "dbus_bus_request_name fail\n");
        ret = -1;
        goto clean;
    }

    if (irot_init()) {
        log_e(TAG, "irot init failed\n");
        ret = -1;
        goto clean;
    }
#if CONFIG_LINKAGE_SUPPORT
    gettimeofday(&tv_start, NULL);
    DBusMessage *feed_msg = watchdog_new_feeddog_signal(SEC_WELL_KNOWN_NAME,SEC_SST_OBJECT_PATH, "main", COUNT_DOWN_INTERVAL_S);

    while (g_signal_require_exit != SIGNAL_REQUIRE_EXIT_VALID && dbus_connection_get_is_connected(connection)) {
        dbus_connection_read_write_dispatch(connection, DBUS_READ_WRITE_TIMEOUT_MS);

        //feed the dog
        gettimeofday(&tv_now, NULL);
        if(tv_now.tv_sec < tv_start.tv_sec || tv_now.tv_sec - tv_start.tv_sec >= FEED_WATCHDOG_INTERVAL_S){
            dbus_connection_send(connection, feed_msg, NULL);
            gettimeofday(&tv_start, NULL);
        }
    }

    dbus_message_unref(feed_msg);
#else
    while (dbus_connection_get_is_connected(connection)) {
        dbus_connection_read_write_dispatch(connection, DBUS_READ_WRITE_TIMEOUT_MS);
    }
#endif /* CONFIG_LINKAGE_SUPPORT */
    irot_destroy();

clean:
#if CONFIG_LINKAGE_SUPPORT
    log_destroy();
#endif /* CONFIG_LINKAGE_SUPPORT */

    return ret;
}
