#ifndef SEC_INTROSPECT_H
#define SEC_INTROSPECT_H

#define SEC_INTROSPECT_INTERFACE_NAME "org.freedesktop.DBus.Introspectable"

#endif /* SEC_INTROSPECT_H */

