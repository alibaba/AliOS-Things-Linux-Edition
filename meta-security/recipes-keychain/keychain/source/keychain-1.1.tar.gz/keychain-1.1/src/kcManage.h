#ifndef SST_MANAGE_H
#define SST_MANAGE_H

uint32_t sec_sst_init(DBusConnection *connection);

#endif /* SST_MANAGE_H*/

