#!/bin/sh

### BEGIN INIT INFO
# Provides:          keychain
# Required-Start:    irot
# Required-Stop:     irot
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: keychain service
### END INIT INFO


run_tfs() {
    echo "Executing deploy_sst ..."
    su tfs -c /usr/bin/deploy_sst > /dev/null 2>&1
    echo "Executing keychain service ..."
    su tfs -c /usr/bin/keychain_service &
}

case $1 in
    start)
        run_tfs
        ;;
    stop)
        killall keychian_service > /dev/null 2>&1
        ;;
    restart|reload)
        $0 stop && sleep 1 && $0 start
        ;;
    *)
        echo "$0 start|stop|restart|reload"
        ;;
esac
